# Paper fixes found while writing the study guide (11 November 2026)

Each study guide agent checked the paper against the code and the result files. None of these changes a theorem or a headline number. Each is a sentence to correct in draft 3 before submission, ordered by how much it matters.

1. The factor of two is exact only for odd window sides. For odd u the strong-form ceiling is exactly half the orientation-only ceiling (120 to 60 for 3 x 3, 8,386,560 to 4,193,280 for 5 x 5). For even u the two ceilings are |F_u|/s and 2^(N-1)/s, so their ratio is 2 - 2^(1 - N/2): 1.992 for 4 x 4 (16,320 to 8,192) and 1.5 for 2 x 2. The abstract, Section 1, Section 4 (after Remark 7) and Section 10 say "halves" and "the factor of two is exact" without the qualifier. Suggested fix: "for odd window sides; for even sides the factor is 2 - 2^(1-N/2), within 0.4 percent of 2 for 4 x 4".

2. Section 7, local search: "failed at 272 x 272 on both, one of them by a single conflicting pair (energy 2)". The energy counts unordered pairs, and with s = 4 it is always even. Energy 2 here is one window that equals its own half turn, which makes two coinciding pairs: (k = 0, k = 2) and (k = 1, k = 3). Suggested fix: "one of them by a single window equal to its own half turn (energy 2)".

3. Section 8, camera: "the difference in wrong rate is the 193 single-error reads that distance 2 removes". Over all noise levels the 5 x 5 orientation-only torus has 482 wrong reads and the strong-form torus 299, a difference of 183: distance 2 removes 193 single-error wrong reads, and the strong-form torus has 10 more multi-error wrong reads (299 against 289). Suggested fix: say both numbers.

4. Section 5, second encoding: "run on the 56 shapes with at most 30 cells". There are 58 such shapes; 3 x 10 and 5 x 6 were not run with the second encoding (results/verify_3x3_s4_d2.csv). Suggested fix: "on 56 of the 58 shapes with at most 30 cells" or run the two missing shapes.

5. Section 5: "Both 6 x 6 witnesses have mixed parity". The two stored 6 x 6 files (u3v3s4d2_R6C6.txt and u3v3s4d2_R6C6_camera.txt) are the same torus. Suggested fix: "The 6 x 6 witness has mixed parity".

6. Section 8: "all tori see the same positions, turns and noise draws". With one seed for every torus the draws coincide, but the positions are the same only for tori of the same size. Suggested fix: "the same random draws".

7. Appendix A and Table 3: the 256 x 256 strong-form solve with seed 0 is recorded in grow_5x5.csv with a 10,000,000-flip budget, not 30 million. It solved after 728,102 flips, and a re-run at 30 million gives the identical torus, so the result stands; the budget column or the appendix sentence should match.

8. Section 9: H1 predicted two things, a 3 x 3 maximum equal to the ceiling (60) and large 5 x 5 tori. The first failed (36); the second held (256 x 256). The paper says H1 failed, which is right for the joint prediction, but saying that half of it held is more accurate and pre-empts the question.

9. Section 4, before Lemma 4: "Burns and Mitchell state the case s = 4 ...; the case s = 2 follows by the same argument." Their Lemma 16 (Section 5.1, 2-orientable arrays) already states the s = 2 bound, mn <= (c^(uv) - c^floor((uv+1)/2))/2, and Lemma 19 (Section 6.1) the s = 4 bound with /4 (checked in the Royal Holloway open copy). Suggested fix: cite Lemma 16 for s = 2 and Lemma 19 for s = 4.

10. Section 9: "orientation alone falls short of its own ceiling too". At 3 x 3 the orientation-only maximum lies between 85 and 120, so falling short is not established (and at 4 x 4 and 5 x 5 only search results exist). Suggested fix: "the best orientation-only tori we found also fall short of their ceiling (85 of 120 at 3 x 3)".

11. Appendix A, Commands: "run_camera.py, with the tori listed in the results README" (the README does not list them; they are set in run_camera.py), and run_interleave_table.py and run_interleave_rows6.py are listed without their required arguments (a timeout; for rows6 also the list of widths). Suggested fix: name the tori or point to the script, and give the full commands, e.g. "run_interleave_table.py 300".

Result files with stale wording (records from earlier runs; update or leave with a dated note):
- results/bounds.md lists the constant-parity divisibility under "Not proved", but the paper now proves it as Lemma 8. What remains open is whether near-extremal tori must have constant parity.
- results/exact_3x3_strong_form.md still calls the cause of the 3 x 3 loss local, but after review 2 the paper reads it as closure; it also leaves 2 x 3 out of the list of mixed-parity tori.
- paper/talk/talk_plan.md predates the reviews; the Slides deck replaces it.

A possible strengthening, not in the paper (study guide Part 4, Remark labelled "checked here, not in the paper"): parts (a) and (b) of Theorem 11 appear to hold without admissibility, and removing descriptors fixed by the half turn sharpens the interleave caps to 384 (admissible) and 480 (unrestricted). It was checked by brute force while writing the guide; treat it as a lead, not a result, until you have checked the proof yourself.
