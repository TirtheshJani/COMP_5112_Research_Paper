# Citation check for refs.bib

Run 2026-11-09 from the cloud shell with /tmp/bibcheck/check_refs.py (adapted from research/notes/tools/check_bib.py on TJ's PC). Each DOI was resolved at Crossref (DataCite fallback; no 10.4230 DOI is in this file), and each arXiv id at export.arxiv.org. Requests were sequential with 1.2 s (Crossref) and 3.5 s (arXiv) pauses; there were no HTTP 429 errors. Titles were compared after normalisation (VERIFIED = similarity 0.85 or more; every entry with an identifier scored 1.00), plus first-author surname and year (a difference of one year is accepted).

Course rule: BibTeX should come from Google Scholar. These entries were NOT exported from Scholar (no scraping was done). TJ should re-export each entry from Google Scholar, reconcile it with the fields below, and keep the DOIs.

Entries: 43. VERIFIED: 37. NO_ID (print only, checked by hand): 6. Problems: 0.

Duplicate works across bib files: the main file loads \bibliography{refs,refs_software}, and refs_software.bib (written separately) defines ignatiev2018pysat, biere2020cadical, audemard2009glucose and lam2015numba, the works that refs.bib holds as pysat2018, cadical2020, glucose2009 and numba2015 (the keys requested for this file). Section 05 currently cites the refs_software keys, so the refs.bib copies are uncited and do not print. Citing both keys of a pair would list the work twice: settle on one key per work. No key is defined in both files, so BibTeX reports no repeated entry. Two fields in refs_software.bib disagree with today's checks: audemard2009glucose gives pages 399--404 where the IJCAI index gives 399--403, and biere2020cadical spells the fourth author Maximillian where the JKU record and the paper give Maximilian.

## One line per key

- fan85debruijn: NO_ID (print only). Ars Combinatoria 19A, pp. 205--213 (1985) as given by three independent reference lists (Kreitzer et al. ref. 7, Hurlbert and Isaak 1995 ref. 3, Chung et al. ref. 6); local scan read. Page range corrected from 205--221 in the original refs.bib to 205--213, matching otorus.bib.
- burns1993coding: NO_ID (print only). Cryptography and Coding III, ed. Ganley, OUP 1993, pp. 31--66, from the reference list of Mitchell and Wild 2022 (ref. 4); full text read from the open-access Royal Holloway copy. Lemma, theorem and figure numbers in Section 2 follow that copy; check them against the printed chapter if one is available.
- berkowitz2016robust: VERIFIED. doi:10.1137/1.9781611974331.ch136 -> crossref "Robust positioning patterns" (2016). Crossref dates the SODA 2016 proceedings to December 2015; 2016 kept.
- schusselbauer2021dothraki: VERIFIED. doi:10.1145/3430524.3440656 -> crossref "Dothraki: Tracking Tangibles Atop Tabletops Through De-Bruijn Tori" (2021). First pass flagged the first author only because of the umlaut; rerun with accent folding: match.
- cooper2013generalized: VERIFIED. doi:10.1016/j.aam.2012.12.002 -> crossref "Generalized Fibonacci recurrences and the lex-least de Bruijn sequence" (2013).
- cock1988: VERIFIED. doi:10.1016/0012-365X(88)90095-7 -> crossref "Toroidal tilings from de Bruijn-Good cyclic sequences" (1988).
- etzion1988: VERIFIED. doi:10.1109/18.21260 -> crossref "Constructions for perfect maps and pseudorandom arrays" (1988).
- paterson1994: VERIFIED. doi:10.1109/18.335886 -> crossref "Perfect maps" (1994).
- mitchellpaterson1994: VERIFIED. doi:10.1007/BF01388557 -> crossref "Decoding Perfect Maps" (1994).
- hurlbert1993: VERIFIED. doi:10.1016/0097-3165(93)90087-O -> crossref "On the de Bruijn Torus problem" (1993).
- hurlbert1995: VERIFIED. doi:10.1007/BF01390770 -> crossref "New constructions for De Bruijn tori" (1995).
- cdg1992: VERIFIED. doi:10.1016/0012-365X(92)90699-G -> crossref "Universal cycles for combinatorial structures" (1992).
- kreitzer2024alternating: VERIFIED. doi:10.1007/s10623-023-01351-0 -> crossref "Using alternating de Bruijn sequences to construct de Bruijn tori" (2024).
- becher2024nested: VERIFIED. doi:10.1109/TIT.2024.3445122 -> crossref "Nested Perfect Arrays" (2024).
- horan2016locating: VERIFIED. doi:10.1016/j.disc.2015.11.015 -> crossref "Locating patterns in the de Bruijn torus" (2016); arXiv:1505.04065 -> arxiv "Locating Patterns in the De Bruijn Torus" (2015).
- carey2025universal: VERIFIED. doi:10.1007/s10623-025-01609-9 -> crossref "Universal partial tori" (2025).
- gerlach2026: VERIFIED. arXiv:2609.27583 -> arxiv "Shorthand Universal Tori for Permutations: Existence, Symmetry, and Generation of Twori" (2026).
- burnslloyd1995position: NO_ID (patent, no DOI). US 5,442,147, Burns and Lloyd, Hewlett-Packard, granted 1995-08-15; checked on Google Patents (US5442147A) on 2026-11-07 per lit/07_threat_checks.md. Not re-fetched today (Google Patents blocks scripted requests).
- dai1993orientable: NO_ID (print only). Same volume, pp. 97--115, from the reference list of Mitchell and Wild 2022 (ref. 8). Not read; Section 2 states only what later papers restate.
- mitchell2022constructing: VERIFIED. doi:10.1109/TIT.2022.3158645 -> crossref "Constructing Orientable Sequences" (2022).
- gabric2024construction: VERIFIED. arXiv:2401.14341 -> arxiv "Construction of orientable sequences in $O(1)$-amortized time per bit" (2024).
- alhakim2024orientable: VERIFIED. doi:10.1007/s12095-024-00742-x -> crossref "Orientable sequences over non-binary alphabets" (2024); arXiv:2407.14866 -> arxiv "Orientable sequences over non-binary alphabets" (2024).
- mitchell2026searching: VERIFIED. arXiv:2610.33601 -> arxiv "Searching for binary orientable sequences" (2026).
- chee2020robust: VERIFIED. doi:10.1137/19M1253472 -> crossref "Robust Positioning Patterns with Low Redundancy" (2020).
- wei2022nearly: VERIFIED. doi:10.1109/TIT.2021.3118905 -> crossref "Nearly Optimal Robust Positioning Patterns" (2022).
- bruckstein2012simple: VERIFIED. doi:10.1109/TIT.2012.2191699 -> crossref "Simple and Robust Binary Self-Location Patterns" (2012); arXiv:1112.4253 -> arxiv "Simple and Robust Binary Self-Location Patterns" (2011).
- szentandrasi2012uniform: VERIFIED. doi:10.1109/ISMAR.2012.6402593 -> crossref "Uniform Marker Fields: Camera localization by orientable De Bruijn tori" (2012).
- herout2013five: VERIFIED. doi:10.1109/CVPR.2013.182 -> crossref "Five Shades of Grey for Fast and Reliable Camera Pose Estimation" (2013).
- zhu2023hydramarker: VERIFIED. doi:10.1109/TPAMI.2022.3212862 -> crossref "HydraMarker: Efficient, Flexible, and Multifold Marker Field Generation" (2023).
- stelldinger2025puzzleboard: VERIFIED. doi:10.1007/978-3-031-85187-2_21 -> crossref "PuzzleBoard: A New Camera Calibration Pattern with Position Encoding" (2025); arXiv:2409.20127 -> arxiv "PuzzleBoard: A New Camera Calibration Pattern with Position Encoding" (2024).
- garrido2014automatic: VERIFIED. doi:10.1016/j.patcog.2014.01.005 -> crossref "Automatic generation and detection of highly reliable fiducial markers under occlusion" (2014).
- garrido2016generation: VERIFIED. doi:10.1016/j.patcog.2015.09.023 -> crossref "Generation of fiducial marker dictionaries using Mixed Integer Linear Programming" (2016).
- olson2011apriltag: VERIFIED. doi:10.1109/ICRA.2011.5979561 -> crossref "AprilTag: A robust and flexible visual fiducial system" (2011).
- morano1998structured: VERIFIED. doi:10.1109/34.667888 -> crossref "Structured light using pseudorandom codes" (1998).
- xu2007robust: VERIFIED. doi:10.1007/978-3-540-74873-1_37 -> crossref "Robust Dense Depth Acquisition Using 2-D De Bruijn Structured Light" (2007).
- vandenhouten2017design: VERIFIED. doi:10.1117/12.2270248 -> crossref "Design and quality metrics of point patterns for coded structured light illumination with diffractive optical elements i" (2017).
- numpy2020: VERIFIED. doi:10.1038/s41586-020-2649-2 -> crossref "Array programming with NumPy" (2020).
- numba2015: VERIFIED. doi:10.1145/2833157.2833162 -> crossref "Numba a LLVM-based Python JIT compiler" (2015).
- pysat2018: VERIFIED. doi:10.1007/978-3-319-94144-8_26 -> crossref "PySAT: A Python Toolkit for Prototyping with SAT Oracles" (2018).
- cadical2020: NO_ID (competition proceedings, no DOI). Title, the four authors, Proc. of SAT Competition 2020 (Univ. Helsinki, Dept. of Computer Science Report Series B, B-2020-1) and year checked on 2026-11-09 against the JKU research-portal record, the Helsinki research-portal record of the proceedings and the paper PDF. Pages left out: the JKU record gives 50--53 but the proceedings table of contents could not be fetched (bot wall), so the range is unconfirmed.
- glucose2009: NO_ID (no DOI). Checked on 2026-11-09 against the IJCAI proceedings index (ijcai.org/Proceedings/09): Proceedings of the Twenty-First IJCAI, ed. Craig Boutilier, pp. 399--403, paper 74. Note that some secondary sources give 399--404; the IJCAI page says 399--403.
- hall1935: VERIFIED. doi:10.1112/jlms/s1-10.37.26 -> crossref "On Representatives of Subsets" (1935).
- bondymurty2008: VERIFIED. doi:10.1007/978-1-84628-970-5 -> crossref "Graph Theory" (2008).

## Not in refs.bib

- lloydburns1993 (Lloyd and Burns, Cryptography and Coding III, 1993): unread and unverified, so it is mentioned in Section 2 only as "cited in" Burns and Mitchell, with no entry of its own.
- No requested key was dropped. CaDiCaL is cited through its 2020 SAT Competition description without page numbers (see above), not through a substitute paper.

## Reconciliation by the main session (2026-11-09)

The duplicate software entries were merged: the paper now cites pysat2018, numba2015, cadical2020 and glucose2009 from refs.bib, and refs_software.bib was removed from the build. Two corrections to refs.bib after re-checking primary sources: glucose2009 pages are 399--404 (the page numbers printed on the IJCAI 2009 PDF, paper 074, and DBLP both give 399--404; 399--403 was wrong); cadical2020 gains pages 50--53 and its editors (proceedings table of contents and the JKU research portal both give 50--53). The fourth author's name, Maximilian, matches the paper's own header.

## Added after peer review 1 (2026-11-09)

- ruskey2012fixed: VERIFIED. doi:10.1137/100808782 -> crossref "De Bruijn Sequences for Fixed-Weight Binary Strings", Ruskey, Sawada, Williams, SIAM J. Discrete Math. 26(2):605--617 (2012).
- mitchell1996decodable: VERIFIED. doi:10.1109/18.532887 -> crossref "A method for constructing decodable de Bruijn sequences", Mitchell, Etzion, Paterson, IEEE Trans. Inf. Theory 42(5):1472--1478 (1996).
- macwilliamssloane1976: VERIFIED earlier in otorus.bib (DOI in Crossref); copied over. Not read; cited only as the classical source for pseudo-random arrays.
- jackson2009research: copied from otorus.bib (DOI 10.1016/j.disc.2009.04.002, checked there).
- mitchellpaterson1994 is now cited (decoding of perfect maps).
