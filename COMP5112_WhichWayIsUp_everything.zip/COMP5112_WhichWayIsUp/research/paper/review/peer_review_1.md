# Peer review 1: "Which Way Is Up? Orientation and Error Detection Compete in Binary Position Tori"

Reviewer: independent reviewer (did not write any part of the paper or code).
Reviewed: `paper/build/paper_draft1.pdf` (build of 2026-11-09 19:22, pages 1 to 19; the Assignment 3 appendix was skipped), the LaTeX sources, `results/`, and `otorus/`. Line numbers below are the LIPIcs line numbers printed in that PDF. Several source files (refs.bib, 02_related.tex, 05_exact.tex, the main .tex) were edited at 19:33 while this review was in progress; I checked that those edits do not touch any finding below.

What I ran: the test suite (51 passed, 72 s); an independent turned-window checker written for this review (explicit index arithmetic for the quarter turn, no `np.rot90`, no `otorus` code); an independent CNF encoding for 3 x 3 strong-form tori (own instance generator, totalizer at-least-2, no symmetry breaking); a direct CNF for checkerboard interleaves without the banned-word restriction; brute force over all label pairs for 15 XOR shapes; brute force over all 2 x 2, 3 x 3 and 4 x 4 arrays for Lemma 3 and Remark 7; the paper's `dfs_search` on longer thin shapes. Nothing ran longer than about three minutes.

## Summary of the paper

The paper asks whether a binary doubly periodic array can be both 4-orientable (every window and its three quarter turns are distinct, so one window gives position and orientation) and error-detecting (every two turned windows differ in at least two cells, so one misread cell is rejected). It calls this the strong form. It proves that distance 2 halves the counting ceiling (to 4,193,280 cells for 5 x 5 windows, Theorems 5 and 6) and that no argument about the window set alone can do better (Remark 7). By SAT and exhaustive search it finds the exact 3 x 3 maximum, 36 cells, against at least 81 for orientation alone. For 5 x 5 windows it gives two algebraic families with label decoders (XOR, maximum 36 cells; checkerboard interleave, stated maximum 280 cells), a local-search 256 x 256 strong-form torus, and a 1024 x 1024 orientation-only torus. A simulated camera shows that no strong-form torus decodes a one-cell misread to a wrong position. The thesis is that orientation and error detection compete, and that the competition comes from overlap between windows rather than from counting.

## Overall assessment

This is an ambitious and well-built course paper. The question is new as far as I can tell, the related-work section is careful and honest about its search limits, the introduction follows The Craft of Research closely (context, a problem stated as condition plus consequence, then the response), figure captions state their point, the Discussion openly reports that both preregistered hypotheses failed, and almost every number traces to a results file. I checked the proofs of Lemma 3, Lemma 4, Theorems 5 and 6, Remark 7 and Lemma 8 and found them correct; Theorem 10 is correct under its hypothesis, though the sketch skips a step. I independently confirmed all eight satisfiable 3 x 3 shapes of Theorem 9, the 6 x 6 XOR torus at distance 5, the 14 x 20 interleave at distance 2, the 256 x 256 strong-form torus, the 1024 x 1024 4-orientable torus, the XOR shape list on 15 shapes by brute force, every entry of Tables 2, 3 and 4, and the camera totals.

Against that: one theorem is false as stated (Theorem 11, the interleave maximum; I found a 308-cell strong-form interleave), the headline thesis is stated more strongly than an exact 3 x 3 result plus ratios of search outcomes can carry, the 5 x 5 search comparison is not run under equal conditions, the verification statements do not match the stored artifacts (92 stored tori, not 99; six of eight Theorem 9 witnesses missing; the "independent" methods share the turned-window generator), and the camera experiment mainly re-confirms a theorem while its 3 x 3 control is not size-matched. The AI-use statement is candid but leaves open what the author personally verified, which matters for a methods course.

Structure against The Craft of Research: the introduction is strong; significance is stated but inflated in two places (finding 15); "compose" and "compete" are never given one quantitative definition (finding 6); claims come with reasons and evidence, and the Limitations paragraph acknowledges some objections but not the ones in findings 3, 4 and 5; the conclusion has a main point, a new significance and a call for research. I found no em dashes. The prose is plain and mostly free of filler; the main tell is repetition ("Large strong-form tori still exist" appears in the abstract, introduction and conclusion), and a few sentences are dense (findings 9, 14, 20).

Grade band: as submitted I would expect the upper B to low A range. With finding 1 fixed and findings 2 to 8 addressed, this would be a clear A paper for a research methodology course. How the instructor weighs the extent of AI involvement (finding 8) under the course policy could move the grade either way and is outside what I can judge.

Counts: 1 critical, 7 major, 12 minor.

## Findings

### Critical

**1. Theorem 11 is false as stated: a 4-orientable checkerboard interleave with 308 cells and window distance 2 exists.**

Location: Section 6.2, Theorem 11 (p. 12, lines 371 to 381); Introduction line 69 ("a checkerboard interleave whose largest member has 280 cells"); Figure 4 annotation "14 x 20 = 280 cells, the largest that exists" and caption ("every tested shape above 280 cells is impossible"); line 368 ("Period R = 2 is impossible"); line 382 ("7.8 times"); `results/interleave.md`.

What is wrong: Theorem 11 claims the maximum over all 4-orientable checkerboard interleaves. The computation behind it, `otorus/construct.py: solve_interleave`, adds the hypothesis of Theorem 10 as hard clauses: it forbids 00000, 11111, 01010 and 10101 in every 5-window of A and of B. So the SAT sweep decides the maximum only over interleaves whose label sequences avoid those four words. The cap RC <= 392 from Theorem 10(c) likewise holds only under that hypothesis.

Evidence: I encoded 4-orientability of the interleave directly (each turned window as a list of label indices, one clause per pair of turned windows, CaDiCaL 1.5.3 through PySAT, no banned-word clauses).
- 14 x 22 is satisfiable: A = 11110010110000, B = 1101000101011101100100. B contains 01010 and 10101. `interleave_checkerboard(A, B)` is 4-orientable by the paper's own `otorus.windows.is_orientable`, `min_distance_fast(T, 5, 4)` returns 2, and my independent checker agrees (no two turned windows equal, none at distance 1). That is a strong-form interleave of 308 cells.
- 6 x 48 is also satisfiable (288 cells, distance 2): A = 110010, B = 000100000111011110000011110010011011101000101011 (B contains 00000, 01010, 10101).
- Without the restriction, 16 x 18, 4 x 72 and 2 x 150 came out UNSAT; 16 x 20, 14 x 24 and 18 x 20 were undecided after 30 s each.
- Without the hypothesis the only cap I can see is from counting turned windows by (type, row word, column word): 4RC <= 2 x 32 x 32 = 2048, so RC <= 512.

Fix: Either (a) define the family as interleaves whose label sequences avoid the four words and restate Theorem 11, the introduction, the abstract wording and Figure 4 for that family. This is also the family for which the decoder on lines 383 to 386 works as written, because a banned word makes a colour class constant along both rows and columns, so the type test becomes ambiguous. Or (b) rerun the shape sweep with a direct encoding, report the true maximum of the unrestricted family (at least 308), and give a decoder that handles ambiguous types. Option (a) is the smaller change. In either case qualify "Period R = 2 is impossible" as holding under the hypothesis.

### Major

**2. The main claim ("the competition comes from the overlap between windows, not from counting") is stronger than the evidence.**

Location: Abstract lines 11 to 17; Introduction lines 52 to 61; Discussion lines 480 to 494; Conclusion lines 518 to 529.

What is wrong:
- Once Remark 7 shows that window codes reach the ceiling exactly, any shortfall of the true torus maximum is by definition caused by the torus constraint. "Comes from overlap" is therefore close to a restatement; the informative content is the size of the extra loss.
- The only exact evidence about that size is 3 x 3. The strong-form maximum is 36 and the orientation-only maximum lies between 81 and 120, so the ratio of maxima lies between 2.25 and 3.33, against a counting ratio of 2. The excess over counting is a factor between 1.125 and 1.67.
- For 4 x 4 and 5 x 5, "6 to 10" and "16" are ratios of local-search outcomes. Each is a lower bound on an unknown maximum, and a ratio of two lower bounds bounds nothing. The same search leaves orientation alone at 12.5 percent of its own ceiling at 5 x 5, so search shortfall is not specific to distance.
- The proposed mechanism in Section 7 ("what limits the search seems to be how crowded the space of codes is around each window", lines 427 to 428) is a density argument about the search. It is a counting-type explanation and does not isolate overlap; it sits awkwardly beside "not from counting".
- Line 480: "Distance 2 always costs more than the factor of two that counting predicts" generalizes from one exact window size to all. Line 482 labels 2.25 "(exact)", but 2.25 is a lower bound; only the 36 is exact.

Fix: State the claim at the strength of the evidence, for example: "For 3 x 3 windows we prove that distance 2 costs a factor of at least 2.25 in maximum size, more than the factor 2 that any window-code argument allows. For 4 x 4 and 5 x 5 windows the same local search finds strong-form tori 6 to 16 times smaller than orientation-only tori, which is consistent with a larger loss but does not establish it." Remove "always", fix "(exact)", and present the overlap mechanism as a hypothesis with a stated test (an overlap-based bound improving Theorem 5, or exact 4 x 4 maxima).

**3. The search comparison between distance 1 and distance 2 is not controlled, and its ratios carry false precision.**

Location: Section 7, lines 391 to 428, Table 3, Figure 5; abstract line 13; introduction lines 59 to 61; conclusion line 521.

What is wrong, with evidence from `results/grow_5x5.csv`, `results/grow_4x4.csv` and the logs:
- Unequal budgets. At 5 x 5 the failing orientation-only run (1536 x 1536) had 30 million flips (932 s); the failing strong-form runs (288 x 288, 320 x 320) had 10 million (514 s, 637 s). Line 392 says the search is "run in the same way with and without the distance condition". Table 3 does not report budgets at all (3 million per run at 4 x 4).
- Different size grids. Orientation-only tried 256, 512, 1024, 1536; strong form tried 128, 256, 288, 320. The brackets are [1024^2, 1536^2) (a factor 2.25 in cells) and [256^2, 288^2) (factor 1.27). The ratio of search limits implied by the brackets lies anywhere from about 12.6 (1024^2 / 288^2) to 36 (1536^2 / 256^2), not "16". 1024 x 1024 was solved in 300,107 flips and 7 s, so it is probably well below the orientation-only limit.
- At 4 x 4, "between 6-fold and 10-fold ... depending on the seed" (line 414) is a grid artifact: seed 1 stopped at energy 4 at 64 x 64 and 56 x 56 was never tried. The bracket-implied range is about 4.8 to 16.
- One seed per condition at 5 x 5.
- A fixed temperature of 0.5 for both conditions, although a flip's energy change is on a different scale when each window's 1 + u^2 code ball is counted.

Fix: Equal flip budgets (or equal wall-clock time), bisection on size, at least five seeds per size, budgets in Table 3, and report the brackets plus the range of ratios they imply. Calibrate the temperature per condition or report a small sensitivity check.

**4. The verification and data statements do not match the stored artifacts.**

Location: Introduction lines 76 to 78; Section 5 lines 290 to 292 and 303 to 305; Data and code lines 538 to 544; AI statement lines 549 to 550; `results/README.md` item 2; `results/exact_3x3_strong_form.md`.

What is wrong:
- "reports no failures on all 99 stored tori" (line 544). `results/verify_witnesses.txt` has 92 "ok" lines and `results/witnesses/` holds 92 files.
- Theorem 9's proof is said to include "the witnesses for the eight satisfiable shapes, each checked again by a separate verifier" (lines 304 to 305). Only two 3 x 3 strong-form witnesses are stored (`u3v3s4d2_R2C3.txt`, `u3v3s4d2_R6C6_camera.txt`). The 36-cell 3 x 12 witness and the original 6 x 6 witness, cited by file name in README.md and exact_3x3_strong_form.md (`u3v3s4d2_R3C12.txt`, `u3v3s4d2_R6C6.txt`), do not exist. Also not stored: the XOR tori 1 x 6, 4 x 6 and 5 x 6, and every interleave except 14 x 20. Line 540 says "every reported torus" is in the repository.
- Line 291 says the exhaustive search "shares no code with the SAT encoding". `otorus/exhaustive.py` imports `_instances` from `otorus/sat.py`, and the second encoding `solve_torus_alt` uses the same function. All three "separately written" methods share the code that lists which cells each turned window reads, which is exactly where a shared bug would make UNSAT answers agree wrongly. The witness verifier (`windows.py`) is independent, but it only protects SAT answers.
- No DRAT or LRAT certificates (acknowledged on line 512).

Evidence that Theorem 9 itself survives: I regenerated all eight satisfiable shapes with `dfs_search` and checked them with my own turned-window code; all have exact d4 = 2. My independent CNF gave SAT for 3 x 12 and 6 x 6 and UNSAT for 3 x 10, 4 x 9, 5 x 7 and 2 x 4, agreeing with the paper (3 x 13, 3 x 16 and 6 x 7 timed out at 25 s).

Fix: Store every reported torus, rerun `verify_witnesses.py` and quote the real count, correct the "shares no code" sentence (or give the DFS its own instance generator), and have CaDiCaL emit DRAT proofs for the UNSAT shapes of Theorems 9 and 11 and check them with drat-trim.

**5. The camera experiment mostly re-checks a theorem, and its 3 x 3 control is not size-matched.**

Location: Abstract lines 15 to 16; introduction lines 62 to 65; Section 8 lines 434 to 471 and Table 4; Discussion lines 500 to 505.

What is wrong:
- For a torus with d4 >= 2, a read with exactly one wrong cell cannot equal any turned window (Section 3, lines 200 to 205). "0 of 103,801" therefore tests the implementation, not the design, and should not appear in the abstract as a finding.
- Line 437 says the controls have "the same window sizes", but the 3 x 3 pair differs in size and density: strong form 6 x 6 (density 0.28) against orientation-only 9 x 9 (density 0.63). `sat_table.csv` shows a 4-orientable 6 x 6 torus exists. The drop in wrong reads at sigma = 0.3 from 23.3 to 2.6 percent (line 461) mixes the effect of distance with a 2.25-fold drop in density.
- The matched 5 x 5 pair (both 256 x 256) is the clean comparison, and the data say something the text does not: multi-error wrong reads are the same (299 strong form, 289 orientation-only, from `camera_robustness.csv`), so the whole difference is the 193 single-error reads.
- The cost side is not discussed: at sigma = 0.3 the 3 x 3 strong-form torus rejects 33.5 percent of reads against 12.8 percent for the 9 x 9 control, with the same correct rate (63.9 versus 64.0 percent). Distance 2 converts wrong answers into rejections; it does not add correct reads.

Fix: Add a size-matched 6 x 6 orientation-only 3 x 3 control; report correct, rejected and wrong rates with intervals; present the single-error result as a check and the multi-error and density results as the findings.

**6. The preregistered hypotheses are reported honestly in the Discussion, but the framing elsewhere moves the goalposts, and deviations from the plan are not reported.**

Location: Introduction lines 46 to 53; Discussion lines 473 to 485; `notes/02_research_statement_v1.md`.

What is wrong:
- Both preregistered hypotheses failed (H1: 3 x 3 maximum = 60; H2: 5 x 5 search stalls near 36). The Discussion says so, which is good practice. But the title, abstract and conclusion assert that the requirements "compete" without telling the reader that the competition hypothesis, as preregistered, was falsified and that the "graded" form was formulated after seeing the data.
- "Compose" and "compete" are defined in the introduction by distance from the counting bound ("the largest tori sit close to the counting bound" versus "fall far below", lines 47 to 50). The verdict in the Discussion uses a different criterion: the ratio to orientation alone compared with 2 (lines 480 to 483). Under the introduction's definition, orientation alone also falls below its own bound (at least 67.5 percent at 3 x 3; 12.5 percent under search at 5 x 5), so the original test had no control. The paper later uses the right comparison but does not say it changed the criterion.
- Deviations from the research statement are not reported: the planned camera test had perspective, pixel noise, a plain de Bruijn baseline and a false-accept rate; the planned exact 4 x 4 maximum was not computed; the XOR cap moved from 128 to 120.

Fix: One sentence in the abstract and introduction saying that both preregistered predictions failed and that the graded claim is exploratory. One quantitative definition of compose and compete, used throughout (for example, ratio of maxima with and without distance compared with the ratio of ceilings). A short list of deviations from the plan in Limitations.

**7. Methods are not described well enough to reproduce from the paper alone.**

Location: Sections 5, 7, 8 and 10.

Missing items, all of which I had to recover from the code:
- SAT: the PySAT and Glucose versions; how timeouts work (a loop of 50,000-conflict budgets with a wall-clock check); the timeouts used per table (25 minutes for the 3 x 3 control, 300 s for the interleave table, where 6 x 62 and 6 x 64 timed out); that the "N clauses" (line 287) are one per position at which the two windows read different cells, so fewer than N when windows overlap.
- Exhaustive search: that cell 0 is fixed to 0, and that cells are assigned row by row on the transposed shape.
- Local search: flip budget per run; the initial state, a fresh uniform random torus for each size (line 406, "We grew square tori in steps", suggests incremental growth, but `scripts/run_grow.py` restarts from random); which seeds (0 and 1); why rescans every 50,000 flips; the hardware.
- Camera: the random seed (12345, the same for every torus, so the comparison uses common random numbers, which is good design and worth stating); the exact noise levels (0, 0.10, 0.15, ..., 0.40, not evenly spaced from 0); 200,000 reads per timing.
- General: Python, NumPy and Numba versions; the run commands, which are in the results files but not in the paper.

Fix: A short reproducibility paragraph or table in Section 10 or an appendix.

**8. The data and code statement and the AI-use disclosure are clear in tone but not yet adequate.**

Location: Section 10, lines 538 to 550; LaTeX comments "% TJ: add the public repository URL here" and "% TJ: check that this statement matches what you did".

What is wrong:
- No URL or archive. "The author's course repository under research/otorus" cannot be reached by a reader.
- The count 99 and "every reported torus" are wrong (finding 4).
- The AI statement is unusually candid, which is to its credit. It says the AI searched the literature, wrote the code, ran the experiments, drafted the proofs and the text, and drew the figures, while the author chose the topic, question and scope and "reviewed the results". For a course graded on research method, the instructor will want to know what the author personally verified. For example: were the proofs checked line by line? Finding 1 is the kind of error such a check would catch. It should also give the model version and the working environment (an agentic coding setup that ran code), and state which course AI policy it follows.
- It does not mention that the BibTeX was not exported from Google Scholar, which `paper/refs_check.md` says the course requires.
- The two TODO comments show the author has not yet confirmed the statement.

Fix: Give the URL, or say the repository is submitted with the paper. Correct the count. Name the model version and environment. List what the author checked by hand. Cite the course AI policy. Resolve the TODOs.

### Minor

**9. A computational fact in Section 5 is wrong, and the corrected version supports a stronger result.**

Location: Section 5, lines 309 to 314; Discussion lines 492 to 494.

The paper says the exhaustive search tree "has the same number of nodes for every length C >= 8 (28,645 nodes for 4 rows, 301,975 for 5 rows, about 2.07 million for 6 rows)". For 6 rows, `verify_3x3_s4_d2_dfs.csv` gives 2,060,805 (C = 8), 2,072,925 (C = 9) and 2,073,601 (C = 10). So the count is not constant from C = 8, and the paper's data (C <= 10) cannot show it becomes constant at all. I ran `dfs_search` for 6 x 11 to 6 x 14: all give 2,073,601, so for 6 rows it stabilizes from C = 10. For 3 rows the count is 5,728,261 for every C from 17 to 24, which the paper does not mention. The 4- and 5-row counts are as stated (checked up to C = 20 and C = 16).

Fix: Correct the threshold for 6 rows, add 3 rows, and turn the observation into a proposition. Every turned window that wraps around the long side is checked only when the last column is set, so identical trees for consecutive lengths mean no branch reaches the last column. A cleaner proof is to run the same DFS on an open strip of R rows (wrapping only along the short side) and show it dies by some column L, which proves non-existence for every length. Line 493, "before the torus has wrapped around", should say "before the long side wraps"; the short side wraps from the start.

**10. The Theorem 10 proof sketch skips a step, and one side claim is not what the test checks.**

Location: lines 357 to 368; `tests/test_construct.py`.

The sketch should say that the label words of turned windows are 5-windows of A or B read forwards or backwards (as in `interleave_descriptors`), and that the excluded set is closed under reversal. Without this, "Those are exactly the four excluded words" (line 359) is not justified for turned windows. "Every 4-orientable case had distance exactly 2" (line 368) is not what the test checks: it calls `min_distance_fast(..., rmax=1)`, which returns 2 to mean "at least 2". The 360 random pairs are drawn only from label sequences with distinct 5-windows (`random_window_cycle`), a narrower set than the theorem covers.

**11. Small gaps in the ceiling section.**

Location: Section 4, lines 225 to 262; Limitations lines 506 to 507.

- Hall's theorem and Kőnig's theorem are used without citation, although refs.bib already holds `hall1935` and `bondymurty2008`.
- Lemma 4 is attributed to Burns and Mitchell's Lemma 19, which is stated for 4-orientable arrays. Say whether the s = 2 case is also theirs. Note that `refs_check.md` warns that the lemma numbers were taken from an open-access copy, not the printed chapter.
- "Window codes" in the title of Remark 7 is not defined. One sentence (a set of arrays in F_u, closed under the quarter turn, at pairwise distance at least delta) would make "no argument about the set of windows alone" precise.
- Remark 7 actually shows that the two constraints compose exactly at the level of codes (factor 2). Saying so would give the introduction's undefined analogy, "the way coding theory stacks constraints on a code" (lines 48 to 49), a precise meaning.
- Line 506 to 507: solved search sizes are valid lower bounds on the maxima; only the failed sizes are "not bounds".

**12. The 3 x 3 orientation-only control stops at an arbitrary point.**

Location: Section 5, lines 316 to 322; `sat_table.csv`.

Every shape up to 81 cells was tried, then only the two 120-cell shapes; nothing from 82 to 119 cells was attempted. Since 81/36 = 2.25 is the paper's only exact evidence for "more than counting", the rest of that range matters. My quick attempts all failed: the paper's SAT encoding at 25 s each on 9 x 10, 10 x 10, 4 x 25, 3 x 30 and 9 x 11, and the paper's local search (four seeds, 2 million flips each) at 90 to 120 cells. So 81 may be close to the true maximum, but the intermediate shapes should be run with the same 25-minute budget and reported.

**13. The family decoders are claimed but never demonstrated.**

Location: Section 6, lines 325 to 326 and 382 to 390; Section 8.

The paper says the families' "value lies in the short decoder". But the camera uses the generic sorted-table decoder for all six tori, and no XOR decoder is described. Either implement and time the label decoders, or soften the claim.

**14. The Section 7 reading of where search stops overstates "similar", and one sentence is hard to follow.**

Location: lines 417 to 428; Figure 5 caption; lines 403 to 405.

Occupancies from 0.125 to 0.415 span a 3.3-fold range, yet they are called "a similar fraction". They are also taken at the largest solved sizes, which sit at different distances from the failures (orientation-only 5 x 5 solved 1024 x 1024 in 7 s). Give the occupancy bracket between the solved and failed size for each condition. Line 404, "it can hold only one partner of a conflict", is hard to follow. Explain that after an accepted flip only the touched instances are re-listed, so an untouched partner of a new conflict can be missing from the list until the next full rescan.

**15. Significance and coverage are overclaimed in places.**

Location: lines 51, 52, 525.

"Which of the two holds decides how a self-locating pattern should be designed in the first place" (line 51) and "The result changes how such patterns should be designed" (line 525) claim more than a size comparison and a simulation can support. The paper's own camera results show that for large 5 x 5 tori distance 2 buys a guarantee rather than a large error reduction (lines 500 to 504). "This paper answers the question exactly for 3 x 3 windows and with bounds on both sides for 4 x 4 and 5 x 5" (line 52) is true, but the 5 x 5 bracket is 64-fold wide. The abstract should state that bracket (65,536 to 4,193,280) because it is the answer to the motivating question.

**16. References a de Bruijn and universal cycle reader would expect are missing, and so is the 1D analogue of Lemma 8.**

Location: Section 2, lines 98 to 103 and generally.

Framing the tori as packings of rotation orbits (lines 101 to 103) is good. It would be stronger if tied to universal cycles for restricted sets, and to decoding:
- F. Ruskey, J. Sawada, A. Williams, "De Bruijn sequences for fixed-weight binary strings", SIAM Journal on Discrete Mathematics 26(2):605 to 617, 2012, doi:10.1137/100808782 (existence confirmed by search). Universal cycles for a weight-restricted subset are the 1D counterpart of realizing the even-weight code of Remark 7.
- J. Sawada, A. Williams, D. Wong, "Generalizing the classic greedy and necklace constructions of de Bruijn sequences and universal cycles", Electronic Journal of Combinatorics 23(1), paper P1.24, 2016 (details from memory, not confirmed by search).
- B. Jackson, B. Stevens, G. Hurlbert, "Research problems on Gray codes and universal cycles", Discrete Mathematics 309(17):5341 to 5348, 2009 (existence confirmed).
- C. J. Mitchell, T. Etzion, K. G. Paterson, "A method for constructing decodable de Bruijn sequences", IEEE Transactions on Information Theory 42(5):1472 to 1478, 1996 (existence confirmed). Also cite Mitchell and Paterson, "Decoding perfect maps" (1994), which is already in refs.bib as `mitchellpaterson1994` but never cited, although decoders are part of the paper's argument.
- F. J. MacWilliams, N. J. A. Sloane, "Pseudo-random sequences and arrays", Proceedings of the IEEE 64(12):1715 to 1729, 1976, the classical source for 2D window arrays.

The 1D analogue of Lemma 8 deserves a sentence. In a cyclic binary sequence whose n-windows all have the same parity, consecutive windows give x_i = x_{i+n}, so the period divides n and the sequence holds at most n windows. In 2D the same argument only forces 5 | R and 5 | C. That contrast is direct evidence that overlap constrains 1D and 2D very differently, and it supports the paper's theme.

**17. The decode-speed claim is not supported by the timing data.**

Location: lines 465 to 466; `results/decode_timing.md`.

"Between 3.6 and 25 million lookups per second ... depending on table size" does not match the data. The 144-entry table (3 x 3, 6 x 6) ran at 6.3 million per second and the 324-entry table (9 x 9) at 24.9 million. The two 256 x 256 tables are the same size and ran at 3.6 and 8.8 million. Each figure is a single run of 200,000 decodes on a shared core. Report repeated timings or drop "depending on table size".

**18. Figure and table details.**

- Figure 1 caption: "no orientable torus can" contain all 2^25 windows contradicts line 191, which says a de Bruijn torus is 1-orientable. Say "no 2- or 4-orientable torus".
- The "x 16" arrow in Figure 1 compares two search results; label it as such.
- Figure 4: the annotation "the largest that exists" (see finding 1).
- `camera_robustness.csv` lists min_distance 3 for the XOR torus (the rmax = 2 cap, meaning at least 3), while Table 4 gives 5 (correct, from `xor_table.csv`). Label the column.
- Table 4 rounds 0.285 to 0.28 but 0.505 to 0.51.

**19. Statistical reporting.**

Give binomial confidence intervals for the camera proportions. For example, 193 of 26,043 single-error reads is 0.74 percent (95 percent interval about 0.64 to 0.85), consistent with the 0.78 percent density. For the 3 x 3 control, 16,255 of 25,404 is 64.0 percent (interval about 63.4 to 64.6), slightly above the 63.3 percent density, so "close to" is fair. State intervals for the wrong rates compared in lines 460 to 463.

**20. Course format, template residue and clarity.**

- The compiled PDF still prints the template's appendix instructions ("Delete assignment instructions (like these) before submitting your assignment", page 19).
- The course appendix contains "[Summary to be written by TJ.]".
- The author line reads "Student Number : 1374286".
- The 19:22 build prints Glucose pages as 399 to 404; `refs_check.md` says 399 to 403.
- Line 174, "about one hundred course papers", is unclear; say what these are.
- Line 495, "The research statement had hoped", refers to a document the reader does not have. Either summarize it or cite it as an appendix.
