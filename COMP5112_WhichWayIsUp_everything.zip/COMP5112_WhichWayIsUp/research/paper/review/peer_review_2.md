# Peer review 2: revision check for "Which Way Is Up? Orientation and Error Detection Compete in Binary Position Tori"

Reviewer: the same independent reviewer as peer review 1.
Reviewed: `paper/build/paper_draft2.pdf` (built 2026-11-09 20:50; main text, references and Appendix A; the course appendix after Appendix A was skipped), the revised sources in `paper/sections/` and `paper/figures/`, and the new or changed files in `results/` and `otorus/`. Line numbers are the LIPIcs line numbers printed in draft 2.

What I ran for this round:
- The test suite: 59 passed.
- My own turned-window checker on all 136 stored witnesses: all pass. Small tori got an exact minimum distance. Large tori got a check that the turned windows are distinct and, where distance 2 is claimed, that no two are at distance 1.
- The new DFS results compared with the shared-generator run: same status and node count on all 134 shapes.
- Table 3 and Table 4 recomputed from `grow_4x4.csv`, `grow_5x5.csv` and `camera_robustness.csv`, including the bracket ratios and the Wilson intervals: all match.
- Proposition 10 checked with my own CNF encoding (my own instance generator, totalizer, CaDiCaL), which agrees everywhere I tested it:
  - distance 2: widths 4 and 5 fill at length 6 and fail at length 7; width 6 fills at 8 and fails at 9; width 7 fills at 5 and fails at 6;
  - distance 1: width 4 fills at length 20.
- Open patches that wrap in neither direction, and the paper's own `dfs_strip` at widths 8 and 9 (finding A below).

On the witness count: in peer review 1 I saw 92 files in the copy I had. The current set has 136, and every one verifies.

## Summary of the revision

The revision deals with most of review 1, and with the most serious problems fully:
- Theorem 12 (formerly 11) is restricted to admissible labels. The 308-cell counterexample is reported, and the unrestricted family gets the correct cap of 512.
- The search comparison now uses equal flip budgets, five seeds for 4 x 4, and bracket-implied ranges for the ratio.
- The exhaustive search has its own instance generator, and every reported torus is stored and verified.
- The camera has a size-matched control and reports correct, rejected and wrong rates with intervals.
- Appendix A gives the details needed to rerun everything.
- New material: a definition of compose and compete, an open-strip proposition (Proposition 10), a lower bound of 85 for 3 x 3 orientation alone, and the 1D analogue of Lemma 8.

## Overall assessment

The paper is now much stronger and close to a clear A for a research methodology course. No critical issue remains. One new major issue comes from the new material. The paper reads Proposition 10 as showing that the extra cost of distance is local, arising "long before counting or wrap-around matters" (lines 356 to 357). That reading is contradicted by a simple control. Patches that do not wrap at all can be filled far beyond any strong-form torus. The strips die because they close on themselves in one direction. This sentence now carries the paper's mechanism claim in the abstract, introduction, Section 5, Discussion and Conclusion, so it must be fixed. The other major item is the AI-use and data statements, which still wait on the author (URL, what he checked himself, course policy).

Grade band as revised: A- to A. With finding A fixed, which needs one extra control computation and some rewording, and the author's TODOs filled in, I would expect a solid A. As before, how the instructor weighs the extent of AI involvement under the course policy is outside what I can judge.

Remaining issues: 0 critical, 2 major, 7 minor (findings A to H and J below; I is a record of checks, not an issue).

## Status of the findings from peer review 1

| No. | Finding (review 1) | Status | Note |
|---|---|---|---|
| 1 | Theorem 11 false as stated (interleave maximum) | Fixed | Now Theorems 11 and 12 with "admissible" labels; counterexample, cap 512 and decoder ambiguity stated (lines 401 to 438); Figure 4 corrected. Small leftovers in Figure 1 and `results/interleave.md`, see finding G. |
| 2 | Main claim stronger than the evidence | Partly fixed | Wording, the definition, "a hypothesis" in the Discussion, and "does not prove it" for the search ratios are all good. But the new strip evidence is misread (finding A), and the 3 x 3 verdict needs the threshold in finding D. |
| 3 | Search comparison not controlled | Fixed | Equal flip budgets, five seeds at 4 x 4, brackets 8.5 to 11.8 and 18 to 25 (checked), temperature listed as a limitation. Residual design note in finding C. |
| 4 | Verification claims did not match artifacts | Fixed | Own `turned_cells` in exhaustive.py, identical rerun, 136 stored tori, all verify independently. No DRAT certificates, which is acknowledged. |
| 5 | Camera tests a theorem; confounded control | Fixed | Size-matched 6 x 6 control; the single-error result is presented as a check; intervals added. Residual wording in finding E. |
| 6 | Preregistration framing | Partly fixed | Abstract and introduction now say both predictions failed; one definition is used throughout; deviations are listed (lines 604 to 610). "Exploratory" appears only in the Discussion (finding D). |
| 7 | Reproducibility gaps | Fixed | Appendix A covers versions, machines, limits, budgets, seeds and commands. The results README is stale (finding G). |
| 8 | Data and AI statements | Partly fixed, pending the author | Count, versions, the review and the BibTeX source are now disclosed. URL, the author's own checks and the course policy are still TODOs (finding B). |
| 9 | Wrong node-count claim in Section 5 | Fixed | Replaced by Proposition 10; `exact_3x3_strong_form.md` corrected. |
| 10 | Theorem 10 sketch gap | Fixed | Reversal closure stated; "at least 2" and the distinct-window sampling described accurately. |
| 11 | Ceiling section details | Fixed | Hall and Kőnig cited, Lemma 4 attribution, window code defined, "compose exactly at the level of codes" added, "lower bounds / not upper bounds" fixed. |
| 12 | 3 x 3 control stopped at 81 | Fixed | 4 x 21, 6 x 14 and 5 x 17 are satisfiable (checked); untried and undecided shapes are reported. |
| 13 | Decoders claimed, not demonstrated | Fixed | Now "described but not implemented or timed" (lines 445 to 447). |
| 14 | Search reading overstated | Fixed | Occupancy brackets given (checked); rescan explained. |
| 15 | Significance overclaimed | Fixed | Toned down and tied to the definition. |
| 16 | Missing references, 1D analogue | Partly fixed | Ruskey, Sawada and Williams cited; 1D analogue added (lines 297 to 301). Four entries were added to refs.bib but are never cited, so they do not print (finding H). |
| 17 | Decode speed | Fixed | Medians of five runs; no claim about table size. |
| 18 | Figure and table details | Mostly fixed | Figure 1 caption fixed; two labels inside the Figure 1 image remain (finding G). |
| 19 | Statistical reporting | Fixed | Wilson intervals in Table 4 and in the text (checked). |
| 20 | Template residue | Not fixed (left to the author) | Finding J. |

## Remaining and new findings

### Major

**A. (New) The open strips show an obstruction from closing up, not a local one. The paper's reading of Proposition 10 is contradicted by a control.**

Location: Abstract lines 13 to 15 ("Open strips point to a local cause"); Introduction lines 61 to 65 ("the obstruction comes from how neighbouring windows overlap and appears long before counting would stop a torus"); Section 5 lines 342 to 343 ("Third, the obstruction is local, which we show with open strips") and lines 356 to 357 ("in how a few neighbouring windows overlap, long before counting or wrap-around matters"); Discussion lines 569 to 572; Conclusion lines 615 to 616 ("open strips locate it in the overlap of neighbouring windows").

What is wrong: Proposition 10 itself is correct; I confirmed its distance-2 boundaries at widths 4, 5, 6 and 7, and the distance-1 width-4 case, with an independent encoding. But an open strip of width w wraps around its w columns. For 3 x 3 windows and w = 4 or 5, almost every window straddles the seam, so the strip mainly tests what happens when the pattern closes on itself. To check whether the cost really appears "long before wrap-around matters", the natural control is a patch that wraps in neither direction. It behaves very differently:
- With all four turns and distance 2, an open 9 x 8 patch can be filled. It has 7 x 6 = 42 window positions and 168 turned windows, all pairwise at distance at least 2. That is 70 percent of the 240-word code bound, and more than the 144 turned windows of the largest strong-form torus (36 cells). I found it with my own CNF and then checked every pair of turned windows by brute force (minimum distance 2):

```
0 1 1 1 0 1 1 1
1 0 0 1 1 0 1 1
0 0 0 1 0 0 1 1
1 0 1 0 1 1 0 0
1 0 0 1 1 0 1 1
1 1 0 0 1 0 0 0
0 0 0 1 1 0 1 0
1 0 0 1 1 0 1 1
1 1 0 0 1 0 0 0
```

- Open 8 x 8 (144 turned windows) and open 7 x 7 (100) can also be filled. A non-wrapping 20 x 4 strip (144 turned windows) can be filled at distance 2, while the wrapping width-4 strip already fails at length 7 with 80.
- With the paper's own `dfs_strip`, wrapping strips of width 8 fail at length 6 (128 turned windows) and width 9 at length 7 (180). So wrapping strips fail early at every width tried, while open patches of comparable or larger size can be filled.

So at 3 x 3 the extra cost does not come from how a few neighbouring windows overlap in an open region; local packing allows more windows than any torus holds. It appears when the pattern has to close on itself, even in one direction. The data also hint at an arithmetic effect like Lemma 8. For a 3 x 3 window, the same argument as Lemma 8 makes constant-parity tori need 3 | R and 3 | C. Widths 3 and 6 survive longest in Proposition 10 (lengths 17 and 9). Every satisfiable shape in Theorem 9 above 15 cells (3 x 6, 3 x 9, 3 x 12, 6 x 6) has both sides divisible by 3, and the 3 x 12 maximum has constant parity. This is an observation, not a proof, but it points to wrap-around rather than locality.

Fix: Add the open-patch control to Section 5 (it takes seconds with the existing encodings), and restate the mechanism. For example: "Distance 2 can be met far beyond the torus maximum in open patches; the obstruction appears as soon as the pattern must close on itself, even in one direction." Remove "local" and "long before ... wrap-around matters" from the abstract, introduction, Section 5, Discussion and Conclusion. The Discussion's test of the overlap hypothesis (lines 578 to 581) should then name closure or periodicity as the candidate cause. A bound in the style of Lemma 8 for 3 x 3 windows (constant parity forces 3 | R and 3 | C) is a natural next step to state.

**B. The AI-use and data statements still lack the parts only the author can supply.**

Location: Section 10, lines 635 to 652; LaTeX TODO comments in `sections/10_conclusion.tex` lines 11 and 15.

Improved: the stored-torus count is correct (136), Appendix A gives versions and commands, the BibTeX source and the review step are disclosed, and the wording is factual. Still missing, by design: a repository URL (or a statement that the repository is submitted with the paper), what the author personally checked, and the course AI policy the statement follows. Also, the statement names two models. I can confirm only that this review was produced by Claude Opus 5.5; the author should check the other model name against his own records. Until the TODOs are filled, a grader cannot tell how much of the verification the author did himself. This matters more now that the paper discloses that a theorem was corrected only because a review caught it.

Fix: The author fills in the TODOs before submission.

### Minor

**C. "Equal budgets" is equal flips, not equal effort per cell; the 5 x 5 seed counts differ.**

Location: Section 7, lines 451 to 452 and 470 to 472; Table 3.

At 5 x 5, 30 million flips spread over the 1,327,104 cells of the 1152 x 1152 torus is about 23 flips per cell. Over the 65,536 cells of 256 x 256 it is about 458. Orientation alone used one seed and the strong form two. Both choices favour the strong form, so the ratio of about 20 is, if anything, conservative. Say so in one sentence, so the reader knows the direction of the bias.

**D. The compose/compete definition has no threshold, and "exploratory" appears only in the Discussion.**

Location: Introduction lines 53 to 56 and 71 to 73; abstract lines 20 to 21; Discussion lines 557 to 561.

The definition says the requirements compose if the largest torus shrinks "by only about this factor" (2) and compete if it shrinks "by more". At 3 x 3 the ratio lies between 2.36 and 3.33, so the excess over the code factor is between 1.18 and 1.67. Whether 1.18 is "about" 1 is a judgement the definition leaves open. Report the excess as a measured quantity ("at least 18 percent beyond the code factor") rather than resting a binary verdict on an unstated threshold.

The abstract still calls the graded claim "what the evidence supports", and the introduction calls it "what the data support". Only the Discussion (line 558) says it was formed after seeing the data and is exploratory. Add "exploratory" to the abstract and introduction sentences.

Also: the refutation criterion on lines 580 to 581 ("refuted by a construction that brings strong-form tori to a constant fraction of the ceiling") would only bound the ratio by a constant. It would not refute a cost beyond the factor of 2, which is already shown at 3 x 3. State which hypothesis it tests: growth with window size.

**E. Camera wording: distance 2 makes multi-error reads worse, and the 6 x 6 control does not track its density.**

Location: Section 8, lines 523 to 535; abstract lines 18 to 20.

On reads with two or more wrong cells, the strong-form 6 x 6 torus was wrong on 3,636 of 9,502 (38.3 percent) and its orientation-only twin on 2,690 of 9,408 (28.6 percent). The intervals are far apart, so distance 2 increases wrong answers on multi-error reads by about a third. "It also does not protect reads with two or more wrong cells" (lines 531 to 532) understates this; say it plainly and offer a reason. A plausible one is that a code with no pairs at distance 1 has more pairs at distance 2, so two-error reads land on codes more often.

The size-matched control's single-error wrong rate is 22.9 percent (interval about 22.4 to 23.4) against a density of 28.1 percent, a clear shortfall. "Close to the density" (line 527) fits the 9 x 9 and 256 x 256 tori but not this one.

The abstract's "from 8.5 to 2.6 percent" holds at one noise level (sigma = 0.3); name it there, as the introduction does.

**F. Proposition 10 and the strip definition need tighter wording.**

Location: Section 5, lines 344 to 352; `otorus/exhaustive.py` and `scripts/run_strips.py` docstrings.

"Every window of such a strip is a window of any torus with w columns and at least L rows" is not what is meant. The correct statement is that the first L rows of any such torus form a strip of width w and length L, whose windows are windows of the torus at distinct positions. "Pairwise at distance delta" should read "at distance at least delta". Proposition 10 should say that all four turns are allowed (s = 4) and that it is a computational result from the exhaustive search, without certificates, as Theorem 9 does. Minor: Remark 7 now refers to itself ("the even-weight code of Remark 7", line 281).

**G. Stale evidence files and two figure labels contradict the revised paper.**

Location: `results/README.md`; `results/interleave.md`; Figure 1 image.
- `results/README.md` item 6 still gives the old search results (1024 x 1024, 20 x 20, "similar ball occupancy", "about 10 to at least 16").
- Its "Open at the end of Phase 3" list still gives 81 as the 3 x 3 orientation-only lower bound.
- Item 3a ends with "Data: sat_table.csv (rows u=3, s=4, delta=1). Witnesses: witnesses/u3v3s4d1_*.txt", which belongs to item 3.
- `results/interleave.md`, last paragraph, still says "392 cells is the family's counting cap and 280 its true maximum" without "admissible".
- The Figure 1 image still labels the interleave "Checkerboard interleave, largest" (it should say admissible, or mark 308 as the unrestricted lower bound) and the de Bruijn marker "not orientable" (it is 1-orientable; the caption already says "no 2- or 4-orientable torus").

The paper tells readers to use the README to find the evidence, so these should match the text.

**H. Four added references are never cited, so they do not print.**

Location: refs.bib; Section 2.

`mitchell1996decodable`, `macwilliamssloane1976`, `jackson2009research` and `mitchellpaterson1994` are in refs.bib, and the first two are listed as verified in refs_check.md, but none is cited, so the bibliography in draft 2 does not contain them. Cite Mitchell, Etzion and Paterson (1996) and Mitchell and Paterson (1994) where decoders are discussed (Section 6 or the Dothraki paragraph), MacWilliams and Sloane (1976) in the perfect-maps paragraph, and Jackson, Stevens and Hurlbert (2009) next to Chung, Diaconis and Graham. Alternatively, remove the entries.

**I. Not an issue: checks on the new numbers, all correct.**

These all match the result files: 85/36 = 2.36; 70.8 percent; brackets 8.5 to 11.8 and 18 to 25; occupancy ranges 0.16 to 0.20, 0.25 to 0.32, 0.20 to 0.23 and 0.46 to 0.50; 5.4 and 15.8 percent of ceiling; the Table 4 rates and Wilson intervals; 22.9 percent; the counts of 14 undecided shapes and 136 stored tori; 59 tests. One wording point: Table 3 says "Unsolved 72^2 (16 to 52)" for orientation alone at 4 x 4. Seeds 1 and 4 also failed at 64 x 64 (energies 4 and 2), which the "(3 of 5)" already implies. Nothing to fix.

**J. Template residue (left to the author).**

The course appendix still prints the template instructions ("Delete assignment instructions (like these) before submitting your assignment") right after Appendix A, and the author line still reads "Student Number : 1374286".
