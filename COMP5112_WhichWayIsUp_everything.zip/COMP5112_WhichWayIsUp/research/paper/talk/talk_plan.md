# 12-minute talk plan (Craft of Research ch. 16: claim with a sketch of the argument)

Shape: introduction in under two minutes (context, question, so what), main claim stated by slide 4, three reasons with one best piece of evidence each, the application, limits, conclusion with call for research, AI acknowledgment. Most important material first, so later slides can be skipped if time runs short. About one slide per minute. Speaker notes are cues, not a script.

| # | Slide (title is the claim) | Visual | Notes (cues) | Time |
|---|---|---|---|---|
| 1 | Which way is up? Orientation and error detection compete in binary position tori | title, name, course | One sentence: a camera reads a 5x5 patch of a printed bit pattern and must say where it is. | 0:20 |
| 2 | A printed bit pattern lets a camera find itself from one 5x5 patch | Dothraki-style torus sketch, window | De Bruijn torus: every 5x5 window once (Dothraki, 8192 x 4096). Two unknowns: how the camera is turned, whether a bit was misread. A de Bruijn torus fails both: turned or corrupted windows are other windows. | 1:00 |
| 3 | Two lines of work fix one problem each, and never met | two columns: orientable arrays (Burns and Mitchell 1993) / window distance (Berkowitz and Kopparty 2016) | Question: how large can a torus be with both? So what: compose (stack constraints like codes) or compete (pay in size). No example in print. | 1:00 |
| 4 | Answer: they compete, because windows overlap | fig_sizes | Main claim up front. Distance halves the counting ceiling, real cost is larger; still a 256 x 256 torus exists. | 1:00 |
| 5 | Strong form: every turned window differs from every other in two cells | fig_windows | Definition. Consequence: any single misread matches nothing, so it is rejected, never decoded wrongly. | 0:50 |
| 6 | Reason 1: counting halves the ceiling, and counting alone cannot do better | ceiling numbers 8,386,560 to 4,193,280; centre-flip picture | Centre-flip pairing for odd windows; Hall and Koenig for even. Even-weight windows reach the ceiling as a code, so any better bound must use overlap. | 1:10 |
| 7 | Reason 2: for 3x3 windows the exact answer is 36 cells, not 60 | fig_exact3x3 | 134 shapes, SAT plus exhaustive search agree. Orientation alone reaches at least 81: cost at least 2.25, more than counting's 2. | 1:10 |
| 8 | Reason 3: for larger windows the gap grows to 6 to 16 times | table: 64x64 vs 20x20; 1024x1024 vs 256x256 | Same local search, same budget. Search stops at similar crowding of each window's conflict ball; the ball is 1 + u^2 codes under distance 2. | 1:10 |
| 9 | Two algebraic families come with decoders, but stay small | fig_interleave | XOR: 36 cells, distance 5. Checkerboard interleave: 280 cells exact maximum, decode from two label words, table of at most 784 entries. | 1:00 |
| 10 | In a simulated camera, a single misread never gave a wrong position | fig_camera | 0 of 103,801 one-error reads from strong-form tori; orientation-only tori wrong at their density (64 percent at 3x3). Benefit largest where windows are dense, which is where distance costs most. | 1:10 |
| 11 | Both of our starting hypotheses failed, and the limits are real | two lines: H1 predicted 60, got 36; H2 predicted stall near 36, got 65,536 | Graded competition. Limits: search brackets from one method and few seeds; computational proofs without certificates; simulated camera; no Google Scholar. | 0:50 |
| 12 | Conclusion: ask for distance where density makes it pay | open problems list | Main point, significance for design and theory, open: 3x3 orientation-only (81 to 120), 4x4 strong (400 to 8,192), 5x5 strong (65,536 to 4,193,280), constant parity, distance 3. AI use acknowledgment; code and data available. | 1:00 |

Total about 11:40, leaving time for one question.
