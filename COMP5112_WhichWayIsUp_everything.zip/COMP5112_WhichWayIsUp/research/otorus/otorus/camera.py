"""Simulated camera reading a printed torus at an unknown rotation.

Model. The torus is printed with unit cells, cell (r, c) covering [r, r+1) x [c, c+1). The camera
looks at a u x u window whose top-left cell is (i0, j0), uniformly random, and is turned by k
quarter turns, k uniform in 0..3, plus a small in-plane angle. The reader is assumed to find the
grid lines, so it knows the rotation modulo 90 degrees up to an angle error, but not k; resolving
k is the job of orientability. It samples the u x u cell centres with that angle error and a grid
offset error, the image is blurred (Gaussian point spread, Monte Carlo) and noisy (Gaussian), and
each sample is thresholded at 0.5. The read array is the sampled window turned by k quarter turns,
so a perfect read equals np.rot90(window(T, i0, j0, u, u), k) and decodes to (i0, j0, k).

Parameters are in cell units (blur, offset), intensity units with black 0 and white 1 (noise),
and degrees (angle_deg); each is the standard deviation of a zero-mean Gaussian.
"""
import numpy as np


def simulate_reads(T, u, n, rng, blur=0.0, noise=0.0, angle_deg=0.0, offset=0.0, subsamples=16):
    """Return (reads (n, u, u) uint8, truth (n, 3) int64 as (i0, j0, k), n_err (n,) wrong cells)."""
    T = np.asarray(T, dtype=np.float64)
    R, C = T.shape
    i0 = rng.integers(0, R, n)
    j0 = rng.integers(0, C, n)
    k = rng.integers(0, 4, n)
    eps = np.deg2rad(rng.normal(0.0, angle_deg, n)) if angle_deg > 0 else np.zeros(n)
    delta = rng.normal(0.0, offset, (n, 2)) if offset > 0 else np.zeros((n, 2))

    m = (u - 1) / 2.0
    a, b = np.meshgrid(np.arange(u) - m, np.arange(u) - m, indexing="ij")      # local cell centres
    cos, sin = np.cos(eps)[:, None, None], np.sin(eps)[:, None, None]
    y = (i0 + u / 2.0)[:, None, None] + cos * a - sin * b + delta[:, 0, None, None]
    x = (j0 + u / 2.0)[:, None, None] + sin * a + cos * b + delta[:, 1, None, None]

    S = subsamples if blur > 0 else 1
    jit = rng.normal(0.0, blur, (2, n, u, u, S)) if blur > 0 else np.zeros((2, n, u, u, 1))
    yy = np.floor(y[..., None] + jit[0]).astype(np.int64) % R
    xx = np.floor(x[..., None] + jit[1]).astype(np.int64) % C
    intensity = T[yy, xx].mean(axis=-1)
    if noise > 0:
        intensity = intensity + rng.normal(0.0, noise, intensity.shape)
    sampled = (intensity > 0.5).astype(np.uint8)

    rows = (i0[:, None] + np.arange(u)) % R
    cols = (j0[:, None] + np.arange(u)) % C
    true_win = T[rows[:, :, None], cols[:, None, :]].astype(np.uint8)
    n_err = (sampled != true_win).reshape(n, -1).sum(axis=1)

    reads = np.empty_like(sampled)
    for t in range(4):
        sel = k == t
        reads[sel] = np.rot90(sampled[sel], t, axes=(1, 2))
    truth = np.stack([i0, j0, k], axis=1).astype(np.int64)
    return reads, truth, n_err
