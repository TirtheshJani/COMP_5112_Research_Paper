"""Counting ceilings for s-orientable binary tori with u x v windows.

delta = 1 (orientability only), Lemma 19 of Burns and Mitchell (1993): a window equal to its own
half turn cannot occur in a 2- or 4-orientable array (its turned copies would coincide), so
s*R*C <= 2^(uv) - fixed_by_rot180. Every window fixed by the quarter turn is also fixed by the
half turn, so the half-turn count is the one to subtract.

delta = 2 (strong form: all s*R*C turned windows pairwise at Hamming distance >= 2). The turned
windows form an independent set in the hypercube graph on the usable windows F (all windows when
s = 1, the windows not fixed by the half turn when s >= 2). Two cases:
  * u and v both odd. Flipping the centre cell commutes with every turn and fixes no window, so it
    is a perfect matching of F by hypercube edges and at most one window per pair is used:
    s*R*C <= |F| / 2.
  * otherwise. The half turn fixes no cell, so every half-turn-fixed window has even weight. All
    odd windows are then usable, and every even usable window has all uv of its neighbours (odd)
    in F, while odd windows have at most uv neighbours in F. Hall's condition gives a matching
    that saturates the even side, so by Koenig the largest independent set is the odd side:
    s*R*C <= 2^(uv - 1).
max_independent_free(u) computes the largest independent set directly for small square windows,
as a check on both arguments.
"""


def _cell_orbits(u, v, k):
    """Number of cell orbits of a u x v grid under rotation by k quarter turns (k = 1 or 2)."""
    seen = set()
    orbits = 0
    for i in range(u):
        for j in range(v):
            if (i, j) in seen:
                continue
            orbits += 1
            a, b = i, j
            for _ in range(4):
                seen.add((a, b))
                if k == 2:
                    a, b = u - 1 - a, v - 1 - b
                else:
                    a, b = v - 1 - b, a
    return orbits


def fixed_by_rot90(u):
    return 2 ** _cell_orbits(u, u, 1)


def fixed_by_rot180(u, v=None):
    v = u if v is None else v
    return 2 ** _cell_orbits(u, v, 2)


def even_fixed_by_rot180(u, v=None):
    """Half-turn-fixed windows of even weight. Orbit pairs contribute even weight, so the parity
    is set by the fixed centre cell when there is one (odd u and v), otherwise all are even."""
    v = u if v is None else v
    n = _cell_orbits(u, v, 2)
    return 2 ** (n - 1) if (u % 2 == 1 and v % 2 == 1) else 2 ** n


def ceiling(u, v, s, delta):
    """Upper bound on R*C. delta=1: orientability only (Lemma 19). delta=2: strong form."""
    if s not in (1, 2, 4):
        raise ValueError("s must be 1, 2 or 4")
    if s == 4 and u != v:
        raise ValueError("4-orientability needs square windows")
    total = 2 ** (u * v)
    usable = total if s == 1 else total - fixed_by_rot180(u, v)
    if delta == 1:
        return usable // s
    if delta == 2:
        if u % 2 == 1 and v % 2 == 1:
            return usable // (2 * s)
        return 2 ** (u * v - 1) // s
    raise ValueError("delta must be 1 or 2")


def max_independent_free(u):
    """Largest set of u x u windows, none fixed by the half turn, pairwise at Hamming distance >= 2.

    Computed as |F| minus a maximum matching of the bipartite (even/odd weight) hypercube graph on F
    (Koenig). Uses scipy; intended for u <= 4.
    """
    import numpy as np
    from scipy.sparse import csr_matrix
    from scipy.sparse.csgraph import maximum_bipartite_matching

    N = u * u
    codes = np.arange(2 ** N, dtype=np.int64)
    # Half turn of a row-major packed window = reversal of its N-bit code.
    rev = np.zeros_like(codes)
    for p in range(N):
        rev |= ((codes >> p) & 1) << (N - 1 - p)
    free = codes != rev
    weight = np.array([bin(c).count("1") for c in range(2 ** N)])
    even = codes[free & (weight % 2 == 0)]
    odd = codes[free & (weight % 2 == 1)]
    col_of = -np.ones(2 ** N, dtype=np.int64)
    col_of[odd] = np.arange(len(odd))
    rows, cols = [], []
    for r, c in enumerate(even):
        for p in range(N):
            k = col_of[c ^ (1 << p)]
            if k >= 0:
                rows.append(r)
                cols.append(k)
    B = csr_matrix((np.ones(len(rows), dtype=np.int8), (rows, cols)), shape=(len(even), len(odd)))
    match = maximum_bipartite_matching(B, perm_type="column")
    return int(free.sum()) - int((match >= 0).sum())
