"""Local search for large s-orientable binary tori with window distance >= delta.

State: the torus, the code of every turned window ("instance"), and a table cnt[code] holding how
many instances currently have that code. The energy is the number of unordered instance pairs at
Hamming distance below delta (equal codes, and for delta = 2 also codes one bit apart). A torus is
a solution exactly when its energy is 0; this includes windows equal to their own half turn, whose
two turned copies are an equal pair.

Instance q = (kk*R + i)*C + j is the window at (i, j) turned by the kk-th allowed rotation. Bit p
(row-major, most significant first) of its code is the torus cell (i + src[kk, p, 0], j + src[kk, p, 1])
taken mod (R, C), where src comes from np.rot90 of an index grid. Nothing larger than the code
table is stored, so tori with millions of cells fit in memory.

Flipping one cell changes s*u*u instance codes by one bit each. The energy change is computed
exactly by removing each affected instance from the table and adding it back with its new code,
one at a time. Moves: pick an instance that is in conflict, flip one of its cells at random, and
accept by the Metropolis rule at a fixed temperature (temp = 0 accepts only non-worsening moves).
"""
import numpy as np
from numba import njit

_ROT_K = {1: (0,), 2: (0, 2), 4: (0, 1, 2, 3)}


def _src_table(u, s):
    idx = np.arange(u * u).reshape(u, u)
    src = np.zeros((len(_ROT_K[s]), u * u, 2), dtype=np.int64)
    for kk, k in enumerate(_ROT_K[s]):
        rot = np.rot90(idx, k)
        for p in range(u * u):
            src[kk, p] = divmod(int(rot.flat[p]), u)
    return src


@njit(cache=True)
def _codes(T, R, C, src, nn):
    ns = src.shape[0]
    out = np.empty(ns * R * C, np.int64)
    for kk in range(ns):
        for i in range(R):
            for j in range(C):
                c = 0
                for p in range(nn):
                    c = (c << 1) | T[((i + src[kk, p, 0]) % R) * C + (j + src[kk, p, 1]) % C]
                out[(kk * R + i) * C + j] = c
    return out


@njit(cache=True)
def _ball(c, cnt, nn, delta):
    """Instances already in the table that would be in conflict with an instance of code c."""
    d = np.int64(cnt[c])
    if delta == 2:
        for k in range(nn):
            d += cnt[c ^ (1 << k)]
    return d


@njit(cache=True)
def _add(c, cnt, nn, delta):
    d = _ball(c, cnt, nn, delta)
    cnt[c] += 1
    return d


@njit(cache=True)
def _remove(c, cnt, nn, delta):
    cnt[c] -= 1
    return -_ball(c, cnt, nn, delta)


@njit(cache=True)
def _init_energy(codes, cnt, nn, delta):
    E = np.int64(0)
    for q in range(codes.shape[0]):
        E += _add(codes[q], cnt, nn, delta)
    return E


@njit(cache=True)
def _flip(x, T, codes, cnt, R, C, src, nn, delta):
    r = x // C
    c = x % C
    T[x] ^= 1
    dE = np.int64(0)
    for kk in range(src.shape[0]):
        for p in range(nn):
            i = (r - src[kk, p, 0]) % R
            j = (c - src[kk, p, 1]) % C
            q = (kk * R + i) * C + j
            old = codes[q]
            new = old ^ (np.int64(1) << (nn - 1 - p))
            dE += _remove(old, cnt, nn, delta)
            dE += _add(new, cnt, nn, delta)
            codes[q] = new
    return dE


@njit(cache=True)
def _in_conflict(c, cnt, nn, delta):
    if cnt[c] > 1:
        return True
    if delta == 2:
        for k in range(nn):
            if cnt[c ^ (1 << k)] > 0:
                return True
    return False


@njit(cache=True)
def _run(T, codes, cnt, R, C, src, nn, delta, E, max_flips, temp, seed, rescan_every):
    np.random.seed(seed)
    n_inst = codes.shape[0]
    L = np.empty(n_inst, np.int64)
    inL = np.zeros(n_inst, np.bool_)
    nL = 0
    flips = 0
    last_scan = -1
    while E > 0 and flips < max_flips:
        # Full rescans: after an accepted flip only touched instances are added, so a conflict can
        # be listed from one side only; a periodic scan adds the other partner as well.
        if nL == 0 or (flips % rescan_every == 0 and flips != last_scan):
            last_scan = flips
            for q in range(n_inst):
                if not inL[q] and _in_conflict(codes[q], cnt, nn, delta):
                    L[nL] = q
                    inL[q] = True
                    nL += 1
            if nL == 0:
                break
        idx = np.random.randint(nL)
        q = L[idx]
        if not _in_conflict(codes[q], cnt, nn, delta):
            nL -= 1
            L[idx] = L[nL]
            inL[q] = False
            continue
        kk = q // (R * C)
        i = (q // C) % R
        j = q % C
        p = np.random.randint(nn)
        x = ((i + src[kk, p, 0]) % R) * C + (j + src[kk, p, 1]) % C
        dE = _flip(x, T, codes, cnt, R, C, src, nn, delta)
        flips += 1
        if dE <= 0 or (temp > 0 and np.random.random() < np.exp(-dE / temp)):
            E += dE
            r0 = x // C
            c0 = x % C
            for k2 in range(src.shape[0]):
                for p2 in range(nn):
                    q2 = (k2 * R + (r0 - src[k2, p2, 0]) % R) * C + (c0 - src[k2, p2, 1]) % C
                    if not inL[q2] and _in_conflict(codes[q2], cnt, nn, delta):
                        L[nL] = q2
                        inL[q2] = True
                        nL += 1
        else:
            _flip(x, T, codes, cnt, R, C, src, nn, delta)
    return E, flips


class SearchState:
    """A torus with its instance codes, code table and energy, kept exact under flips."""

    def __init__(self, T, u, s, delta):
        T = np.asarray(T)
        self.R, self.C = T.shape
        self.u, self.s, self.delta, self.nn = u, s, delta, u * u
        self.src = _src_table(u, s)
        self.T = T.ravel().astype(np.int64)
        self.codes = _codes(self.T, self.R, self.C, self.src, self.nn)
        self.cnt = np.zeros(1 << self.nn, dtype=np.uint16)
        self.energy = int(_init_energy(self.codes, self.cnt, self.nn, delta))

    def flip(self, x):
        self.energy += int(_flip(x, self.T, self.codes, self.cnt, self.R, self.C, self.src, self.nn, self.delta))

    def run(self, max_flips, temp, seed, rescan_every=50_000):
        E, flips = _run(self.T, self.codes, self.cnt, self.R, self.C, self.src, self.nn, self.delta,
                        self.energy, max_flips, temp, seed, rescan_every)
        self.energy = int(E)
        return int(flips)

    def torus(self):
        return self.T.reshape(self.R, self.C).astype(np.uint8)


def energy(T, u, s, delta):
    """Number of turned-window pairs at distance below delta, computed directly (no table updates)."""
    from collections import Counter
    from .windows import packed_turned_windows
    mult = Counter(packed_turned_windows(T, u, u, s))
    E = sum(m * (m - 1) // 2 for m in mult.values())
    if delta == 2:
        E += sum(m * mult.get(c ^ (1 << k), 0) for c, m in mult.items() for k in range(u * u)) // 2
    return E


def local_search(R, C, u, s, delta, seed=0, max_flips=10**7, temp=0.5, T0=None):
    """Search for an R x C torus; returns (torus, final energy, flips used). Energy 0 = solution."""
    rng = np.random.default_rng(seed)
    T = rng.integers(0, 2, size=(R, C)) if T0 is None else np.asarray(T0)
    st = SearchState(T, u, s, delta)
    flips = st.run(max_flips, temp, seed)
    return st.torus(), st.energy, flips
