"""Constructions of orientable arrays from sequences."""
import numpy as np


def construction_e(A, B, d):
    """Burns and Mitchell Construction E: e[i][j] = d*a[i] + b[j], d = alphabet size of B."""
    A = np.asarray(A, dtype=int)
    B = np.asarray(B, dtype=int)
    return d * A[:, None] + B[None, :]


def xor_torus(A, B):
    """Binary torus e[i][j] = a[i] xor b[j] (Construction E over GF(2) collapsed to one bit)."""
    A = np.asarray(A, dtype=np.uint8)
    B = np.asarray(B, dtype=np.uint8)
    return A[:, None] ^ B[None, :]


def interleave_checkerboard(A, B):
    """Binary interleave of two sequences: cell (i, j) carries a[i] when i + j is even, b[j] when odd.

    A quarter turn maps each checkerboard class of an odd window to itself, so a turned window shows
    its row labels along columns; this is the binary counterpart of Construction E's label pairs.
    Both periods must be even for the colouring to be well defined on the torus.
    """
    A = np.asarray(A, dtype=np.uint8)
    B = np.asarray(B, dtype=np.uint8)
    if len(A) % 2 or len(B) % 2:
        raise ValueError("both periods must be even")
    i = np.arange(len(A))[:, None]
    j = np.arange(len(B))[None, :]
    return np.where((i + j) % 2 == 0, A[:, None], B[None, :]).astype(np.uint8)


def random_window_cycle(n, L, banned, rng, max_tries=200, node_budget=20000):
    """A random cyclic binary sequence of period L whose n-windows are distinct and not in `banned`
    (strings of '0'/'1'), found by randomized depth-first search in the de Bruijn graph; None if
    no cycle was found within max_tries restarts."""
    import sys
    sys.setrecursionlimit(max(1000, 4 * (L + n)))
    for _ in range(max_tries):
        start = [int(x) for x in rng.integers(0, 2, n - 1)]
        seq, used, nodes = list(start), set(), [0]

        def extend():
            nodes[0] += 1
            if nodes[0] > node_budget:
                return False
            t = len(seq)
            if t == L + n - 1:
                return seq[L:] == start
            options = [0, 1]
            rng.shuffle(options)
            for bit in options:
                if t >= L and bit != start[t - L]:
                    continue  # the last n-1 bits must repeat the first n-1 to close the cycle
                w = "".join(map(str, seq[t - n + 1:])) + str(bit)
                if w in used or w in banned:
                    continue
                used.add(w)
                seq.append(bit)
                if extend():
                    return True
                seq.pop()
                used.discard(w)
            return False

        if extend():
            return np.array(seq[:L], dtype=np.uint8)
    return None


INTERLEAVE_BANNED = ("00000", "11111", "01010", "10101")


def interleave_descriptors(R, C):
    """Type-0 turned windows of interleave_checkerboard(A, B) as pairs of label words.

    For 5 x 5 windows, a turned window whose even-colour class is constant along rows is fully
    described by (labels along the even-class rows, labels along the odd-class columns). Returns an
    int array (2RC, 2, 5) of indices into the label vector [a_0..a_{R-1}, b_0..b_{C-1}]:
      window (i, j) with i + j even, turned 0:   (A_i, B_j);   turned 2: (rev A_i, rev B_j)
      window (i, j) with i + j odd,  turned 1:   (rev B_j, A_i); turned 3: (B_j, rev A_i)
    where A_i = (a_i, ..., a_{i+4}). The other 2RC turned windows are quarter turns of these.
    """
    a = lambda x: x % R
    b = lambda y: R + y % C
    D = []
    for i in range(R):
        for j in range(C):
            if (i + j) % 2 == 0:
                D.append(([a(i + t) for t in range(5)], [b(j + t) for t in range(5)]))
                D.append(([a(i + 4 - t) for t in range(5)], [b(j + 4 - t) for t in range(5)]))
            else:
                D.append(([b(j + 4 - t) for t in range(5)], [a(i + t) for t in range(5)]))
                D.append(([b(j + t) for t in range(5)], [a(i + 4 - t) for t in range(5)]))
    return np.array(D, dtype=np.int64)


def solve_interleave(R, C, timeout=600, fix_a=None):
    """Find label sequences A (period R) and B (period C), both even, avoiding INTERLEAVE_BANNED,
    whose checkerboard interleave is 4-orientable for 5 x 5 windows (hence window distance >= 2).

    Exact: the interleave is 4-orientable iff its 2RC type-0 descriptors are distinct (see
    interleave_descriptors and tests/test_construct.py). Each label word is one of the 28 allowed
    words, so 2RC > 28^2 = 784 is impossible by counting. Returns (status, A, B).
    """
    import time
    from pysat.solvers import Cadical153

    if R % 2 or C % 2:
        raise ValueError("both periods must be even")
    if 2 * R * C > 28 * 28:
        return "UNSAT", None, None
    n = R + C
    clauses, diff, top = [], {}, [n]

    def d(x, y):
        x, y = int(x), int(y)
        key = (min(x, y), max(x, y))
        if key not in diff:
            top[0] += 1
            z, p, q = top[0], key[0] + 1, key[1] + 1
            clauses.extend([[-z, p, q], [-z, -p, -q], [z, -p, q], [z, p, -q]])
            diff[key] = z
        return diff[key]

    for start, period in ((0, R), (R, C)):
        for i in range(period):
            cells = [start + (i + t) % period for t in range(5)]
            for w in INTERLEAVE_BANNED:
                clauses.append([cells[t] + 1 if w[t] == "0" else -(cells[t] + 1) for t in range(5)])
    if fix_a is not None:  # optional: pin the row sequence A, leaving only B to be found
        clauses.extend([[x + 1] if bit else [-(x + 1)] for x, bit in enumerate(fix_a)])
    D = interleave_descriptors(R, C)
    for p in range(len(D)):
        for q in range(p + 1, len(D)):
            terms = [d(x, y) for x, y in zip(D[p].ravel(), D[q].ravel()) if x != y]
            if not terms:
                return "UNSAT", None, None
            clauses.append(terms)
    with Cadical153(bootstrap_with=clauses) as solver:
        t0 = time.time()
        solver.conf_budget(50_000)
        while True:
            res = solver.solve_limited()
            if res is True:
                model = set(x for x in solver.get_model() if x > 0)
                v = np.array([1 if x + 1 in model else 0 for x in range(n)], dtype=np.uint8)
                return "SAT", v[:R], v[R:]
            if res is False:
                return "UNSAT", None, None
            if time.time() - t0 > timeout:
                return "TIMEOUT", None, None
            solver.conf_budget(50_000)


def xor_descriptors(R, C):
    """The 4RC turned 5 x 5 windows of xor_torus(A, B) as pairs of label words.

    A window x_p xor y_q is determined by (x, y) up to complementing both. Its quarter turns are
    (rev y, x), (rev x, rev y) and (y, rev x). Returns an int array (4RC, 2, 5) of indices into
    [a_0..a_{R-1}, b_0..b_{C-1}]; the torus is 4-orientable iff no two descriptors are equal or
    complementary.
    """
    a = lambda x: x % R
    b = lambda y: R + y % C
    D = []
    for i in range(R):
        for j in range(C):
            Ai = [a(i + t) for t in range(5)]
            Bj = [b(j + t) for t in range(5)]
            D += [(Ai, Bj), (Bj[::-1], Ai), (Ai[::-1], Bj[::-1]), (Bj, Ai[::-1])]
    return np.array(D, dtype=np.int64)


def xor_descriptors_distinct(A, B):
    v = np.concatenate([np.asarray(A, dtype=np.uint8), np.asarray(B, dtype=np.uint8)])
    seen = set()
    for d in xor_descriptors(len(A), len(B)):
        w = v[d].ravel()
        key = tuple((w ^ w[0]).tolist())  # canonical up to complementing both words
        if key in seen:
            return False
        seen.add(key)
    return True


def solve_xor(R, C, timeout=600):
    """Exact search for A (period R), B (period C) with xor_torus(A, B) 4-orientable (5 x 5).
    Every two descriptors must be neither equal nor complementary. Returns (status, A, B)."""
    import time
    from pysat.solvers import Cadical153

    if 4 * R * C > 512 - 32:
        return "UNSAT", None, None  # the XOR window family has 480 usable windows
    n = R + C
    clauses, diff, top = [[-1]], {}, [n]  # a_0 = 0: complementing A complements the torus, a symmetry

    def d(x, y):
        x, y = int(x), int(y)
        key = (min(x, y), max(x, y))
        if key not in diff:
            top[0] += 1
            z, p, q = top[0], key[0] + 1, key[1] + 1
            clauses.extend([[-z, p, q], [-z, -p, -q], [z, -p, q], [z, p, -q]])
            diff[key] = z
        return diff[key]

    D = xor_descriptors(R, C)
    for p in range(len(D)):
        P = D[p].ravel()
        for q in range(p + 1, len(D)):
            Q = D[q].ravel()
            same = [x == y for x, y in zip(P, Q)]
            terms = [d(x, y) for x, y, s in zip(P, Q, same) if not s]
            if not terms:
                return "UNSAT", None, None
            clauses.append(terms)                       # not equal
            if not any(same):
                clauses.append([-z for z in terms])     # not complementary
    with Cadical153(bootstrap_with=clauses) as solver:
        t0 = time.time()
        solver.conf_budget(50_000)
        while True:
            res = solver.solve_limited()
            if res is True:
                model = set(x for x in solver.get_model() if x > 0)
                v = np.array([1 if x + 1 in model else 0 for x in range(n)], dtype=np.uint8)
                return "SAT", v[:R], v[R:]
            if res is False:
                return "UNSAT", None, None
            if time.time() - t0 > timeout:
                return "TIMEOUT", None, None
            solver.conf_budget(50_000)
