"""Windows of a doubly periodic array, their rotations, orientability and window distance.

Conventions (see research/notes/CONTEXT.md): T is an R x C array read modulo R and C.
The u x v window at (i, j) has its top-left cell at row i, column j. rotations(W) returns
W turned by 0, 90, 180, 270 degrees in that order (numpy rot90 convention, counterclockwise).
An array is s-orientable (s in {1, 2, 4}) when the s*R*C turned windows are pairwise distinct.
"""
import numpy as np

_ROT_K = {1: (0,), 2: (0, 2), 4: (0, 1, 2, 3)}


def window(T, i, j, u, v):
    T = np.asarray(T)
    R, C = T.shape
    rows = [(i + a) % R for a in range(u)]
    cols = [(j + b) % C for b in range(v)]
    return T[np.ix_(rows, cols)]


def all_windows(T, u, v):
    T = np.asarray(T)
    R, C = T.shape
    return [window(T, i, j, u, v) for i in range(R) for j in range(C)]


def rotations(W, s=4):
    return [np.rot90(W, k) for k in _ROT_K[s]]


def pack(W):
    """Row-major bits of a 0/1 array as a Python int (first cell is the most significant bit)."""
    out = 0
    for b in np.asarray(W, dtype=np.uint8).ravel():
        out = (out << 1) | int(b)
    return out


def packed_turned_windows(T, u, v, s):
    """All s*R*C turned windows, packed. Non-binary arrays are packed symbol by symbol via tuples."""
    T = np.asarray(T)
    binary = T.max() <= 1
    out = []
    for W in all_windows(T, u, v):
        for X in rotations(W, s):
            out.append(pack(X) if binary else tuple(X.ravel().tolist()))
    return out


def is_orientable(T, u, v, s):
    T = np.asarray(T)
    R, C = T.shape
    codes = packed_turned_windows(T, u, v, s)
    return len(set(codes)) == s * R * C


def min_window_distance(T, u, v, s=1):
    """Minimum Hamming distance between two distinct turned windows (binary T only).

    Returns 0 if some turned windows coincide (so the array is not s-orientable).
    Brute force over all pairs; intended for R*C*s up to a few thousand.
    """
    codes = packed_turned_windows(T, u, v, s)
    if len(set(codes)) != len(codes):
        return 0
    best = u * v
    for a in range(len(codes)):
        x = codes[a]
        for b in range(a + 1, len(codes)):
            d = bin(x ^ codes[b]).count("1")
            if d < best:
                best = d
                if best == 1:
                    return 1
    return best


def turned_window_codes(T, u, s):
    """Packed codes of all s*R*C turned u x u windows, vectorized with np.roll (for large tori).

    Written independently of the search code: the code of the k-quarter-turned window at (i, j)
    has, at row-major position (a, b), the cell of the upright window that np.rot90 moves there.
    """
    T = np.asarray(T, dtype=np.int64)
    nn = u * u
    idx = np.arange(nn).reshape(u, u)
    out = []
    for k in _ROT_K[s]:
        src = np.rot90(idx, k)
        code = np.zeros_like(T)
        for a in range(u):
            for b in range(u):
                sa, sb = divmod(int(src[a, b]), u)
                code |= np.roll(T, (-sa, -sb), axis=(0, 1)) << (nn - 1 - (a * u + b))
        out.append(code.ravel())
    return np.concatenate(out)


def min_distance_fast(T, u, s, rmax=2):
    """Exact minimum distance between distinct turned windows if it is at most rmax, else rmax + 1.

    Returns 0 if two turned windows coincide. Checks every code against all codes within Hamming
    radius r (r = 1..rmax) by sorted lookup, so it scales to tori with millions of windows.
    """
    from itertools import combinations
    codes = turned_window_codes(T, u, s)
    uniq = np.unique(codes)
    if len(uniq) < len(codes):
        return 0
    for r in range(1, rmax + 1):
        for bits in combinations(range(u * u), r):
            mask = sum(1 << b for b in bits)
            probe = uniq ^ mask
            pos = np.searchsorted(uniq, probe)
            pos[pos == len(uniq)] = 0
            if np.any(uniq[pos] == probe):
                return r
    return rmax + 1
