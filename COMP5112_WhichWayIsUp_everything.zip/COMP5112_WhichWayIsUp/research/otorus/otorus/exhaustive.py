"""Exhaustive depth-first search for s-orientable binary tori with window distance >= delta.

Independent of the SAT encodings in sat.py, including the bookkeeping of which cells each turned
window reads (turned_cells below uses explicit index arithmetic, not np.rot90 or sat._instances).
Cells are assigned in row-major order, and each turned window is checked the moment its last cell
is assigned, against a table of the turned windows already placed (equal code, or for delta = 2
any code one bit away, is a conflict). Cell 0 is fixed to 0, which is safe because complementing a
torus preserves orientability and distances.

dfs_strip runs the same search on an open strip: R rows that do not wrap and C columns that do. The
first R rows of any torus with C columns and at least R rows form such a strip, and its windows are
windows of the torus at distinct positions, so if the strip has no valid filling, no such torus
exists for any number of rows >= R. dfs_patch searches a patch that wraps in neither direction.
"""
import numpy as np
from numba import njit

_TURNS = {1: (0,), 2: (0, 2), 4: (0, 1, 2, 3)}


def turned_cells(R, C, u, s, wrap_rows=True, wrap_cols=True):
    """Cell indices (row*C + col) read by every turned u x u window, one list per instance.

    The quarter turn is (rho W)[a][b] = W[b][u-1-a], so position (a, b) of rho^k W reads window
    position f^k(a, b) with f(a, b) = (b, u-1-a). Rows (columns) wrap unless wrap_rows (wrap_cols)
    is False, in which case only windows that fit inside the R rows (C columns) are listed.
    """
    starts = range(R) if wrap_rows else range(R - u + 1)
    col_starts = range(C) if wrap_cols else range(C - u + 1)
    out = []
    for i in starts:
        for j in col_starts:
            for k in _TURNS[s]:
                cells = []
                for a in range(u):
                    for b in range(u):
                        x, y = a, b
                        for _ in range(k):
                            x, y = y, u - 1 - x
                        cells.append(((i + x) % R) * C + (j + y) % C)
                out.append(cells)
    return out


@njit(cache=True)
def _code(bits, cells, nn):
    c = 0
    for p in range(nn):
        c = (c << 1) | bits[cells[p]]
    return c


@njit(cache=True)
def _dfs(N, nn, inst_cells, comp_ptr, comp_list, delta, max_nodes):
    bits = np.zeros(N, np.int64)
    seen = np.zeros(1 << nn, np.uint8)
    val = np.full(N, -1, np.int64)
    inserted = np.zeros(N, np.bool_)
    t = 0
    nodes = 0
    while True:
        if t == N:
            return 1, bits, nodes
        if inserted[t]:
            for idx in range(comp_ptr[t], comp_ptr[t + 1]):
                seen[_code(bits, inst_cells[comp_list[idx]], nn)] = 0
            inserted[t] = False
        nxt = val[t] + 1
        if nxt > (0 if t == 0 else 1):
            val[t] = -1
            t -= 1
            if t < 0:
                return 0, bits, nodes
            continue
        val[t] = nxt
        bits[t] = nxt
        nodes += 1
        if max_nodes > 0 and nodes > max_nodes:
            return 2, bits, nodes
        ok = True
        done = comp_ptr[t]
        for idx in range(comp_ptr[t], comp_ptr[t + 1]):
            c = _code(bits, inst_cells[comp_list[idx]], nn)
            bad = seen[c] != 0
            if delta == 2 and not bad:
                for k in range(nn):
                    if seen[c ^ (1 << k)] != 0:
                        bad = True
                        break
            if bad:
                ok = False
                break
            seen[c] = 1
            done = idx + 1
        if ok:
            inserted[t] = True
            t += 1
        else:
            for idx in range(comp_ptr[t], done):
                seen[_code(bits, inst_cells[comp_list[idx]], nn)] = 0


def dfs_search(R, C, u, v, s, delta, max_nodes=0):
    """Return (status, torus or None, nodes) with status "SAT", "UNSAT" or "LIMIT".

    For square windows the search runs on the transposed shape when C > R, so that rows are short
    and windows complete early. Transposing a torus maps its turned windows to the transposes of
    turned windows, which preserves distinctness and Hamming distances, so the answer is the same.
    """
    if u == v and C > R:
        status, T, nodes = dfs_search(C, R, u, v, s, delta, max_nodes)
        return status, (None if T is None else np.ascontiguousarray(T.T)), nodes
    if u != v:
        raise ValueError("square windows only")
    return _run(R, C, u, s, delta, max_nodes, turned_cells(R, C, u, s))


def dfs_strip(R, C, u, s, delta, max_nodes=0):
    """Search an open strip of R rows (no wrap) by C columns (wrapping); same statuses as dfs_search."""
    return _run(R, C, u, s, delta, max_nodes, turned_cells(R, C, u, s, wrap_rows=False))


def dfs_patch(R, C, u, s, delta, max_nodes=0):
    """Search an open R x C patch that wraps in neither direction; same statuses as dfs_search."""
    return _run(R, C, u, s, delta, max_nodes, turned_cells(R, C, u, s, wrap_rows=False, wrap_cols=False))


def _run(R, C, u, s, delta, max_nodes, cells):
    v = u
    inst_cells = np.array(cells, dtype=np.int64)
    finish = inst_cells.max(axis=1)
    order = np.argsort(finish, kind="stable")
    comp_ptr = np.searchsorted(finish[order], np.arange(R * C + 1), side="left").astype(np.int64)
    status, bits, nodes = _dfs(R * C, u * v, inst_cells, comp_ptr, order.astype(np.int64), delta, max_nodes)
    if status == 1:
        return "SAT", bits.reshape(R, C).astype(np.uint8), int(nodes)
    return ("UNSAT" if status == 0 else "LIMIT"), None, int(nodes)
