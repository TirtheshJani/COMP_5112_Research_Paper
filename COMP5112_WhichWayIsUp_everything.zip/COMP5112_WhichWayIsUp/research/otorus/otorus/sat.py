"""Exact search for s-orientable binary tori with window distance >= delta, by SAT.

Encoding: one variable per cell of the R x C torus. Every turned window is a list of u*v cell
variables (window at (i, j), rotated k quarter turns, read row-major). For each unordered pair
of turned windows, the two must differ in at least delta cells. A shared auxiliary d(a, b) means
"cell a != cell b" (four clauses). delta = 1: one clause OR d. delta = 2: for each position t,
OR of the d's at the other positions (at least one other difference). Cell 0 is fixed to 0 to
break the complement symmetry.
"""
import time
import numpy as np
from pysat.solvers import Cadical153

from .windows import rotations


def _instances(R, C, u, v, s):
    """List of (i, j, k, cells): cells are the cell indices (row*C+col) of the turned window."""
    idx = np.arange(R * C).reshape(R, C)
    out = []
    ks = {1: (0,), 2: (0, 2), 4: (0, 1, 2, 3)}[s]
    for i in range(R):
        for j in range(C):
            rows = [(i + a) % R for a in range(u)]
            cols = [(j + b) % C for b in range(v)]
            W = idx[np.ix_(rows, cols)]
            for k in ks:
                out.append((i, j, k, [int(x) for x in np.rot90(W, k).ravel()]))
    return out


def encode(R, C, u, v, s, delta):
    """Return (clauses, n_vars). Cell (r, c) is variable r*C + c + 1."""
    n = R * C
    clauses = [[-1]]  # cell 0 = 0
    diff = {}
    nxt = [n]

    def d(a, b):
        if a == b:
            return None
        key = (a, b) if a < b else (b, a)
        if key not in diff:
            nxt[0] += 1
            z = nxt[0]
            xa, xb = key[0] + 1, key[1] + 1
            # z <-> (xa xor xb)
            clauses.extend([[-z, xa, xb], [-z, -xa, -xb], [z, -xa, xb], [z, xa, -xb]])
            diff[key] = z
        return diff[key]

    inst = _instances(R, C, u, v, s)
    for p in range(len(inst)):
        for q in range(p + 1, len(inst)):
            ds = [d(a, b) for a, b in zip(inst[p][3], inst[q][3])]
            ds = [z for z in ds if z is not None]
            if len(ds) < delta:
                return None, 0  # two turned windows share too many cells: trivially UNSAT
            if delta == 1:
                clauses.append(ds)
            elif delta == 2:
                for t in range(len(ds)):
                    clauses.append(ds[:t] + ds[t + 1:])
            else:
                raise ValueError("delta must be 1 or 2")
    return clauses, nxt[0]


def solve_torus(R, C, u, v, s, delta, timeout=60):
    """Return ("SAT", torus) | ("UNSAT", None) | ("TIMEOUT", None)."""
    clauses, nv = encode(R, C, u, v, s, delta)
    if clauses is None:
        return "UNSAT", None
    with Cadical153(bootstrap_with=clauses) as solver:
        t0 = time.time()
        # Cadical has no wall-clock budget in pysat; use conflict budget as a proxy and check time.
        solver.conf_budget(50_000)
        while True:
            res = solver.solve_limited()
            if res is True:
                model = set(x for x in solver.get_model() if x > 0)
                T = np.array([[1 if r * C + c + 1 in model else 0 for c in range(C)] for r in range(R)], dtype=np.uint8)
                return "SAT", T
            if res is False:
                return "UNSAT", None
            if time.time() - t0 > timeout:
                return "TIMEOUT", None
            solver.conf_budget(50_000)


def solve_torus_alt(R, C, u, v, s, delta, timeout=600):
    """Second, independently written encoding, used only to cross-check solve_torus.

    Differences from encode(): a fresh XOR auxiliary for every position of every pair (nothing
    shared), "differ in at least delta positions" through pysat's sequential-counter cardinality
    encoding, no symmetry breaking, and the Glucose 4 solver instead of CaDiCaL.
    Returns ("SAT", torus) | ("UNSAT", None) | ("TIMEOUT", None).
    """
    from pysat.card import CardEnc, EncType
    from pysat.solvers import Glucose4

    n = R * C
    top = n
    clauses = []
    inst = _instances(R, C, u, v, s)
    for p in range(len(inst)):
        for q in range(p + 1, len(inst)):
            ys = []
            for a, b in zip(inst[p][3], inst[q][3]):
                if a == b:
                    continue  # same cell in both windows: this position can never differ
                top += 1
                y, xa, xb = top, a + 1, b + 1
                clauses += [[-y, xa, xb], [-y, -xa, -xb], [y, -xa, xb], [y, xa, -xb]]
                ys.append(y)
            if len(ys) < delta:
                return "UNSAT", None
            card = CardEnc.atleast(lits=ys, bound=delta, top_id=top, encoding=EncType.seqcounter)
            clauses += card.clauses
            top = max(top, card.nv)
    with Glucose4(bootstrap_with=clauses) as solver:
        t0 = time.time()
        solver.conf_budget(50_000)
        while True:
            res = solver.solve_limited()
            if res is True:
                model = set(x for x in solver.get_model() if x > 0)
                T = np.array([[1 if r * C + c + 1 in model else 0 for c in range(C)] for r in range(R)], dtype=np.uint8)
                return "SAT", T
            if res is False:
                return "UNSAT", None
            if time.time() - t0 > timeout:
                return "TIMEOUT", None
            solver.conf_budget(50_000)
