"""Table decoder: a read u x u window -> (row, column, quarter turns), or None if it is not a window.

The table is the sorted list of all s*R*C turned-window codes of the torus (turned_window_codes),
so memory is linear in the torus size and lookups are binary searches. For an s-orientable torus
every code occurs once, so a hit names exactly one position and one rotation. For a torus with
window distance >= 2, a read with one wrong cell is never a code in the table.
"""
import numpy as np

from .windows import turned_window_codes, _ROT_K


class Decoder:
    def __init__(self, T, u, s=4):
        T = np.asarray(T)
        self.R, self.C = T.shape
        self.u, self.ks = u, _ROT_K[s]
        codes = turned_window_codes(T, u, s)
        self.order = np.argsort(codes, kind="stable")
        self.table = codes[self.order]
        if np.any(self.table[1:] == self.table[:-1]):
            raise ValueError("torus is not s-orientable: two turned windows coincide")
        self.weights = (1 << np.arange(u * u - 1, -1, -1)).astype(np.int64)

    def _locate(self, q):
        rc = self.R * self.C
        return int(q % rc // self.C), int(q % self.C), int(self.ks[q // rc])

    def decode_batch(self, Ws):
        """Ws: array (n, u, u) of 0/1. Returns int array (n, 3) of (row, col, turns), -1 where no match."""
        codes = np.asarray(Ws, dtype=np.int64).reshape(len(Ws), -1) @ self.weights
        pos = np.searchsorted(self.table, codes)
        pos[pos == len(self.table)] = 0
        hit = self.table[pos] == codes
        q = self.order[pos]
        rc = self.R * self.C
        out = np.stack([q % rc // self.C, q % self.C, np.asarray(self.ks)[q // rc]], axis=1)
        out[~hit] = -1
        return out

    def decode(self, W):
        r = self.decode_batch(np.asarray(W)[None])[0]
        return None if r[0] < 0 else (int(r[0]), int(r[1]), int(r[2]))
