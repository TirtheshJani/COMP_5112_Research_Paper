"""Exact maximum of the checkerboard interleave for 5 x 5 windows, by shape.
Usage: python3 scripts/run_interleave_table.py timeout [min_RC] [rows, e.g. 4,8,10]
All shapes 4 <= R <= C, R and C even, 2RC <= 784 (the counting cap), largest RC first.
Appends to research/results/interleave_table.csv (resumable)."""
import csv, os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from otorus.construct import solve_interleave, interleave_checkerboard
from otorus.windows import min_distance_fast

timeout = int(sys.argv[1])
min_rc = int(sys.argv[2]) if len(sys.argv) > 2 else 0
root = os.path.join(os.path.dirname(__file__), "..", "..", "results")
path = os.path.join(root, "interleave_table.csv")
done = set()
if os.path.exists(path):
    done = {(int(r["R"]), int(r["C"])) for r in csv.DictReader(open(path)) if r["status"] != "TIMEOUT"}
else:
    with open(path, "w", newline="") as f:
        csv.writer(f).writerow(["R", "C", "RC", "status", "seconds", "A", "B", "verified_min_distance"])
rows = [int(x) for x in sys.argv[3].split(",")] if len(sys.argv) > 3 else list(range(4, 30, 2))
shapes = sorted({(R, C) for R in rows for C in range(R, 400, 2) if 2 * R * C <= 784 and R * C >= min_rc},
                key=lambda p: (-p[0] * p[1], p))
for R, C in shapes:
    if (R, C) in done:
        continue
    t0 = time.time()
    st, A, B = solve_interleave(R, C, timeout=timeout)
    dt = time.time() - t0
    a = b = md = ""
    if st == "SAT":
        a, b = "".join(map(str, A)), "".join(map(str, B))
        md = min_distance_fast(interleave_checkerboard(A, B), 5, 4, rmax=2)
    with open(path, "a", newline="") as f:
        csv.writer(f).writerow([R, C, R * C, st, f"{dt:.1f}", a, b, md])
    print(f"{R}x{C} RC={R*C}: {st} {dt:.1f}s md={md}", flush=True)
