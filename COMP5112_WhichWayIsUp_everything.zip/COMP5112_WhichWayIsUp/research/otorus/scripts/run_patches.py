"""Open-patch control for the strip result (peer review 2, finding A).
Usage: python3 scripts/run_patches.py u s delta max_nodes RxC,RxC,...
Searches patches that wrap in neither direction and records whether their turned windows can be made
pairwise at distance >= delta. Writes research/results/patches_<u>x<u>_s<s>_d<delta>.csv."""
import csv, os, sys, time
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from otorus.exhaustive import dfs_patch

u, s, delta = (int(x) for x in sys.argv[1:4])
max_nodes = int(float(sys.argv[4]))
shapes = [tuple(int(v) for v in sh.split("x")) for sh in sys.argv[5].split(",")]
root = os.path.join(os.path.dirname(__file__), "..", "..", "results")
with open(os.path.join(root, f"patches_{u}x{u}_s{s}_d{delta}.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["R", "C", "turned_windows", "status", "nodes", "seconds", "patch"])
    for R, C in shapes:
        t0 = time.time()
        st, T, nodes = dfs_patch(R, C, u, s, delta, max_nodes=max_nodes)
        patch = "" if T is None else "/".join("".join(str(int(x)) for x in row) for row in T)
        w.writerow([R, C, s * (R - u + 1) * (C - u + 1), st, nodes, f"{time.time() - t0:.1f}", patch])
        print(f"open {R}x{C}: {st} ({nodes:,} nodes)", flush=True)
