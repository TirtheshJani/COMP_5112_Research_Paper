"""Decide 6-row interleave shapes by splitting on the row sequence A.
Usage: python3 scripts/run_interleave_rows6.py timeout C1,C2,...
A ranges over period-6 sequences avoiding the banned windows, up to the symmetries that preserve
the interleave: shifting A by two rows (a torus translation) and complementing A and B together.
A width C is SAT if some class is SAT, UNSAT if every class is UNSAT, otherwise undecided.
Appends per-class results to research/results/interleave_rows6.csv."""
import csv, itertools, os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from otorus.construct import solve_interleave, interleave_checkerboard, INTERLEAVE_BANNED
from otorus.windows import min_distance_fast

timeout = int(sys.argv[1]); widths = [int(x) for x in sys.argv[2].split(",")]
root = os.path.join(os.path.dirname(__file__), "..", "..", "results")
path = os.path.join(root, "interleave_rows6.csv")


def ok(a):
    return all("".join(str(a[(i + t) % 6]) for t in range(5)) not in INTERLEAVE_BANNED for i in range(6))


reps, seen = [], set()
for a in itertools.product((0, 1), repeat=6):
    if not ok(a) or a in seen:
        continue
    orbit = set()
    for sh in (0, 2, 4):
        b = a[sh:] + a[:sh]
        orbit.add(b); orbit.add(tuple(1 - x for x in b))
    seen |= orbit
    reps.append(list(a))
print(f"{len(reps)} classes of A", flush=True)
new = not os.path.exists(path)
with open(path, "a", newline="") as f:
    if new:
        csv.writer(f).writerow(["R", "C", "A", "status", "seconds", "B", "verified_min_distance"])
for C in widths:
    statuses = []
    for a in reps:
        t0 = time.time()
        st, A, B = solve_interleave(6, C, timeout=timeout, fix_a=a)
        b = md = ""
        if st == "SAT":
            b = "".join(map(str, B)); md = min_distance_fast(interleave_checkerboard(A, B), 5, 4, rmax=2)
        with open(path, "a", newline="") as f:
            csv.writer(f).writerow([6, C, "".join(map(str, a)), st, f"{time.time()-t0:.1f}", b, md])
        statuses.append(st)
        if st == "SAT":
            break
    verdict = "SAT" if "SAT" in statuses else ("UNSAT" if all(s == "UNSAT" for s in statuses) else "UNDECIDED")
    print(f"6x{C}: {verdict} ({statuses.count('UNSAT')} classes UNSAT, {statuses.count('TIMEOUT')} timeouts)", flush=True)
