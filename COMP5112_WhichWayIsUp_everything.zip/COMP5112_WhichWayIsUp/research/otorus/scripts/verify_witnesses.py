"""Re-check every witness torus in research/results/witnesses against the property its name claims.
Names: u<u>v<v>s<s>d<delta>_R<R>C<C>*.txt (SAT), u<u>s<s>d<delta>_R<R>C<C>_seed*.npz (search),
interleave_R*C*.txt and xor_R*C*.txt (5 x 5, s = 4; interleave claims distance >= 2, XOR claims 5).
Uses otorus.windows.min_distance_fast (independent of the search and SAT code)."""
import os, re, sys
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from otorus.windows import min_distance_fast, min_window_distance

root = os.path.join(os.path.dirname(__file__), "..", "..", "results", "witnesses")
bad = 0
for name in sorted(os.listdir(root)):
    path = os.path.join(root, name)
    if name.endswith(".npz"):
        z = np.load(path); shape = tuple(z["shape"])
        T = np.unpackbits(z["bits"])[: shape[0] * shape[1]].reshape(shape)
        m = re.match(r"u(\d+)s(\d+)d(\d+)_R(\d+)C(\d+)", name); u, s, d = int(m[1]), int(m[2]), int(m[3])
    else:
        T = np.atleast_2d(np.loadtxt(path, dtype=np.uint8))
        m = re.match(r"u(\d+)v(\d+)s(\d+)d(\d+)_R(\d+)C(\d+)", name)
        if m:
            u, s, d = int(m[1]), int(m[3]), int(m[4])
        else:
            u, s, d = 5, 4, (5 if name.startswith("xor") else 2)
    small = T.size * s <= 2000
    md = min_window_distance(T, u, u, s) if small else min_distance_fast(T, u, s, rmax=2)
    ok = md >= (d if small else min(d, 3))  # the fast check reports 3 for "at least 3"
    bad += not ok
    print(f"{'ok ' if ok else 'BAD'} {name}: {T.shape[0]}x{T.shape[1]} window {u}x{u} s={s} claimed distance >= {d}, measured {md}"
          + ("" if small else " (fast check, 3 means >= 3)"))
print(f"{bad} failures")
sys.exit(1 if bad else 0)
