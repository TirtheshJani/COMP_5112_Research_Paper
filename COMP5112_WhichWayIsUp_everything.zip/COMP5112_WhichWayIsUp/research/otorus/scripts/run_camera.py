"""Simulated-camera robustness experiment (research statement, fourth step).
Usage: python3 scripts/run_camera.py name=path:u:s:design ... (path relative to research/results)
For every torus and noise level, reads n windows at random positions and quarter turns through
otorus.camera.simulate_reads and decodes them with otorus.decode.Decoder. Writes
research/results/camera_robustness.csv and research/results/decode_timing.md."""
import csv, os, sys, time
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from otorus.camera import simulate_reads
from otorus.decode import Decoder
from otorus.windows import min_distance_fast

root = os.path.join(os.path.dirname(__file__), "..", "..", "results")
N_READS, BLUR, ANGLE, OFFSET = 20000, 0.10, 1.0, 0.05
NOISES = [0.0, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40]


def load(path):
    full = os.path.join(root, path)
    if path.endswith(".npz"):
        z = np.load(full)
        shape = tuple(z["shape"])
        return np.unpackbits(z["bits"])[: shape[0] * shape[1]].reshape(shape)
    return np.atleast_2d(np.loadtxt(full, dtype=np.uint8))


tori = []
for arg in sys.argv[1:]:
    name, rest = arg.split("=", 1)
    path, u, s, design = rest.split(":")
    tori.append((name, load(path), int(u), int(s), design))

out = os.path.join(root, "camera_robustness.csv")
with open(out, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["torus", "u", "R", "C", "design", "min_distance", "density", "noise", "blur", "angle_deg",
                "offset", "reads", "correct", "rejected", "wrong", "reads_with_errors",
                "single_error_reads", "single_error_wrong", "multi_error_reads", "multi_error_wrong"])
    timing = []
    for name, T, u, s, design in tori:
        dec = Decoder(T, u, s)
        md = min_distance_fast(T, u, s, rmax=2)
        dens = s * T.size / 2 ** (u * u)
        for noise in NOISES:
            rng = np.random.default_rng(12345)
            reads, truth, n_err = simulate_reads(T, u, N_READS, rng, blur=BLUR, noise=noise,
                                                 angle_deg=ANGLE, offset=OFFSET)
            got = dec.decode_batch(reads)
            ok = (got == truth).all(axis=1)
            rej = got[:, 0] == -1
            wrong = ~ok & ~rej
            one, many = n_err == 1, n_err >= 2
            w.writerow([name, u, T.shape[0], T.shape[1], design, md, f"{dens:.5f}", noise, BLUR, ANGLE, OFFSET,
                        N_READS, int(ok.sum()), int(rej.sum()), int(wrong.sum()), int((n_err > 0).sum()),
                        int(one.sum()), int((wrong & one).sum()), int(many.sum()), int((wrong & many).sum())])
            print(f"{name} noise={noise}: correct={ok.mean():.4f} rejected={rej.mean():.4f} wrong={wrong.mean():.4f} "
                  f"(1-error reads {one.sum()}, wrong {int((wrong & one).sum())})", flush=True)
        reads, truth, _ = simulate_reads(T, u, 200000, np.random.default_rng(7))
        rates = []
        for _ in range(5):
            t0 = time.time()
            dec.decode_batch(reads)
            rates.append(200000 / (time.time() - t0))
        timing.append((name, T.shape, s * T.size, sorted(rates)))

with open(os.path.join(root, "decode_timing.md"), "w") as f:
    f.write("# Decode timing (table decoder, numpy binary search, one core, 200,000 decodes per run, 5 runs)\n\n")
    f.write("| torus | shape | table entries | median decodes per second | slowest run | fastest run |\n|---|---|---|---|---|---|\n")
    for name, shape, entries, rates in timing:
        f.write(f"| {name} | {shape[0]} x {shape[1]} | {entries:,} | {rates[2]:,.0f} | {rates[0]:,.0f} | {rates[4]:,.0f} |\n")
    f.write("\nDothraki (Schusselbauer et al. 2021) reports a 14 Hz end-to-end pipeline; the table lookup is not the bottleneck.\n")
print("done", flush=True)
