"""Grow large tori by local search and verify them independently.
Usage: python3 scripts/run_grow.py u s delta n1,n2,... seeds max_flips temp  (seeds: a count, or a range a:b)
Appends to research/results/grow_<u>x<u>.csv; witnesses go to results/witnesses/ as packed .npz."""
import csv, hashlib, os, sys, time
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from otorus.search import local_search
from otorus.windows import min_distance_fast

u, s, delta = (int(x) for x in sys.argv[1:4])
sizes = [int(x) for x in sys.argv[4].split(",")]
seed_list = range(*map(int, sys.argv[5].split(":"))) if ":" in sys.argv[5] else range(int(sys.argv[5]))  # "5" or "2:5"
max_flips = int(float(sys.argv[6]))
temp = float(sys.argv[7])
root = os.path.join(os.path.dirname(__file__), "..", "..", "results")
os.makedirs(os.path.join(root, "witnesses"), exist_ok=True)
path = os.path.join(root, f"grow_{u}x{u}.csv")
new = not os.path.exists(path)
with open(path, "a", newline="") as f:
    w = csv.writer(f)
    if new:
        w.writerow(["u", "s", "delta", "R", "C", "RC", "density", "seed", "temp", "max_flips",
                    "final_energy", "flips", "seconds", "verified_min_distance", "witness", "sha1"])
for n in sizes:
    for seed in seed_list:
        t0 = time.time()
        T, E, flips = local_search(n, n, u, s, delta, seed=seed, max_flips=max_flips, temp=temp)
        dt = time.time() - t0
        md, wit, h = "", "", ""
        if E == 0:
            md = min_distance_fast(T, u, s, rmax=2)  # 3 means "at least 3"
            h = hashlib.sha1(T.tobytes()).hexdigest()[:10]
            wit = f"u{u}s{s}d{delta}_R{n}C{n}_seed{seed}.npz"
            np.savez_compressed(os.path.join(root, "witnesses", wit), bits=np.packbits(T), shape=T.shape)
        dens = s * n * n / 2 ** (u * u)
        with open(path, "a", newline="") as f:
            csv.writer(f).writerow([u, s, delta, n, n, n * n, f"{dens:.5f}", seed, temp, max_flips,
                                    E, flips, f"{dt:.1f}", md, wit, h])
        print(f"{u}x{u} s={s} d={delta} {n}x{n} seed={seed}: E={E} flips={flips} {dt:.1f}s mindist={md}", flush=True)
