"""Resumable exact-search table. Usage: python3 scripts/run_sat_table.py u v s delta [timeout]
Appends rows to research/results/sat_table.csv and saves SAT witnesses to results/witnesses/."""
import csv, hashlib, os, sys, time
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from otorus.sat import solve_torus
from otorus.bounds import ceiling

u, v, s, delta = map(int, sys.argv[1:5])
timeout = int(sys.argv[5]) if len(sys.argv) > 5 and sys.argv[5].isdigit() else 120
root = os.path.join(os.path.dirname(__file__), "..", "..", "results")
csv_path = os.path.join(root, "sat_table.csv")
done = set()
retry = "--retry-timeouts" in sys.argv
if os.path.exists(csv_path):
    with open(csv_path) as f:
        rows = list(csv.DictReader(f))
    if retry:  # drop TIMEOUT rows so they are run again with the new budget
        keep = [r for r in rows if r["status"] != "TIMEOUT"]
        with open(csv_path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(keep)
        rows = keep
    for row in rows:
        done.add(tuple(int(row[k]) for k in ("u", "v", "s", "delta", "R", "C")))
else:
    with open(csv_path, "w", newline="") as f:
        csv.writer(f).writerow(["u", "v", "s", "delta", "R", "C", "RC", "status", "seconds", "solution_hash"])

cap = ceiling(u, v, s, delta)
shapes_arg = [a for a in sys.argv if a.startswith("--shapes=")]
if shapes_arg:  # explicit list, e.g. --shapes=10x12,8x15
    pairs = [tuple(int(x) for x in sh.split("x")) for sh in shapes_arg[0].split("=", 1)[1].split(",")]
else:
    pairs = sorted({(R, C) for R in range(u, cap + 1) for C in range(v, cap // R + 1) if R <= C or u != v}, key=lambda p: (p[0] * p[1], p))
for R, C in pairs:
    if (u, v, s, delta, R, C) in done:
        continue
    t0 = time.time()
    status, T = solve_torus(R, C, u, v, s, delta, timeout=timeout)
    dt = round(time.time() - t0, 2)
    h = ""
    if status == "SAT":
        h = hashlib.sha1(T.tobytes()).hexdigest()[:10]
        np.savetxt(os.path.join(root, "witnesses", f"u{u}v{v}s{s}d{delta}_R{R}C{C}.txt"), T, fmt="%d")
    with open(csv_path, "a", newline="") as f:
        csv.writer(f).writerow([u, v, s, delta, R, C, R * C, status, dt, h])
    print(f"{u}x{v} s={s} d={delta} {R}x{C} RC={R*C}: {status} in {dt}s", flush=True)
