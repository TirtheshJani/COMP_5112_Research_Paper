"""Regenerate every figure of the COMP 5112 paper from the files in research/results.

Usage: python3 make_figures.py   (from any directory; paths are relative to this file)

Writes one vector PDF and one 150 dpi PNG preview per figure into research/paper/figures/:
  fig_windows     a window, its three quarter turns, and a one-cell misread
  fig_exact3x3    3 x 3 windows, s = 4: which shapes R x C exist, distance 1 against distance 2
  fig_interleave  the checkerboard interleave layout and its feasibility map
  fig_sizes       sizes reached for 5 x 5 windows against the ceilings (log scale)
  fig_search      local search: ball occupancy of solved and failed runs
  fig_camera      simulated camera: wrong-position rate against noise
Every plotted number is read from a results file or computed by the otorus package; the script
also prints a few cross-checks (maxima and ceilings) so a reader can compare them with the text.
"""
import csv
import os
import sys

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import Rectangle  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
RESEARCH = os.path.abspath(os.path.join(HERE, "..", ".."))
RESULTS = os.path.join(RESEARCH, "results")
OUT = os.path.join(RESEARCH, "paper", "figures")
sys.path.insert(0, os.path.join(RESEARCH, "otorus"))
from otorus import bounds, construct, windows  # noqa: E402

# ---------------------------------------------------------------------------------------------
# Style: one sans face, 8 to 9 pt text, thin recessive axes, a colour-blind-checked palette.
# The six series colours are the first six slots of the dataviz reference palette (adjacent
# pairs pass the CVD and normal-vision checks); every series also has its own marker shape.
# ---------------------------------------------------------------------------------------------
WIDTH = 5.5  # inches; LIPIcs text width is about 5.6 in

INK = "#0b0b0b"      # primary text
INK2 = "#52514e"     # secondary text, axes, reference curves
MUTED = "#898781"    # impossible shapes, de-emphasised items
FAINT = "#c3c2b7"    # not-tested shapes
GRID = "#e1e0d9"     # hairlines

BLUE = "#2a78d6"
ORANGE = "#eb6834"
AQUA = "#1baf7a"
YELLOW = "#eda100"
MAGENTA = "#e87ba4"
GREEN = "#008300"
BLUE_TINT = "#cde2fb"
ORANGE_TINT = "#fbe1d6"

STRONG = BLUE        # strong form (distance 2) wherever a figure colours by condition
ORIENT = ORANGE      # orientation only (distance 1)

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Liberation Sans", "Arial", "Helvetica", "DejaVu Sans"],
    "mathtext.fontset": "custom",
    "mathtext.rm": "Liberation Sans",
    "mathtext.it": "Liberation Sans:italic",
    "mathtext.bf": "Liberation Sans:bold",
    "mathtext.sf": "Liberation Sans",
    "mathtext.cal": "Liberation Sans:italic",
    "font.size": 8,
    "axes.labelsize": 9,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": 8,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.linewidth": 0.6,
    "axes.edgecolor": INK2,
    "axes.labelcolor": INK,
    "xtick.color": INK2,
    "ytick.color": INK2,
    "xtick.labelcolor": INK,
    "ytick.labelcolor": INK,
    "xtick.major.width": 0.6,
    "ytick.major.width": 0.6,
    "xtick.minor.width": 0.4,
    "ytick.minor.width": 0.4,
    "xtick.major.size": 3,
    "ytick.major.size": 3,
    "xtick.minor.size": 1.8,
    "ytick.minor.size": 1.8,
    "lines.linewidth": 1.3,
    "legend.frameon": False,
    "legend.handlelength": 1.8,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "figure.dpi": 150,
    "savefig.dpi": 150,
})

# Markers for the status of a tested shape (figures 2 and 3).
STATUS_STYLE = {
    "exists": dict(marker="o", ms=3.6, mfc=BLUE, mec="white", mew=0.4, ls="none"),
    "impossible": dict(marker="x", ms=2.6, color=MUTED, mew=0.6, ls="none"),
    "undecided": dict(marker="^", ms=5.0, mfc=ORANGE, mec=INK, mew=0.5, ls="none"),
    "not tested": dict(marker=".", ms=1.6, color=FAINT, ls="none"),
}
STATUS_LABEL = {
    "exists": "exists",
    "impossible": "impossible",
    "undecided": "undecided (solver timed out)",
    "not tested": "not tested",
}


def read_csv(name):
    with open(os.path.join(RESULTS, name), newline="") as f:
        return list(csv.DictReader(f))


def save(fig, name):
    os.makedirs(OUT, exist_ok=True)
    fig.savefig(os.path.join(OUT, name + ".pdf"), metadata={"CreationDate": None})
    fig.savefig(os.path.join(OUT, name + ".png"), dpi=150, facecolor="white")
    plt.close(fig)
    print("wrote", name + ".pdf", "and", name + ".png")


def merge_status(table, key, status):
    """A shape may appear more than once; a decided answer (SAT or UNSAT) beats TIMEOUT."""
    old = table.get(key)
    if old is None or old == "TIMEOUT":
        table[key] = status
    elif status != "TIMEOUT" and status != old:
        raise ValueError(f"conflicting statuses for {key}: {old} and {status}")


def word(status):
    return {"SAT": "exists", "UNSAT": "impossible", "TIMEOUT": "undecided"}[status]


def panel_tag(ax, text, x=0.0, y=1.02):
    ax.text(x, y, text, transform=ax.transAxes, ha="left", va="bottom", fontsize=9, color=INK)


def times(r, c):
    return f"{r} × {c}"


# ---------------------------------------------------------------------------------------------
# Figure 1: a window, its three quarter turns, and the same window with one cell misread.
# ---------------------------------------------------------------------------------------------
def fig_windows():
    T = construct.xor_torus([0, 0, 0, 0, 0, 1], [0, 0, 1, 0, 1, 1])
    W = windows.window(T, 0, 0, 5, 5)
    turns = windows.rotations(W, 4)  # 0, 90, 180, 270 degrees, counterclockwise (np.rot90)
    flip = (1, 3)
    M = W.copy()
    M[flip] ^= 1

    # Checks behind the figure's point: the four turns differ; the misread is no turned window.
    codes = set(windows.packed_turned_windows(T, 5, 5, 4))
    assert len({windows.pack(X) for X in turns}) == 4
    assert windows.pack(M) not in codes
    assert windows.is_orientable(T, 5, 5, 4)
    d = windows.min_window_distance(T, 5, 5, 4)
    print(f"  fig_windows: 6 x 6 XOR torus is 4-orientable, window distance {d}; misread is not a window")

    grids = turns + [M]
    labels = ["window", "turned 90°", "turned 180°", "turned 270°", "one cell misread"]
    fig, axes = plt.subplots(1, 5, figsize=(WIDTH, 1.25))
    fig.subplots_adjust(left=0.02, right=0.98, bottom=0.17, top=0.98, wspace=0.42)
    for k, (ax, G, lab) in enumerate(zip(axes, grids, labels)):
        for r in range(5):
            for c in range(5):
                ax.add_patch(Rectangle((c, r), 1, 1, facecolor=INK if G[r, c] else "white",
                                       edgecolor=MUTED, linewidth=0.5))
        ax.add_patch(Rectangle((0, 0), 5, 5, fill=False, edgecolor=INK, linewidth=0.8))
        if k == 4:
            r, c = flip
            ax.add_patch(Rectangle((c + 0.06, r + 0.06), 0.88, 0.88, fill=False,
                                   edgecolor=ORANGE, linewidth=2.0))
        ax.set_xlim(-0.1, 5.1)
        ax.set_ylim(5.1, -0.1)
        ax.set_aspect("equal")
        ax.axis("off")
        ax.text(2.5, 5.55, lab, ha="center", va="top", fontsize=8.5, color=INK)
    # A thin rule separates the four turned copies from the misread.
    x = (axes[3].get_position().x1 + axes[4].get_position().x0) / 2
    fig.add_artist(Line2D([x, x], [0.12, 0.95], color=FAINT, linewidth=0.8))
    save(fig, "fig_windows")


# ---------------------------------------------------------------------------------------------
# Figure 2: exact results for 3 x 3 windows, s = 4, distance 1 against distance 2.
# ---------------------------------------------------------------------------------------------
def fig_exact3x3():
    table = {1: {}, 2: {}}
    for row in read_csv("sat_table.csv"):
        if (row["u"], row["v"], row["s"]) != ("3", "3", "4"):
            continue
        merge_status(table[int(row["delta"])], (int(row["R"]), int(row["C"])), row["status"])
    ceil = {1: bounds.ceiling(3, 3, 4, 1), 2: bounds.ceiling(3, 3, 4, 2)}
    best = {dl: max(r * c for (r, c), s in t.items() if s == "SAT") for dl, t in table.items()}
    print(f"  fig_exact3x3: ceilings {ceil}, largest existing R*C {best}, "
          f"shapes tested {len(table[1])} (delta 1) and {len(table[2])} (delta 2)")
    assert best[2] == 36 and best[1] == 85 and ceil == {1: 120, 2: 60}

    fig, axes = plt.subplots(1, 2, figsize=(WIDTH, 2.55), sharex=True, sharey=True)
    fig.subplots_adjust(left=0.075, right=0.985, bottom=0.16, top=0.80, wspace=0.08)
    xmax, ymax = 62, 11.6
    for ax, dl in zip(axes, (1, 2)):
        for st in ("SAT", "UNSAT", "TIMEOUT"):
            pts = [(c, r) for (r, c), s in table[dl].items() if s == st]
            if pts:
                cs, rs = zip(*pts)
                ax.plot(cs, rs, **STATUS_STYLE[word(st)], zorder=3)
        cc = np.linspace(ceil[dl] / ymax, xmax, 400)
        ax.plot(cc, ceil[dl] / cc, color=INK2, linewidth=0.9, zorder=2)
        ax.set_xlim(0, xmax)
        ax.set_ylim(0.3, ymax)
        ax.set_xticks(range(0, 61, 10))
        ax.set_yticks(range(1, 12))
        ax.set_xlabel("Columns C")
        ax.tick_params(axis="both", length=2.5)
    a, b = axes
    a.set_ylabel("Rows R")
    panel_tag(a, "(a) orientation only (distance 1)")
    panel_tag(b, "(b) strong form (distance 2)")
    a.text(36, 3.85, f"R × C = {ceil[1]} (ceiling)", color=INK2, fontsize=8, ha="left")
    b.text(34, 2.25, f"R × C = {ceil[2]} (ceiling)", color=INK2, fontsize=8, ha="left")
    cc = np.linspace(best[2] / ymax, xmax, 400)
    b.plot(cc, best[2] / cc, color=INK2, linewidth=0.9, linestyle=(0, (3, 2)), zorder=2)
    largest = sorted(k for k, s in table[2].items() if s == "SAT" and k[0] * k[1] == best[2])
    b.annotate(f"R × C = {best[2]}, the largest that exists:\n"
               + " and ".join(times(r, c) for r, c in largest) + " (ringed)",
               xy=(4.5, 8.0), xytext=(11, 9.3), color=INK2, fontsize=8, ha="left", va="center",
               arrowprops=dict(arrowstyle="-", color=INK2, linewidth=0.5, shrinkA=1, shrinkB=0))
    for r, c in largest:
        b.plot([c], [r], marker="o", ms=7.5, mfc="none", mec=INK, mew=0.8, zorder=4)

    handles = [Line2D([], [], **STATUS_STYLE[k]) for k in ("exists", "impossible", "undecided")]
    fig.legend(handles, [STATUS_LABEL[k] for k in ("exists", "impossible", "undecided")],
               loc="upper center", ncol=3, bbox_to_anchor=(0.53, 1.0), handletextpad=0.3,
               columnspacing=1.6, markerscale=1.3)
    save(fig, "fig_exact3x3")


# ---------------------------------------------------------------------------------------------
# Figure 3: the checkerboard interleave, layout and feasibility map.
# ---------------------------------------------------------------------------------------------
def interleave_status():
    status = {}
    for row in read_csv("interleave_table.csv"):
        merge_status(status, (int(row["R"]), int(row["C"])), row["status"])
    per_width = {}
    for row in read_csv("interleave_rows6.csv"):
        per_width.setdefault((int(row["R"]), int(row["C"])), []).append(row["status"])
    for key, sts in per_width.items():
        if "SAT" in sts:
            merge_status(status, key, "SAT")
        elif all(s == "UNSAT" for s in sts):
            merge_status(status, key, "UNSAT")
        else:
            merge_status(status, key, "TIMEOUT")
    return status


def fig_interleave():
    status = interleave_status()
    cap = 784 // 2  # 2RC distinct descriptors out of 28 x 28 = 784, so R*C <= 392
    best = max(r * c for (r, c), s in status.items() if s == "SAT")
    best_shape = [k for k, s in status.items() if s == "SAT" and k[0] * k[1] == best]
    above = [k for k in status if k[0] * k[1] > best]
    print(f"  fig_interleave: largest existing R*C {best} at {best_shape}; "
          f"{len(above)} tested shapes above it, all impossible: "
          f"{all(status[k] == 'UNSAT' for k in above)}; undecided left: "
          f"{[k for k, s in status.items() if s == 'TIMEOUT']}")
    assert best == 280 and best_shape == [(14, 20)]

    fig, (axl, axr) = plt.subplots(1, 2, figsize=(WIDTH, 2.7),
                                   gridspec_kw=dict(width_ratios=[1.0, 1.45]))
    fig.subplots_adjust(left=0.045, right=0.985, bottom=0.15, top=0.73, wspace=0.17)

    # Left: a 6 x 10 piece of the layout.
    R, C = 6, 10
    for i in range(R):
        for j in range(C):
            even = (i + j) % 2 == 0
            axl.add_patch(Rectangle((j, i), 1, 1, facecolor=BLUE_TINT if even else ORANGE_TINT,
                                    edgecolor="white", linewidth=1.2))
            lab = f"$a_{{{i}}}$" if even else f"$b_{{{j}}}$"
            axl.text(j + 0.5, i + 0.52, lab, ha="center", va="center", fontsize=8, color=INK)
    axl.set_xlim(0, C)
    axl.set_ylim(R, 0)
    axl.set_aspect("equal")
    axl.set_xticks(np.arange(C) + 0.5, [str(j) for j in range(C)])
    axl.set_yticks(np.arange(R) + 0.5, [str(i) for i in range(R)])
    axl.xaxis.tick_top()
    axl.xaxis.set_label_position("top")
    axl.tick_params(length=0, pad=2)
    for side in ("left", "bottom", "top", "right"):
        axl.spines[side].set_visible(False)
    axl.set_xlabel("column j", labelpad=3)
    axl.set_ylabel("row i", labelpad=2)
    axl.text(0, R + 0.35, "$a_i$ where i + j is even, $b_j$ where i + j is odd",
             ha="left", va="top", fontsize=8, color=INK)

    # Right: feasibility map over even shapes 4 <= R <= C up to the counting cap.
    groups = {k: [] for k in STATUS_STYLE}
    for r in range(4, 20, 2):
        for c in range(r, cap // r + 1):
            if c % 2:
                continue
            s = status.get((r, c))
            groups["not tested" if s is None else word(s)].append((c, r))
    for k in ("not tested", "impossible", "undecided", "exists"):
        if groups[k]:
            cs, rs = zip(*groups[k])
            axr.plot(cs, rs, **STATUS_STYLE[k], zorder=3)
    xmax = 100
    cc = np.linspace(cap / 19, xmax, 400)
    axr.plot(cc, cap / cc, color=INK2, linewidth=0.9, zorder=2)
    cc = np.linspace(best / 19, xmax, 400)
    axr.plot(cc, best / cc, color=INK2, linewidth=0.9, linestyle=(0, (3, 2)), zorder=2)
    br, bc = best_shape[0]
    axr.plot([bc], [br], marker="o", ms=8.5, mfc="none", mec=INK, mew=0.9, zorder=4)
    axr.annotate(f"{times(br, bc)} = {best} cells, the largest\nwith admissible labels", xy=(bc + 1.2, br + 0.6),
                 xytext=(29, 16.8), fontsize=8, color=INK, va="center",
                 arrowprops=dict(arrowstyle="-", color=INK2, linewidth=0.5))
    axr.set_xlim(0, xmax)
    axr.set_ylim(2.6, 19.2)
    axr.set_yticks(range(4, 19, 2))
    axr.set_xticks(range(0, 101, 20))
    axr.set_xlabel("Columns C")
    axr.set_ylabel("Rows R", labelpad=2)

    order = ("exists", "impossible", "undecided", "not tested")
    used = [k for k in order if groups[k]]
    handles = [Line2D([], [], **STATUS_STYLE[k]) for k in used]
    labels = [STATUS_LABEL[k] for k in used]
    handles += [Line2D([], [], color=INK2, linewidth=0.9),
                Line2D([], [], color=INK2, linewidth=0.9, linestyle=(0, (3, 2)))]
    labels += [f"R × C = {cap} (counting cap)", f"R × C = {best}"]
    fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 1.0), ncol=len(labels),
               handletextpad=0.35, markerscale=1.3, columnspacing=1.3, handlelength=2.0)
    # Panel tags at one height, above both panels and below the legend.
    y_tag = 0.845
    fig.text(axl.get_position().x0 - 0.03, y_tag, "(a) the layout", fontsize=9, color=INK,
             ha="left", va="bottom")
    fig.text(axr.get_position().x0 - 0.05, y_tag, "(b) which even shapes R × C exist",
             fontsize=9, color=INK, ha="left", va="bottom")
    save(fig, "fig_interleave")


# ---------------------------------------------------------------------------------------------
# Figure 4: how large, for 5 x 5 windows (log scale).
# ---------------------------------------------------------------------------------------------
def largest_solved(rows, u, delta):
    return max(int(r["RC"]) for r in rows
               if int(r["u"]) == u and int(r["delta"]) == delta and int(r["final_energy"]) == 0)


def fig_sizes():
    xor_best = max(int(r["RC"]) for r in read_csv("xor_table.csv") if r["status"] == "SAT")
    inter_best = max(r * c for (r, c), s in interleave_status().items() if s == "SAT")
    g5 = read_csv("grow_5x5.csv")
    s_strong, s_orient = largest_solved(g5, 5, 2), largest_solved(g5, 5, 1)
    c_strong, c_orient = bounds.ceiling(5, 5, 4, 2), bounds.ceiling(5, 5, 4, 1)
    all_w = 2 ** 25
    items = [  # (label, value, colour, achieved?)
        ("XOR family, largest", xor_best, STRONG, True),
        ("Interleave, admissible labels", inter_best, STRONG, True),
        ("Local search, strong form", s_strong, STRONG, True),
        ("Local search, orientation only", s_orient, ORIENT, True),
        ("Ceiling, strong form", c_strong, STRONG, False),
        ("Ceiling, orientation only (Lemma 19)", c_orient, ORIENT, False),
        ("All $2^{25}$ windows (Dothraki torus,\nonly 1-orientable)", all_w, MUTED, False),
    ]
    print(f"  fig_sizes: {[(lab.split(',')[0], v) for lab, v, _, _ in items]}; "
          f"search factor {s_orient / s_strong:g}, strong search to ceiling {c_strong / s_strong:.1f}")
    assert (xor_best, inter_best) == (36, 280) and s_orient > s_strong >= 65536

    fig, ax = plt.subplots(figsize=(WIDTH, 2.5))
    fig.subplots_adjust(left=0.34, right=0.835, bottom=0.16, top=0.85)
    n = len(items)
    ys = np.arange(n)[::-1]
    for y, (lab, v, col, ach) in zip(ys, items):
        ax.plot([10, v], [y, y], color=GRID, linewidth=0.8, zorder=1)
        ax.plot([v], [y], marker="o", ms=6.5, mfc=col if ach else "white", mec=col,
                mew=1.4, zorder=3)
        ax.text(1.03, y, f"{v:,}", transform=ax.get_yaxis_transform(), ha="left", va="center",
                fontsize=8, color=INK)
    ax.axhline(ys[3] - 0.5, color=FAINT, linewidth=0.6)
    ax.set_yticks(ys, [it[0] for it in items])
    ax.tick_params(axis="y", length=0)
    ax.spines["left"].set_visible(False)
    ax.set_xscale("log")
    ax.set_xlim(10, 1e8)
    ax.set_ylim(-0.6, n - 0.4)
    ax.set_xlabel("Number of cells R × C (log scale)")
    # The cost of distance 2 in what search reaches.
    y2, y1 = ys[2], ys[3]
    ax.annotate("", xy=(s_orient, y1 + 0.18), xytext=(s_strong, y2 - 0.18),
                arrowprops=dict(arrowstyle="->", color=INK2, linewidth=0.7, shrinkA=3, shrinkB=3))
    ax.text(np.sqrt(s_strong * s_orient) * 1.5, (y1 + y2) / 2 + 0.12,
            f"× {s_orient / s_strong:.0f} (search)", ha="left", va="center", fontsize=8, color=INK2)
    handles = [Line2D([], [], marker="o", ms=6, mfc=INK2, mec=INK2, ls="none"),
               Line2D([], [], marker="o", ms=6, mfc="white", mec=INK2, mew=1.3, ls="none"),
               Line2D([], [], marker="s", ms=6, mfc=STRONG, mec=STRONG, ls="none"),
               Line2D([], [], marker="s", ms=6, mfc=ORIENT, mec=ORIENT, ls="none"),
               Line2D([], [], marker="s", ms=6, mfc=MUTED, mec=MUTED, ls="none")]
    fig.legend(handles, ["achieved", "upper bound", "strong form", "orientation only", "neither"],
               loc="upper center", bbox_to_anchor=(0.5, 1.0), ncol=5, handletextpad=0.25,
               columnspacing=1.5)
    save(fig, "fig_sizes")


# ---------------------------------------------------------------------------------------------
# Figure 5: where local search stops, as occupancy of each window's conflict ball.
# ---------------------------------------------------------------------------------------------
def fig_search():
    raw = read_csv("grow_4x4.csv") + read_csv("grow_5x5.csv")
    # A rerun of the same size, seed and budget is deterministic; keep one row per run.
    rows = list({(r["u"], r["delta"], r["R"], r["seed"], r["max_flips"]): r for r in raw}.values())
    series = [(4, 1), (4, 2), (5, 1), (5, 2)]
    names = {(4, 1): "4 × 4, orientation only", (4, 2): "4 × 4, strong form",
             (5, 1): "5 × 5, orientation only", (5, 2): "5 × 5, strong form"}
    ypos = {key: len(series) - 1 - k for k, key in enumerate(series)}

    def occupancy(r):
        u, dl, dens = int(r["u"]), int(r["delta"]), float(r["density"])
        dens_exact = 4 * int(r["RC"]) / 2 ** (u * u)
        assert abs(dens - dens_exact) < 1e-5
        return dens_exact * (1 + u * u) if dl == 2 else dens_exact

    fig, ax = plt.subplots(figsize=(WIDTH, 2.25))
    fig.subplots_adjust(left=0.215, right=0.975, bottom=0.19, top=0.90)
    summary = {}
    for key in series:
        u, dl = key
        col = STRONG if dl == 2 else ORIENT
        pts = [r for r in rows if (int(r["u"]), int(r["delta"])) == key]
        by_size = {}
        for r in pts:
            by_size.setdefault(int(r["R"]), []).append(r)
        for R, group in by_size.items():
            n = len(group)
            # Failed runs below, solved runs above, so a size label points at a solved run.
            for k, r in enumerate(sorted(group, key=lambda r: -int(r["final_energy"]))):
                y = ypos[key] + (k - (n - 1) / 2) * 0.17
                x = occupancy(r)
                if int(r["final_energy"]) == 0:
                    ax.plot([x], [y], marker="o", ms=5, mfc=col, mec="white", mew=0.5, zorder=3)
                else:
                    ax.plot([x], [y], marker="x", ms=4.5, color=col, mew=1.1, zorder=3)
        solved = [r for r in pts if int(r["final_energy"]) == 0]
        top = max(solved, key=lambda r: int(r["RC"]))
        failed_above = [r for r in pts if int(r["final_energy"]) > 0 and int(r["RC"]) > int(top["RC"])]
        x = occupancy(top)
        summary[names[key]] = (f"{top['R']} x {top['C']}", round(x, 3),
                               min(int(r["R"]) for r in failed_above))
        ax.annotate(f"{times(top['R'], top['C'])}", xy=(x, ypos[key] + 0.12),
                    xytext=(x, ypos[key] + 0.40), ha="center", va="bottom", fontsize=8, color=INK,
                    arrowprops=dict(arrowstyle="-", color=INK2, linewidth=0.5, shrinkA=0, shrinkB=1))
    print(f"  fig_search: largest solved (shape, occupancy, smallest failed side above it): {summary}")
    # Light band per row: occupancy between the largest solved size and the smallest size with no
    # solved run, the bracket inside which this search stops.
    for key in series:
        pts = [r for r in rows if (int(r["u"]), int(r["delta"])) == key]
        solved = {int(r["RC"]) for r in pts if int(r["final_energy"]) == 0}
        top_rc = max(solved)
        fail_rc = min(int(r["RC"]) for r in pts if int(r["RC"]) > top_rc and int(r["RC"]) not in solved)
        u = key[0]
        f = (1 + u * u) if key[1] == 2 else 1
        lo, hi = 4 * top_rc * f / 2 ** (u * u), 4 * fail_rc * f / 2 ** (u * u)
        ax.fill_between([lo, hi], ypos[key] - 0.3, ypos[key] + 0.3, color=GRID, alpha=0.8, linewidth=0, zorder=0)
        summary[names[key]] += ((round(lo, 3), round(hi, 3)),)
    print(f"  fig_search: brackets (occupancy at largest solved, at smallest unsolved): {summary}")
    ax.set_xscale("log")
    ax.set_xlim(4e-3, 4)
    ax.set_xticks([0.01, 0.1, 1], ["0.01", "0.1", "1"])
    ax.set_ylim(-0.55, len(series) - 0.25)
    ax.set_yticks([ypos[k] for k in series], [names[k] for k in series])
    ax.tick_params(axis="y", length=0)
    ax.spines["left"].set_visible(False)
    for k in series:
        ax.axhline(ypos[k], color=GRID, linewidth=0.6, zorder=1)
    ax.set_xlabel("Occupied fraction of each window's conflict ball (log scale)")
    handles = [Line2D([], [], marker="o", ms=5, mfc=INK2, mec="white", ls="none"),
               Line2D([], [], marker="x", ms=4.5, color=INK2, mew=1.1, ls="none")]
    ax.legend(handles, ["solved (no conflicts left)", "failed (conflicts left at the flip limit)"],
              loc="lower left", bbox_to_anchor=(0.0, 1.0), ncol=2, borderaxespad=0.1,
              handletextpad=0.3, columnspacing=1.5)
    save(fig, "fig_search")


# ---------------------------------------------------------------------------------------------
# Figure 6: simulated camera.
# ---------------------------------------------------------------------------------------------
CAMERA_SHORT = {
    "3x3 strong 6x6": ("3×3 strong, 6×6", AQUA, "o", "-"),
    "3x3 orientation-only 6x6": ("3×3 orientation only, 6×6", ORANGE, "s", "--"),
    "3x3 orientation-only 9x9": ("3×3 orientation only, 9×9", INK2, "o", ":"),
    "5x5 XOR 6x6": ("5×5 XOR, 6×6", MAGENTA, "D", "-"),
    "5x5 interleave 14x20": ("5×5 interleave, 14×20", GREEN, "v", "-"),
    "5x5 strong 256x256": ("5×5 strong (search), 256×256", BLUE, "^", "-"),
    "5x5 orientation-only 256x256": ("5×5 orientation only, 256×256", YELLOW, "P", "--"),
}


def fig_camera():
    rows = read_csv("camera_robustness.csv")
    tori = list(dict.fromkeys(r["torus"] for r in rows))
    assert set(tori) == set(CAMERA_SHORT), tori
    floor = {"a": 1.5e-5, "b": 1.5e-4}
    lims = {"a": (1.0e-5, 1.0), "b": (1.0e-4, 1.0)}

    fig, axes = plt.subplots(1, 2, figsize=(WIDTH, 3.15), sharex=True)
    fig.subplots_adjust(left=0.15, right=0.985, bottom=0.355, top=0.925, wspace=0.27)
    checks = {}
    for name in tori:
        lab, col, mk, ls = CAMERA_SHORT[name]
        rr = [r for r in rows if r["torus"] == name]
        noise = np.array([float(r["noise"]) for r in rr])
        wrong = np.array([int(r["wrong"]) / int(r["reads"]) for r in rr])
        one_n = np.array([int(r["single_error_reads"]) for r in rr])
        one_w = np.array([int(r["single_error_wrong"]) for r in rr])
        with np.errstate(invalid="ignore", divide="ignore"):
            one = np.where(one_n > 0, one_w / np.maximum(one_n, 1), np.nan)
        checks[lab] = (int(sum(one_w)), int(sum(one_n)), float(rr[0]["density"]))
        for key, ax, yv in (("a", axes[0], wrong), ("b", axes[1], one)):
            y = np.where(yv == 0, floor[key], yv)
            ax.plot(noise, y, color=col, linestyle=ls, linewidth=1.2, marker=mk, ms=4.2,
                    mfc=col, mec="white", mew=0.5, label=lab, zorder=3)
    print("  fig_camera: single-error reads decoded wrong (wrong, reads, density):")
    for lab, v in checks.items():
        rate = v[0] / v[1] if v[1] else float("nan")
        print(f"    {lab}: {v[0]} of {v[1]} = {rate:.4f}; density {v[2]}")

    # Reference lines in (b): the density of turned windows of each orientation-only torus.
    for name in tori:
        lab, col, mk, ls = CAMERA_SHORT[name]
        rr = [r for r in rows if r["torus"] == name]
        if rr[0]["design"] != "orientation-only":
            continue
        dens = float(rr[0]["density"])
        axes[1].axhline(dens, color=col, linestyle=":", linewidth=1.0, zorder=2)
        axes[1].text(0.0, dens / 1.3, f"density {dens:.3g}", color=INK2, fontsize=7.5,
                     ha="left", va="top")
    n_strong = sum(1 for name in tori
                   if [r for r in rows if r["torus"] == name][0]["design"] != "orientation-only")
    axes[1].text(0.40, floor["b"] * 1.6, f"all {n_strong} strong-form tori: 0", color=INK2,
                 fontsize=7.5, ha="right", va="bottom")

    for key, ax in zip(("a", "b"), axes):
        ax.set_yscale("log")
        ax.set_ylim(*lims[key])
        ax.set_xlim(-0.01, 0.41)
        ax.set_xticks([0, 0.1, 0.2, 0.3, 0.4])
        ticks = [t for t in (1e-4, 1e-3, 1e-2, 1e-1, 1) if t >= lims[key][0] * 1.5]
        ax.set_yticks([floor[key]] + ticks, ["0"] + [f"{t:g}" for t in ticks])
        ax.minorticks_off()
        # A break mark on the axis separates the zero row from the log scale.
        gap = np.sqrt(floor[key] * ticks[0])
        ax.text(-0.01, gap, "//", ha="center", va="center", fontsize=7, color=INK2,
                clip_on=False, zorder=6,
                bbox=dict(boxstyle="square,pad=0.0", facecolor="white", edgecolor="none"))
        ax.set_xlabel("Image noise (standard deviation)")
    axes[0].set_ylabel("Fraction decoded to a\nwrong position (log scale)")
    panel_tag(axes[0], "(a) all reads")
    panel_tag(axes[1], "(b) reads with exactly one wrong cell")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, bbox_to_anchor=(0.53, 0.0),
               columnspacing=1.4, handlelength=2.6, handletextpad=0.5)
    save(fig, "fig_camera")


def main():
    for f in (fig_windows, fig_exact3x3, fig_interleave, fig_sizes, fig_search, fig_camera):
        print(f.__name__)
        f()


if __name__ == "__main__":
    main()
