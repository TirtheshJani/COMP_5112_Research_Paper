"""Open-strip test for local obstructions (peer review 1, finding 9).
Usage: python3 scripts/run_strips.py u s delta max_width max_length [max_nodes]
For each width w (the wrapping side), find the shortest open strip of that width whose turned windows
cannot be made pairwise distinct at distance delta. Every window of such a strip is a window of any
torus with w columns and at least that many rows, so no such torus exists. Writes
research/results/strips_<u>x<u>_s<s>_d<delta>.csv."""
import csv, os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from otorus.exhaustive import dfs_strip

u, s, delta, max_w, max_len = (int(x) for x in sys.argv[1:6])
max_nodes = int(float(sys.argv[6])) if len(sys.argv) > 6 else 0
root = os.path.join(os.path.dirname(__file__), "..", "..", "results")
with open(os.path.join(root, f"strips_{u}x{u}_s{s}_d{delta}.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["width", "first_unsat_length", "nodes", "seconds"])
    for width in range(1, max_w + 1):
        for L in range(u, max_len + 1):
            t0 = time.time()
            st, _, nodes = dfs_strip(L, width, u, s, delta, max_nodes=max_nodes)
            if st == "LIMIT":
                w.writerow([width, f"undecided at {L}", nodes, f"{time.time() - t0:.2f}"])
                print(f"width {width}: undecided at length {L}", flush=True)
                break
            if st == "UNSAT":
                w.writerow([width, L, nodes, f"{time.time() - t0:.2f}"])
                print(f"width {width}: no valid strip of length {L} ({nodes:,} nodes)", flush=True)
                break
        else:
            w.writerow([width, f"none up to {max_len}", "", ""])
            print(f"width {width}: valid strips up to length {max_len}", flush=True)
