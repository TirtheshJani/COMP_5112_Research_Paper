"""Exact search over the XOR family a_i xor b_j for 5 x 5 windows: every shape 1 <= R <= C with
4RC <= 480 (the family's cap). Writes research/results/xor_table.csv."""
import csv, os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from otorus.construct import solve_xor, xor_torus
from otorus.windows import is_orientable, min_window_distance

root = os.path.join(os.path.dirname(__file__), "..", "..", "results")
shapes = sorted({(R, C) for R in range(1, 121) for C in range(R, 121) if R * C <= 120}, key=lambda p: (p[0] * p[1], p))
with open(os.path.join(root, "xor_table.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["R", "C", "RC", "status", "seconds", "A", "B", "min_distance"])
    for R, C in shapes:
        t0 = time.time()
        st, A, B = solve_xor(R, C, timeout=600)
        a = b = md = ""
        if st == "SAT":
            T = xor_torus(A, B)
            assert is_orientable(T, 5, 5, 4)
            a, b, md = "".join(map(str, A)), "".join(map(str, B)), min_window_distance(T, 5, 5, 4)
        w.writerow([R, C, R * C, st, f"{time.time()-t0:.1f}", a, b, md]); f.flush()
        if st != "UNSAT":
            print(f"{R}x{C}: {st} md={md}", flush=True)
print("done", len(shapes), "shapes", flush=True)
