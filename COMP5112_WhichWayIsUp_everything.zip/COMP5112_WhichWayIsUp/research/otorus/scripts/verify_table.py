"""Re-decide every shape of the SAT table with the two independent methods and record agreement.
Usage: python3 scripts/verify_table.py u v s delta dfs_max_nodes alt_timeout
Writes research/results/verify_<u>x<v>_s<s>_d<delta>.csv (resumable)."""
import csv, os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from otorus.exhaustive import dfs_search
from otorus.sat import solve_torus_alt
from otorus.windows import is_orientable, min_window_distance

u, v, s, delta = (int(x) for x in sys.argv[1:5])
max_nodes, alt_timeout = int(float(sys.argv[5])), int(sys.argv[6])
root = os.path.join(os.path.dirname(__file__), "..", "..", "results")
rows = [r for r in csv.DictReader(open(os.path.join(root, "sat_table.csv")))
        if (int(r["u"]), int(r["v"]), int(r["s"]), int(r["delta"])) == (u, v, s, delta)]
rows.sort(key=lambda r: (int(r["RC"]), int(r["R"])))
tag = "" if alt_timeout > 0 else "_dfs"
out = os.path.join(root, f"verify_{u}x{v}_s{s}_d{delta}{tag}.csv")
done = set()
if os.path.exists(out):
    done = {(int(r["R"]), int(r["C"])) for r in csv.DictReader(open(out))}
else:
    with open(out, "w", newline="") as f:
        csv.writer(f).writerow(["R", "C", "RC", "sat_status", "dfs_status", "dfs_nodes", "dfs_seconds",
                                "alt_status", "alt_seconds", "witnesses_checked", "agree"])
for r in rows:
    R, C = int(r["R"]), int(r["C"])
    if (R, C) in done:
        continue
    t0 = time.time()
    ds, dT, nodes = dfs_search(R, C, u, v, s, delta, max_nodes=max_nodes)
    t1 = time.time()
    if alt_timeout > 0:
        as_, aT = solve_torus_alt(R, C, u, v, s, delta, timeout=alt_timeout)
    else:
        as_, aT = "SKIPPED", None
    t2 = time.time()
    checked = all(is_orientable(T, u, v, s) and (delta == 1 or min_window_distance(T, u, v, s) >= delta)
                  for T in (dT, aT) if T is not None)
    decided = {x for x in (r["status"], ds, as_) if x in ("SAT", "UNSAT")}
    agree = "yes" if len(decided) == 1 and checked else ("CONFLICT" if len(decided) > 1 or not checked else "undecided")
    with open(out, "a", newline="") as f:
        csv.writer(f).writerow([R, C, R * C, r["status"], ds, nodes, f"{t1-t0:.1f}", as_, f"{t2-t1:.1f}", checked, agree])
    print(f"{R}x{C} RC={R*C}: sat={r['status']} dfs={ds} ({nodes:,} nodes, {t1-t0:.1f}s) alt={as_} ({t2-t1:.1f}s) agree={agree}", flush=True)
