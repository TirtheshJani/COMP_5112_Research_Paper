import numpy as np
from otorus.decode import Decoder
from otorus.construct import xor_torus
from otorus.windows import window


def test_decodes_every_turned_window_of_the_6x6_xor_torus():
    E = xor_torus([0,0,0,0,0,1], [0,0,1,0,1,1])
    dec = Decoder(E, 5, s=4)
    for i in range(6):
        for j in range(6):
            W = window(E, i, j, 5, 5)
            for k in range(4):
                assert dec.decode(np.rot90(W, k)) == (i, j, k)


def test_unknown_window_returns_none():
    E = xor_torus([0,0,0,0,0,1], [0,0,1,0,1,1])
    dec = Decoder(E, 5, s=4)
    W = window(E, 2, 3, 5, 5).copy()
    W[2, 2] ^= 1   # one misread cell: distance 5 torus, so this is never another window
    assert dec.decode(W) is None


def test_batch_decode_matches_single_decode():
    E = xor_torus([0,0,0,0,0,1], [0,0,1,0,1,1])
    dec = Decoder(E, 5, s=4)
    rng = np.random.default_rng(0)
    Ws = [np.rot90(window(E, int(rng.integers(6)), int(rng.integers(6)), 5, 5), int(rng.integers(4))) for _ in range(20)]
    Ws.append(np.zeros((5, 5), dtype=np.uint8))
    got = dec.decode_batch(np.array(Ws))
    for W, g in zip(Ws, got):
        want = dec.decode(W)
        assert (tuple(g) if g[0] >= 0 else None) == want
