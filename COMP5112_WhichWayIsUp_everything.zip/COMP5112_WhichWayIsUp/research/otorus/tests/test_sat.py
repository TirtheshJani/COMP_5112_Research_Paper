import numpy as np
from otorus.sat import solve_torus
from otorus.windows import is_orientable, min_window_distance

def test_4x4_de_bruijn_2x2_is_sat_and_witness_valid():
    status, T = solve_torus(4, 4, 2, 2, s=1, delta=1, timeout=30)
    assert status == "SAT"
    assert T.shape == (4, 4)
    assert is_orientable(T, 2, 2, 1)

def test_2x8_de_bruijn_2x2_is_unsat():
    status, T = solve_torus(2, 8, 2, 2, s=1, delta=1, timeout=30)
    assert status == "UNSAT"
    assert T is None

def test_6x6_strong_form_5x5_is_sat():
    status, T = solve_torus(6, 6, 5, 5, s=4, delta=2, timeout=60)
    assert status == "SAT"
    assert is_orientable(T, 5, 5, 4)
    assert min_window_distance(T, 5, 5, s=4) >= 2

def test_delta2_rejects_distance1_solution():
    # 4 x 4 de Bruijn torus for 2 x 2 windows has distance exactly 1, so delta=2 at the full
    # count of 16 windows is impossible: only 8 of the 16 patterns can be used.
    status, T = solve_torus(4, 4, 2, 2, s=1, delta=2, timeout=30)
    assert status == "UNSAT"
