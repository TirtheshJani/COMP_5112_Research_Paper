import numpy as np
from otorus.camera import simulate_reads
from otorus.decode import Decoder
from otorus.construct import xor_torus


def test_perfect_camera_always_decodes_correctly():
    E = xor_torus([0,0,0,0,0,1], [0,0,1,0,1,1])
    dec = Decoder(E, 5, s=4)
    reads, truth, n_err = simulate_reads(E, 5, 500, np.random.default_rng(0))
    assert (n_err == 0).all()
    assert (dec.decode_batch(reads) == truth).all()


def test_all_four_quarter_turns_occur():
    E = xor_torus([0,0,0,0,0,1], [0,0,1,0,1,1])
    reads, truth, n_err = simulate_reads(E, 5, 400, np.random.default_rng(1))
    assert set(truth[:, 2].tolist()) == {0, 1, 2, 3}


def test_noise_creates_errors_and_single_errors_are_never_wrong_on_a_distance_5_torus():
    E = xor_torus([0,0,0,0,0,1], [0,0,1,0,1,1])
    dec = Decoder(E, 5, s=4)
    reads, truth, n_err = simulate_reads(E, 5, 3000, np.random.default_rng(2), blur=0.15, noise=0.25,
                                         angle_deg=2.0, offset=0.08)
    assert (n_err > 0).any()
    got = dec.decode_batch(reads)
    single = n_err == 1
    assert single.any()
    assert (got[single, 0] == -1).all()          # rejected, never a wrong position
    assert (got[n_err == 0] == truth[n_err == 0]).all()
