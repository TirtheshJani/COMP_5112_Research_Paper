import numpy as np
from otorus.windows import window, all_windows, rotations, pack, is_orientable, min_window_distance
from otorus.construct import construction_e, xor_torus

T44 = np.array([[0,0,0,1],[0,0,1,0],[1,0,1,1],[0,1,1,1]], dtype=np.uint8)

def test_window_wraps_both_ways():
    assert window(T44, 3, 3, 2, 2).tolist() == [[1,0],[1,0]]

def test_t44_is_de_bruijn():
    ws = all_windows(T44, 2, 2)
    assert len(ws) == 16
    assert len(set(pack(w) for w in ws)) == 16

def test_t44_not_2_orientable():
    assert is_orientable(T44, 2, 2, 1)
    assert not is_orientable(T44, 2, 2, 2)

def test_rotations_count_and_order():
    w = np.arange(25, dtype=np.uint8).reshape(5, 5)
    rs = rotations(w)
    assert len(rs) == 4
    assert np.array_equal(rs[0], w)
    assert np.array_equal(rs[2], np.rot90(w, 2))

def test_pack_is_row_major_bits():
    w = np.array([[1,0],[0,1]], dtype=np.uint8)
    assert pack(w) == 0b1001

def test_fig6_is_4_orientable():
    A = B = [1,1,0,1,0,0]
    E = construction_e(A, B, 2)
    assert E.shape == (6, 6)
    assert is_orientable(E, 5, 5, 4)

def test_theorem17_needs_2_orientable_B():
    bad = construction_e([1,1,0,0], [1,1,0,0], 2)
    assert not is_orientable(bad, 2, 2, 2)

def test_min_distance_de_bruijn_is_one():
    assert min_window_distance(T44, 2, 2, s=1) == 1

def test_xor_6x6_is_4_orientable_with_distance_5():
    E = xor_torus([0,0,0,0,0,1], [0,0,1,0,1,1])
    assert E.shape == (6, 6)
    assert is_orientable(E, 5, 5, 4)
    assert min_window_distance(E, 5, 5, s=4) == 5

def test_xor_equal_sequences_not_2_orientable():
    E = xor_torus([0,0,1,0,1,1], [0,0,1,0,1,1])
    assert is_orientable(E, 5, 5, 1)
    assert not is_orientable(E, 5, 5, 2)


def test_fast_codes_match_packed_turned_windows():
    from otorus.windows import turned_window_codes, packed_turned_windows
    rng = np.random.default_rng(3)
    for (R, C, u, s) in [(5, 7, 3, 4), (6, 6, 5, 4), (4, 9, 2, 2), (7, 5, 3, 1)]:
        T = rng.integers(0, 2, size=(R, C), dtype=np.uint8)
        assert sorted(turned_window_codes(T, u, s).tolist()) == sorted(packed_turned_windows(T, u, u, s))


def test_fast_min_distance_matches_brute_force():
    from otorus.windows import min_distance_fast
    rng = np.random.default_rng(4)
    for _ in range(30):
        T = rng.integers(0, 2, size=(int(rng.integers(3, 8)), int(rng.integers(3, 8))), dtype=np.uint8)
        exact = min_window_distance(T, 3, 3, s=4)
        assert min_distance_fast(T, 3, 4, rmax=2) == min(exact, 3)
    E = xor_torus([0,0,0,0,0,1], [0,0,1,0,1,1])
    assert min_distance_fast(E, 5, 4, rmax=2) == 3   # true distance is 5, reported as "at least 3"
