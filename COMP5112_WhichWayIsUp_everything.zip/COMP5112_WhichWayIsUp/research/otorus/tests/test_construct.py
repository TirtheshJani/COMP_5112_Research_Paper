import numpy as np
import pytest
from otorus.construct import interleave_checkerboard, random_window_cycle, xor_torus


def test_checkerboard_interleave_layout():
    A, B = [1, 0, 1, 1], [0, 0, 1, 1, 0, 1]
    T = interleave_checkerboard(A, B)
    assert T.shape == (4, 6)
    for i in range(4):
        for j in range(6):
            assert T[i, j] == (A[i] if (i + j) % 2 == 0 else B[j])


def test_checkerboard_interleave_needs_even_periods():
    with pytest.raises(ValueError):
        interleave_checkerboard([1, 0, 1], [0, 1])


def test_random_window_cycle_has_distinct_allowed_windows():
    rng = np.random.default_rng(0)
    banned = {"00000", "11111", "01010", "10101"}
    for L in (6, 12, 20, 28):
        seq = random_window_cycle(5, L, banned, rng)
        assert seq is not None and len(seq) == L
        wins = ["".join(str(seq[(t + k) % L]) for k in range(5)) for t in range(L)]
        assert len(set(wins)) == L and not (set(wins) & banned)


def test_random_window_cycle_returns_none_when_impossible():
    rng = np.random.default_rng(0)
    assert random_window_cycle(5, 29, {"00000", "11111", "01010", "10101"}, rng, max_tries=50) is None


def _descriptors_distinct(A, B):
    from otorus.construct import interleave_descriptors
    v = np.concatenate([A, B])
    D = interleave_descriptors(len(A), len(B))
    words = {tuple(v[d].ravel().tolist()) for d in D}
    return len(words) == len(D)


def test_descriptor_criterion_matches_direct_check_on_random_pairs():
    # Claim: for label sequences avoiding 00000, 11111, 01010, 10101, the interleave is
    # 4-orientable iff its 2RC type-0 descriptors are distinct, and then its window distance is >= 2.
    from otorus.windows import min_distance_fast
    rng = np.random.default_rng(5)
    banned = {"00000", "11111", "01010", "10101"}
    seen = {True: 0, False: 0}
    for R, C in [(6, 6), (6, 8), (8, 8), (6, 28), (10, 10), (4, 12)]:
        for _ in range(60):
            A = random_window_cycle(5, R, banned, rng)
            B = random_window_cycle(5, C, banned, rng)
            md = min_distance_fast(interleave_checkerboard(A, B), 5, 4, rmax=1)
            ok = _descriptors_distinct(A, B)
            assert ok == (md >= 1), (A, B)
            assert (not ok) or md == 2
            seen[ok] += 1
    assert seen[True] > 0 and seen[False] > 0


def test_solve_interleave_finds_valid_pair_and_proves_impossible_shape():
    from otorus.construct import solve_interleave
    from otorus.windows import min_distance_fast
    status, A, B = solve_interleave(6, 28, timeout=120)
    assert status == "SAT"
    assert min_distance_fast(interleave_checkerboard(A, B), 5, 4, rmax=1) == 2
    assert solve_interleave(28, 30, timeout=60)[0] == "UNSAT"   # 2*R*C = 1680 > 784 descriptor pairs


def test_solve_interleave_with_fixed_row_sequence():
    from otorus.construct import solve_interleave
    from otorus.windows import min_distance_fast
    st, A, B = solve_interleave(6, 20, timeout=120, fix_a=[1, 1, 0, 1, 0, 0])
    assert st == "SAT" and A.tolist() == [1, 1, 0, 1, 0, 0]
    assert min_distance_fast(interleave_checkerboard(A, B), 5, 4, rmax=1) == 2


def test_xor_window_family_facts():
    # The 5 x 5 windows x_p xor y_q: 512 of them, closed under quarter turns, 32 fixed by the half
    # turn, and any two distinct ones differ in at least 5 cells. So a 4-orientable XOR torus has
    # window distance >= 5 and R*C <= (512 - 32) / 4 = 120.
    import itertools
    wins = {tuple(np.bitwise_xor.outer(np.array(x), np.array(y)).ravel())
            for x in itertools.product((0, 1), repeat=5) for y in itertools.product((0, 1), repeat=5)}
    assert len(wins) == 512
    M = {w: np.array(w).reshape(5, 5) for w in wins}
    assert all(tuple(np.rot90(m).ravel()) in wins for m in M.values())
    assert sum(np.array_equal(np.rot90(m, 2), m) for m in M.values()) == 32
    L = np.array(list(wins))
    d = min(int((L[a] != L[a + 1:]).sum(axis=1).min()) for a in range(len(L) - 1))
    assert d == 5


def test_xor_descriptor_criterion_matches_direct_check():
    from otorus.construct import xor_descriptors_distinct
    from otorus.windows import is_orientable
    rng = np.random.default_rng(9)
    seen = {True: 0, False: 0}
    for R, C in [(5, 6), (6, 6), (4, 7), (6, 9), (3, 8)]:
        for _ in range(200):
            A = rng.integers(0, 2, R); B = rng.integers(0, 2, C)
            ok = xor_descriptors_distinct(A, B)
            assert ok == is_orientable(xor_torus(A, B), 5, 5, 4), (A, B)
            seen[ok] += 1
    assert seen[True] > 0 and seen[False] > 0


def test_solve_xor_known_cases():
    from otorus.construct import solve_xor
    assert solve_xor(6, 6, timeout=60)[0] == "SAT"
    assert solve_xor(6, 7, timeout=60)[0] == "UNSAT"
