import numpy as np
from otorus.search import local_search, energy, SearchState
from otorus.windows import is_orientable, min_window_distance


def test_energy_counts_bad_pairs_by_brute_force():
    rng = np.random.default_rng(1)
    T = rng.integers(0, 2, size=(5, 7), dtype=np.uint8)
    # brute force: pairs of turned windows at distance < delta
    from otorus.windows import packed_turned_windows
    codes = packed_turned_windows(T, 3, 3, 4)
    for delta in (1, 2):
        bad = sum(1 for a in range(len(codes)) for b in range(a + 1, len(codes))
                  if bin(codes[a] ^ codes[b]).count("1") < delta)
        assert energy(T, 3, 4, delta) == bad


def test_incremental_energy_stays_exact_under_flips():
    rng = np.random.default_rng(2)
    T = rng.integers(0, 2, size=(6, 8), dtype=np.uint8)
    st = SearchState(T, u=3, s=4, delta=2)
    for _ in range(200):
        x = int(rng.integers(0, 48))
        st.flip(x)
        assert st.energy == energy(st.torus(), 3, 4, 2)


def test_finds_non_extremal_strong_form_3x3_solution():
    # 3 x 6 is well below the proved 3x3 maximum of 36 cells; extremal shapes are left to SAT.
    results = [local_search(3, 6, 3, s=4, delta=2, seed=seed, max_flips=200_000, temp=1.0) for seed in range(10)]
    solved = [T for T, E, flips in results if E == 0]
    assert solved
    for T in solved:
        assert is_orientable(T, 3, 3, 4) and min_window_distance(T, 3, 3, s=4) >= 2


def test_cannot_beat_proved_3x3_maximum():
    T, E, flips = local_search(7, 7, 3, s=4, delta=2, seed=0, max_flips=200_000)
    assert E > 0


def test_finds_5x5_strong_form_64x64():
    T, E, flips = local_search(64, 64, 5, s=4, delta=2, seed=0, max_flips=1_000_000)
    assert E == 0
    from otorus.windows import min_distance_fast
    assert min_distance_fast(T, 5, 4, rmax=1) == 2


def test_single_long_run_does_not_stall_at_256():
    # Regression: without periodic full rescans the conflict list could hold only one partner of a
    # conflict, and a single run stalled (energy 38 after 3M flips); chunked runs solved in 0.65M.
    T, E, flips = local_search(256, 256, 5, s=4, delta=2, seed=0, max_flips=3_000_000, temp=0.5)
    assert E == 0
