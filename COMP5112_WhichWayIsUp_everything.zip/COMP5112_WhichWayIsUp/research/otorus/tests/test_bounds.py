from otorus.bounds import fixed_by_rot90, fixed_by_rot180, even_fixed_by_rot180, ceiling

def test_fixed_window_counts_5x5():
    assert fixed_by_rot90(5) == 2**7
    assert fixed_by_rot180(5) == 2**13
    assert even_fixed_by_rot180(5) == 2**12

def test_fixed_window_counts_3x3():
    assert fixed_by_rot90(3) == 2**3
    assert fixed_by_rot180(3) == 2**5

def test_lemma19_ceilings():
    assert ceiling(5, 5, s=4, delta=1) == 8_386_560
    assert ceiling(5, 5, s=2, delta=1) == 16_773_120
    assert ceiling(5, 5, s=1, delta=1) == 2**25
    assert ceiling(3, 3, s=4, delta=1) == 120

def test_strong_form_distance2_ceilings():
    assert ceiling(5, 5, s=4, delta=2) == 4_193_280
    assert ceiling(3, 3, s=4, delta=2) == 60
    assert ceiling(5, 5, s=1, delta=2) == 2**24


def test_even_window_distance2_ceilings():
    # Even sides have no centre cell; every half-turn-fixed window has even weight, so the odd
    # windows (2^(uv-1) of them) are all usable and form a maximum independent set.
    assert ceiling(4, 4, s=4, delta=2) == 8192
    assert ceiling(2, 2, s=4, delta=2) == 2
    assert ceiling(4, 4, s=1, delta=2) == 2**15
    assert ceiling(4, 4, s=4, delta=1) == 16320


def test_distance2_ceiling_equals_max_independent_set_of_free_windows():
    import pytest
    pytest.importorskip("scipy")
    from otorus.bounds import max_independent_free
    for u in (2, 3, 4):
        mis = max_independent_free(u)
        for s in (2, 4):
            assert s * ceiling(u, u, s, delta=2) == mis
