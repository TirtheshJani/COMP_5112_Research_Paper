"""The exhaustive search must not share its window bookkeeping with sat.py (peer review 1, finding 4).
otorus.exhaustive.turned_cells is written with explicit index arithmetic for the quarter turn; these
tests cross-check it against sat._instances and against a direct reading of np.rot90 on real tori."""
import numpy as np
import pytest

from otorus import exhaustive
from otorus.sat import _instances


@pytest.mark.parametrize("R,C,u,s", [(3, 3, 3, 4), (4, 7, 3, 4), (6, 6, 5, 4), (5, 8, 4, 2), (2, 3, 3, 1)])
def test_turned_cells_match_sat_instances(R, C, u, s):
    mine = sorted(tuple(c) for c in exhaustive.turned_cells(R, C, u, s))
    theirs = sorted(tuple(cells) for (_, _, _, cells) in _instances(R, C, u, u, s))
    assert mine == theirs


def test_turned_cells_read_rot90_windows():
    rng = np.random.default_rng(3)
    T = rng.integers(0, 2, (5, 7))
    flat = T.ravel()
    got = {tuple(flat[c]) for c in exhaustive.turned_cells(5, 7, 3, 4)}
    want = set()
    for i in range(5):
        for j in range(7):
            W = T[np.ix_([(i + a) % 5 for a in range(3)], [(j + b) % 7 for b in range(3)])]
            for k in range(4):
                want.add(tuple(np.rot90(W, k).ravel()))
    assert got == want


def test_open_rows_drop_wrapping_windows():
    # 6 rows that do not wrap give 6 - 3 + 1 = 4 row positions; columns wrap.
    cells = exhaustive.turned_cells(6, 5, 3, 4, wrap_rows=False)
    assert len(cells) == 4 * 5 * 4
    for c in cells:
        rows = {x // 5 for x in c}
        assert max(rows) - min(rows) == 2


def test_dfs_still_matches_known_3x3_table():
    assert exhaustive.dfs_search(6, 6, 3, 3, 4, 2)[0] == "SAT"
    assert exhaustive.dfs_search(3, 12, 3, 3, 4, 2)[0] == "SAT"
    assert exhaustive.dfs_search(3, 10, 3, 3, 4, 2)[0] == "UNSAT"
    assert exhaustive.dfs_search(4, 9, 3, 3, 4, 2)[0] == "UNSAT"


def test_open_patch_lists_only_interior_windows():
    # No wrap in either direction: (R - u + 1) * (C - u + 1) positions, s turns each.
    cells = exhaustive.turned_cells(9, 8, 3, 4, wrap_rows=False, wrap_cols=False)
    assert len(cells) == 7 * 6 * 4
    for c in cells:
        rows = {x // 8 for x in c}
        cols = {x % 8 for x in c}
        assert max(rows) - min(rows) == 2 and max(cols) - min(cols) == 2


def test_reviewer_open_patch_is_valid_at_distance_2():
    # Peer review 2, finding A: an open 9 x 8 patch whose 168 turned 3 x 3 windows are pairwise
    # at distance >= 2 (more than the 144 turned windows of the largest strong-form torus).
    rows = ["01110111", "10011011", "00010011", "10101100", "10011011",
            "11001000", "00011010", "10011011", "11001000"]
    T = np.array([[int(ch) for ch in r] for r in rows])
    flat = T.ravel()
    codes = [tuple(flat[c]) for c in exhaustive.turned_cells(9, 8, 3, 4, wrap_rows=False, wrap_cols=False)]
    assert len(codes) == 168
    dmin = min(sum(a != b for a, b in zip(x, y)) for i, x in enumerate(codes) for y in codes[i + 1:])
    assert dmin == 2
