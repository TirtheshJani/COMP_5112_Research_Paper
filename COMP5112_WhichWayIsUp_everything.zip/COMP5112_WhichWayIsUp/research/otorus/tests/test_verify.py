"""Independent checks of the SAT results: an exhaustive depth-first search and a second SAT
encoding (fresh auxiliaries, sequential-counter cardinality, no symmetry breaking, Glucose)."""
import numpy as np
from otorus.exhaustive import dfs_search
from otorus.sat import solve_torus_alt
from otorus.windows import is_orientable, min_window_distance


def test_dfs_known_2x2_cases():
    assert dfs_search(4, 4, 2, 2, s=1, delta=1)[0] == "SAT"
    assert dfs_search(2, 8, 2, 2, s=1, delta=1)[0] == "UNSAT"
    assert dfs_search(4, 4, 2, 2, s=1, delta=2)[0] == "UNSAT"


def test_dfs_strong_form_3x3_matches_sat_table():
    for R, C, want in [(3, 3, "SAT"), (3, 6, "SAT"), (4, 4, "UNSAT"), (3, 7, "UNSAT"), (4, 5, "UNSAT")]:
        assert dfs_search(R, C, 3, 3, s=4, delta=2)[0] == want, (R, C)


def test_dfs_witness_is_valid():
    status, T, nodes = dfs_search(3, 9, 3, 3, s=4, delta=2)
    assert status == "SAT"
    assert is_orientable(T, 3, 3, 4) and min_window_distance(T, 3, 3, s=4) >= 2


def test_dfs_node_limit():
    status, T, nodes = dfs_search(6, 6, 3, 3, s=4, delta=2, max_nodes=10)
    assert status == "LIMIT" and T is None


def test_alt_encoding_matches_known_cases():
    assert solve_torus_alt(4, 4, 2, 2, s=1, delta=1)[0] == "SAT"
    assert solve_torus_alt(2, 8, 2, 2, s=1, delta=1)[0] == "UNSAT"
    assert solve_torus_alt(4, 4, 2, 2, s=1, delta=2)[0] == "UNSAT"
    for R, C, want in [(3, 6, "SAT"), (4, 4, "UNSAT"), (3, 7, "UNSAT")]:
        assert solve_torus_alt(R, C, 3, 3, s=4, delta=2)[0] == want, (R, C)


def test_alt_encoding_witness_is_valid():
    status, T = solve_torus_alt(6, 6, 3, 3, s=4, delta=2)
    assert status == "SAT"
    assert is_orientable(T, 3, 3, 4) and min_window_distance(T, 3, 3, s=4) >= 2


def test_dfs_thin_shape_solved_via_transpose_and_witness_has_requested_shape():
    status, T, nodes = dfs_search(3, 9, 3, 3, s=4, delta=2)
    assert status == "SAT" and T.shape == (3, 9)
    assert is_orientable(T, 3, 3, 4) and min_window_distance(T, 3, 3, s=4) >= 2
    # filling along the short side prunes far earlier: 3 x 11 is UNSAT within a small node budget
    assert dfs_search(3, 11, 3, 3, s=4, delta=2, max_nodes=20_000_000)[0] == "UNSAT"
