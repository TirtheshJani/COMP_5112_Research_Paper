# 07. Threat checks: US 5,442,147, Garrido-Jurado et al., Lloyd and Burns

Written 2026-11-07 by the threat-check agent. Claim under test: no print document combines (i) 4-orientability (pairwise distinct 5 x 5 windows under the four quarter turns) with (ii) pairwise Hamming distance of at least 2 between all those windows, for a doubly periodic binary array. Test applied to each document: does it contain both (a) an array or pattern whose windows stay distinguishable under rotation, any alphabet, periodic or not, and (b) any minimum Hamming distance, error detection or error correction requirement between windows, turned or not. Having only one of the two is not a threat. Citation keys in square brackets already exist in the student's bibliography unless marked NEW. No em dashes are used in this file.

## 0. Summary

| Document | What was read | (a) orientability | (b) distance or error handling | Verdict |
|---|---|---|---|---|
| US 5,442,147 and relatives | Full Google Patents text, all five 100,000-character windows, all 57 claims, through a summarising fetch tool; four forward citations or neighbours | Yes, strongly | No (procedural tracking checks only) | NO THREAT |
| Garrido-Jurado et al. 2014 and 2016 | 2014: complete article through a summarising fetch tool. 2016: abstract only | Yes, but only as self-distance of isolated square markers | Yes, but only as pairwise distance of isolated square markers | NO THREAT for the claim (close prior art for the distance definition) |
| Lloyd and Burns 1993 | Not reachable; descriptions in three citing documents | Not indicated | Not indicated | INCONCLUSIVE (document unread, indirect evidence points to no threat) |

Overall: none of the three documents the combination (i) plus (ii); the patent has orientability without any distance requirement, the Garrido-Jurado dictionaries have a rotation-aware distance only for isolated markers that share no cells, and the Lloyd and Burns chapter, which could not be obtained, is described by its citers as exact decoding of binary pseudorandom arrays.

A tool caveat that applies to every web result below. WebFetch does not return raw page text. It passes the page through a small model that answers the prompt it is given, so a negative keyword result means "the tool reported no occurrence", not "grep confirmed no occurrence", and positional statements ("this window covers Appendix D") are not fully reliable. For example, the tool described the 100,000 to 200,000 and 200,000 to 300,000 character windows of the patent page with overlapping figure ranges. Where a direct text layer was available (the local PDFs), I used pdftotext and grep instead and say so.

## 1. US 5,442,147, "Position-sensing apparatus" (Hewlett-Packard)

### Coverage

Google Patents page https://patents.google.com/patent/US5442147A/en returned 448,112 characters. I ran keyword-targeted prompts over every window of 100,000 characters: 0 to 100,000 (abstract, summary, orientation definitions, early description), 100,000 to 200,000 (the part the earlier agent also read), 200,000 to 300,000 (example implementation, applications, variants, start of the appendices), 300,000 to 400,000 (end of Appendix C, Appendix D, all claims 1 to 57, start of the Cited By table), and 400,000 to 448,112 (rest of the citation tables, Also Published As, Similar Documents). The words searched were Hamming, distance, error, errors, misread, noise, noisy, tolerance, tolerant, tolerate, detect, correct, redundan, differ, parity and check. A direct curl of the same page returned an HTTP 503 anti-bot "Sorry" page, so I stopped using curl there and relied on WebFetch only. The USPTO print PDF (image-ppubs.uspto.gov, number 5442147) has no text layer, so it gave nothing.

### Findings on the description

Hamming, redundan, parity, misread and tolerance (the exact word) did not occur. "Tolerate" occurs once, where the design is said to be able to tolerate errors arising from diagonal transitions between cells instead of preventing or detecting them; that is a design choice about a sensing artefact, not a distance requirement. "Error" appears only in procedural senses: sensing errors during reversal recovery, and accumulated bits that are "in error" in the absolute tracking register, which the register discards as it shifts. "Noise" appears once, for modulated and synchronously detected light sources in the opto-electronics. "Distance" is physical (sensor movement by one cell pitch). "Differ" and "check" occur in the tracker comparing a predicted bit with a sensed bit and in consistency checks of the movement-direction assumption. The patent defines 1-orientable, 2-orientable and 4-orientable patterns (a sub-pattern can be located only in the pattern's own orientation, in two of four, or in all four), which is the Burns and Mitchell notion. Appendices C and D give discrete-logarithm position finding in one-dimensional and two-dimensional pseudo-random arrays; Appendix D cites only MacWilliams and Sloane and treats exact sensed windows, with no rotation or bit errors.

### Findings on the claims

All 57 claims were returned as a claim-by-claim paraphrase. Claims 1 and 51 are independent (claim 40, a pattern-element claim, was labelled dependent in form by the tool, which I did not confirm). Orientation appears in claims 2 and 4 (M = 4 orientations, a sub-pattern locatable in N of them, N = 1, 2 or 4), 25 to 28 and 57 (sensor orientation fixed, or variable with orientation information supplied separately), and claims 8, 10, 13, 48 and 49 (orientable and complement-orientable sequences, which concern reversal, not quarter turns). No claim recites a minimum distance or difference between windows, and none recites error detection, error correction or redundancy. Claims 15 to 17 and 41 require local differences between neighbouring cells, which is a cell-level contrast rule, not a window distance. Claims 32 to 35 and 52 to 54 reject candidate positions that mismatch the sensed sequence, which is a consistency check in a recovery routine, not a code.

### Family and forward citations

Google lists as Also Published As: WO1992017859A1 (1992-10-15), EP0578692A1 (1994-01-19), EP0578692B1 (1995-06-14), DE69202975D1 and T2, and JPH06506080A. No US continuation or divisional is listed in what I received. The two EP pages (EP0578692A1 and B1) failed to load (server error, one retry blocked by the tool), so the European text was not read; the PCT, EP and US texts are normally the same specification. US 5,675,129 ("Initial track recovery in position-sensing systems that use windowing patterns", listed under Similar Documents) was read from the USPTO text layer (roughly 10,000 words, independent claims 1 and 8): it discusses orientable and complement-orientable sequences and 1- and 2-orientable patterns, mentions a co-pending PCT/GB92/00594 (I could not match that number to the WO publication, so "sibling" is likely but not confirmed), and has no Hamming distance, minimum difference or error correction; it treats mismatches caused by sensing errors only as grounds for rejecting hypotheses.

Google shows 270 documents in Cited By (Silverbrook, Anoto, Microsoft and others); I saw only the part of that table that fits in the last windows. I read four neighbours. US 7,445,160 B2 ("Position location using error correction"; USPTO text, 20 claims, independent 1, 15, 20): a nine-symbol coding pattern on paper in 5 x 5 regions. Each region has four fixed registration symbols (value 8) that carry no position information; orientation and offset are found by matching against 100 templates (4 rotations times 25 offsets) by minimum Hamming distance, rejecting a reading when two candidates tie or the best distance is 2 or more. Position data are Reed-Solomon codewords, [7,5,3] over GF(8). So it has distance-based decoding and rotation handling, but the rotation is resolved by a fixed registration mark, not by the data windows being distinct under quarter turns, the alphabet is not binary, the pattern is not a periodic window array, and the text states no minimum distance between the templates. US 7,583,842 B2 (Google page text, claims missing from the retrieved text) and US 7,729,539 B2 (USPTO text) decode an m-array by counting error bits as a Hamming distance between observed and recomputed bits, and fix orientation by finding which corner type is missing from the grid (7,583,842) or by a separate mechanism; neither requires a minimum distance between windows. US 6,208,771 B1 (glyph address carpets, from Similar Documents; USPTO text of about 80,000 characters) finds 0/180 versus 90/270 orientation from the address code itself by correlation and handles errors by majority voting along diagonals; it states no distance requirement between windows. US 2004/0085287 A1 ("Decoding and error correction in 2-D arrays") failed to load and is unread.

### Verdict: NO THREAT

The patent has property (a) in its strongest form and property (b) not at all; nothing in the description or the claims asks for distance, detection or correction between windows.

### Unread

The European text, US 2004/0085287 A1, the claims of US 7,583,842 B2, and about 265 of the 270 forward citations. Because the 270-document list is dominated by coding-pattern families (Anoto, Silverbrook, Microsoft), a human check of the Anoto and Silverbrook "coding pattern" families for the pair "orientation-distinct tiles plus a distance requirement" would be the most useful remaining patent search. US 7,445,160 B2 is the nearest neighbour found and is worth citing in a related-work sentence on industrial position-coding patterns.

## 2. Garrido-Jurado, Munoz-Salinas, Madrid-Cuevas, Medina-Carnicer 2016, and the 2014 ArUco paper

### Coverage

Both DOIs were checked on Crossref: 10.1016/j.patcog.2015.09.023 (Pattern Recognition 51, pp. 481 to 491, March 2016, four authors as stated) and 10.1016/j.patcog.2014.01.005 (Pattern Recognition 47(6), pp. 2280 to 2292, June 2014; the authors are Garrido-Jurado, Munoz-Salinas, Madrid-Cuevas and Marin-Jimenez, not Medina-Carnicer). The 2014 paper: a reading copy at https://cs-courses.mines.edu/csci507/schedule/24/ArUco.pdf gave the complete article (abstract, Sections 1 to 7, appendix pointer, references 1 to 47) through the summarising fetch tool; figures only as captions. The 2016 paper: only the abstract and subject terms, from a library catalogue record (ersearch2.cvtisr.sk Summon record), and Crossref metadata (Crossref has no abstract). The body of the 2016 paper and its supplementary material were not read. Routes that failed: ScienceDirect page (client error), Semantic Scholar API (client error), Bohrium (web-application firewall challenge page), AMiner (returned only the site home page), the group page https://www.uco.es/investiga/grupos/ava/node/26 (lists both papers by title but the tool saw no PDF links), and Unpaywall, which answers HTTP 422 to the placeholder address research@example.com, so no open-access location could be determined that way. A 2023 paper from the same group (Sensors 23(24):9649, open access) was sampled for its first 100,000 of 497,186 characters; it describes separate markers per face and CRC-based checking, and no shared-cell grids.

### Findings

The 2014 paper defines the distance between two markers as the minimum, over the four quarter turns of one of them, of the Hamming distance to the other, and defines a marker's self-distance as the minimum Hamming distance between the marker and its own three nontrivial turns. A candidate joins the dictionary only if its self-distance and its distance to every member are at least tau; the dictionary distance is the smallest of these, and up to floor((tau-1)/2) bit errors are detected and corrected by nearest-marker search. It gives an upper bound on self-distance from the quartet structure of an n x n grid (quartets of cells that rotate into each other), and an example 6 x 6 dictionary of 30 markers with distance 12, correcting 5 bits. The tool reported that the paper discusses no de Bruijn sequences, m-arrays, perfect maps, tori or periodic encoding, that multi-marker boards place separate markers in one frame without shared cells, and that the reference list has no Burns, Mitchell or orientable-sequence work. The 2016 abstract says the paper gives two mixed integer linear programming approaches (an exact one for small dictionaries and a time-limited heuristic one) to build configurable dictionaries that maximise inter-marker distance, so the markers correct more erroneous bits; it mentions no grid or array variant. Citing papers in the local pool treat these as standard planar fiducials: HydraMarker lists the 2016 paper only in its reference list, and PuzzleBoard and PuzzlePoles cite the 2014 paper as the ArUco reference.

In terms of the test: for isolated square markers the dictionary does have both ingredients, a self-distance across the four turns (property (a) in a weak, whole-marker sense) and a pairwise distance over turns (property (b)). That is the closest published form of the student's "distance taken over all four turns" and a reviewer will know it. What it does not have is any array, torus or shared-cell variant, so no window of a larger pattern is constrained, and there is no uniqueness-of-position requirement.

### Verdict: NO THREAT (to the claim as worded), with a wording consequence

The claim must be phrased as a claim about windows of a doubly periodic array, not about rotation-aware distance in general, because the latter is established for isolated markers. I suggest citing the 2014 paper for the definition and the 2016 paper for the optimisation of it. Confidence is moderate for the 2016 paper because only its abstract was read.

### Unread

The body and supplementary files of the 2016 paper (a grid or "board" variant there cannot be excluded, though neither the abstract nor the 2014 paper hints at one), and the 2014 paper as typeset.

## 3. Lloyd and Burns 1993, "Finding the position of a subarray in a pseudo-random array"

### Reachability

No copy was found. The local pool has the Burns and Mitchell chapter (burns1992coding.pdf, byte-identical to the A2 copy, 240,118 bytes, matching the open-access file at Royal Holloway Research Online, https://repository.royalholloway.ac.uk/items/ea09bc73-0261-92ff-564f-0704f33d4feb/1/), Mitchell and Paterson "Decoding perfect maps", and no copy of Lloyd and Burns or of the patent (a pdftotext grep over all 208 local PDF files (duplicates included) for Lloyd, Finding the position of a subarray, 5442147 and HPL-92 found only citations). Crossref searches for the title, and for the volume "Cryptography and Coding III", returned no record, which fits a chapter with no DOI. OpenAlex returned HTTP 429 (daily request budget used up, no key). OpenCitations answered a 301 redirect that I did not follow, and a chapter without a DOI cannot be queried there anyway. Two web searches for the exact title returned no Google Books entry and no HP Labs item. The HP Labs report archive does hold a page for HPL-92-19 (http://www.hpl.hp.com/techreports/92/HPL-92-19.html), titled "Coding Schemes for Two-Dimensional Position Sensing" by John Burns and C. Mitchell, which confirms the HPL-92-19 note in lit/01 for the Burns and Mitchell chapter, not for Lloyd and Burns; the page showed no date and its PDF link target was not visible to the tool.

### What citing documents say about its content

Burns and Mitchell (local PDF, text layer, section "The decoding problem", near p. 26 of the chapter): the Lloyd and Burns result is the only work on decoding for arrays as opposed to sequences; it generalises Massey and Liu and reduces decoding of the MacWilliams and Sloane pseudorandom arrays with the (k1, k2)-window property to finding a discrete logarithm of an element of GF(2^(k1 k2)). The introduction calls it "Recent work of Lloyd and Burns" giving solutions in certain cases. A keyword search of that chapter's text layer finds no occurrence of Hamming, error, noise or misread. Mitchell and Paterson, "Decoding perfect maps" (local PDF, March 1993 text; DCC 4:11-30, 1994, [mitchell1994decoding]): the only other known array-decoding results are those of Lloyd and Burns, "a decoding technique for a certain special class of (binary) pseudorandom arrays"; that paper's text has no occurrence of rotat, orient, noise or error. Mitchell, Etzion and Paterson 1996 (IEEE TIT 42(5), read through the summarising tool) cites only Burns and Mitchell, not Lloyd and Burns. Horan and Stevens (local pool, "Locating patterns in the de Bruijn torus") and Bruckstein et al. (local pool, "Simple and robust binary self-location patterns") do not cite Lloyd and Burns (grep of the text layers; Bruckstein cites Burns and Mitchell as its reference 19). The patent US 5,442,147 (Section 1) carries a position-finding appendix for one- and two-dimensional pseudo-random arrays by discrete logarithms over finite fields with no treatment of rotation or bit errors; that matches the technique described above and Lloyd is a named inventor in the task brief, so the appendices are plausibly the same content, but no document says so and I mark that as inference.

### Verdict: INCONCLUSIVE (leaning NO THREAT)

The chapter itself is unread, but both authors-side descriptions say it is exact decoding of binary pseudorandom arrays with the plain window property, which are not orientable and carry no distance requirement.

### Unread

The whole chapter. A library request for Cryptography and Coding III (IMA conference series 45, ed. Ganley, Oxford University Press, 1993), or a request to Royal Holloway Information Security Group, are the remaining routes.

## 4. Suggested edits to existing notes

The entry for burns1993coding can take the note "Open-access PDF: Royal Holloway Research Online item ea09bc73-0261-92ff-564f-0704f33d4feb; HP Labs report page hpl.hp.com/techreports/92/HPL-92-19.html". The entry garrido2016generation in lit/02 can change its status from "not read" to "abstract read, body unread". The entry lloydburns1993 stays UNVERIFIED. For the paper's related work, the sentence on prior distance definitions should say that rotation-aware minimum distance exists for isolated square markers (Garrido-Jurado et al.) and that the open question is its use for windows of a periodic array that must also be 4-orientable.

## 5. New BibTeX entries

Existing keys burns1993coding, lloydburns1993, mitchell1994decoding and garrido2016generation are unchanged and are not repeated here.

```bibtex
@article{garrido2014automatic,
  author  = {Garrido-Jurado, S. and Mu{\~n}oz-Salinas, R. and Madrid-Cuevas, F. J. and Mar{\'\i}n-Jim{\'e}nez, M. J.},
  title   = {Automatic generation and detection of highly reliable fiducial markers under occlusion},
  journal = {Pattern Recognition},
  volume  = {47},
  number  = {6},
  pages   = {2280--2292},
  year    = {2014},
  doi     = {10.1016/j.patcog.2014.01.005},
  note    = {Verified on Crossref (title, volume, issue, pages, year, four authors). Full text read through a summarising fetch tool, not verbatim. Defines inter-marker and self-distance over the four quarter turns for isolated markers.}
}

@misc{burnslloyd1995position,
  author       = {Burns, John and Lloyd, Sheelagh A.},
  title        = {Position-sensing apparatus},
  howpublished = {US Patent 5,442,147},
  year         = {1995},
  month        = aug,
  note         = {Verified 2026-11-07 on Google Patents US5442147A: title, inventors, assignee Hewlett Packard Co, application US08/117,200, priority 1991-04-03, filed 1992-04-03, granted 1995-08-15. Patents carry no DOI; resolved by patent number. Family: WO1992017859A1, EP0578692B1.}
}
}

@misc{us5675129initial,
  author       = {{UNVERIFIED inventors}},
  title        = {Initial track recovery in position-sensing systems that use windowing patterns},
  howpublished = {US Patent 5,675,129},
  year         = {1997},
  note         = {UNVERIFIED metadata: title and number from the Similar Documents list of US5442147A on Google Patents; text layer read at the USPTO print service, which shows no title page, inventors or assignee. Optional citation.}
}

@misc{us7445160position,
  author       = {{UNVERIFIED inventors}},
  title        = {Position location using error correction},
  howpublished = {US Patent 7,445,160 B2},
  note         = {UNVERIFIED metadata: title and number from the Cited By list of US5442147A on Google Patents; claims and description read at the USPTO print service, which shows no title page, inventors or assignee. Nearest industrial neighbour found: nine-symbol 5 x 5 regions, fixed registration symbols for orientation, Reed-Solomon [7,5,3] over GF(8). Optional citation.}
}
```
