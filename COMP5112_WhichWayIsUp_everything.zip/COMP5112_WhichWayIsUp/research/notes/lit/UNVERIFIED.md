# Unverified references (do not cite until resolved)

Generated from research/notes/bib/check_results.json. These have no DOI or arXiv id that could be resolved automatically. Most are print-only classics. Several were read locally from the PDF, which is a different kind of verification; that is noted per entry.

- **burns1993coding**: Coding schemes for two-dimensional position sensing (1993). Found in lit/01_orientability.md. No DOI. Editor, publisher and pages as given in the reference list of Mitchell and Wild 2022 (arXiv 2108.03069, ref [4]). Earlier version: Hewlett-Packard Laboratories Technical Report HPL-92-19, January 1992 (ref [3] there).
- **dai1993orientable**: Orientable sequences (1993). Found in lit/01_orientability.md. No DOI or arXiv id found. Not read; bibliographic data from Mitchell and Wild 2022 (arXiv 2108.03069, ref [8]).
- **gao2021novel**: A novel camera calibration pattern robust to incomplete pattern projection (2021). Found in lit/01_orientability.md, lit/05_applications.md. UNVERIFIED: taken from the HydraMarker reference list only
- **etzionbook2024**: Sequences and the De Bruijn Graph: Properties, Constructions, and Applications (2024). Found in lit/03_structure.md. UNVERIFIED: book-level entry copied from the reference list of Becher-Carton 2024; no DOI or ISBN checked; not read.
- **fan1985**: On de Bruijn arrays (1985). Found in lit/03_structure.md, lit/04_construction.md. UNVERIFIED: details copied from the reference lists of Hurlbert-Isaak 1993 and Becher-Carton 2024; no DOI found; not read.
- **lloydburns1993**: Finding the position of a subarray in a pseudo-random array (1993). Found in lit/03_structure.md. UNVERIFIED: details copied from the reference lists of Burns-Mitchell and Mitchell-Paterson; no DOI or arXiv id found; not read.
- **etzion2011** (identifier verified, year to confirm at export): bib year 2011, registry year 2009. Title and DOI match.
- **burnsmitchell1993**: Coding schemes for two-dimensional position sensing (1993). Found in lit/03_structure.md. UNVERIFIED: no DOI or arXiv id found. Details copied from the reference lists of Universal Partial Tori and Kreitzer et al. (the latter also gives a Hewlett-Packard Laboratories technical report, 1992). I read a local full-text copy.
- **burns1992hp**: Coding schemes for two-dimensional position sensing (1992). Found in lit/04_construction.md. UNVERIFIED: no DOI or arXiv id found. Cited under this description as ref. 2 by Kreitzer et al. 2024 and ref. 5 by Chen et al. 2024. I read pp. 28 to 32 of a local copy

Seed entries that are print-only and were never DOI-checked: fan85debruijn (FFMS 1985; local PDF scan; pages 205-213), dai1993orientable (Dai et al. 1993; PDF not in folder, not read), burns1993coding (read locally; reference details taken from Mitchell and Wild 2022 reference list).

## Added after pool triage (lit/06_pool_A/B/C.md), 2026-11-07

Thirty of 33 new entries were checked against Crossref by tools/check_new.py and merged into bib/otorus.bib. Their backup copies are bib/otorus.bib.bak_pre_pool and bib/check_results.bak_pre_pool.json. Three have no DOI or arXiv id and are NOT in otorus.bib.

- **anisiu2006maximal**: Two-dimensional arrays with maximal complexity (Anisiu and Ivanyi, Pure Mathematics and Applications 17(3-4), 197-204, 2006). Found in lit/06_pool_B.md. No DOI found. Checked only against the local pool PDF, which is a different kind of verification.
- **stojkovic2019pseudorandom**: Pseudorandom binary arrays for position determination using virtual instrumentation (UNITECH 2019, Gabrovo). Found in lit/06_pool_B.md. No DOI found. Page range in the agent's entry was inferred, so leave pages out of any citation until confirmed.
- **casteels2017higherdim**: De Bruijn Sequences of Higher Dimension (Casteels and Tinker, undated, latest reference 2017). Found in lit/06_pool_C.md. Student capstone report, not peer reviewed, no identifier. Do not cite in the paper; at most a footnote.

Year notes (title and DOI match, year to confirm at export):
- **ozturk1996generation**: bib year 1996, Crossref year 2002. The DOI prefix is the 1996 NEBC conference; Crossref carries the later digital-library posting date. Keep 1996.
- **morita1988reconstruction**: bib year 1988, Crossref year 2005. The DOI is the 1988 CCV proceedings; same cause. Keep 1988.
- **becher2024**: not merged because its DOI already exists under another key in otorus.bib.

## Added after threat checks (lit/07_threat_checks.md), 2026-11-07

- **lloydburns1993** stays UNVERIFIED and unread: no copy reachable (not in the pool, no Crossref record, not in the HP Labs archive). HP report HPL-92-19 is Burns and Mitchell, not Lloyd and Burns. Do not cite it for anything beyond what Burns and Mitchell and Mitchell and Paterson say about it (decoding of MacWilliams-Sloane arrays by a discrete logarithm). Remaining routes: library request for Cryptography and Coding III (IMA conference series 45, ed. Ganley, OUP 1993), or ask the Royal Holloway Information Security Group.
- **us5675129initial** and **us7445160position**: patent numbers and titles come from Google Patents link lists; inventors and dates were not verified (page fetch failed for 7,445,160). Not in otorus.bib. Optional related-work citations only.
- **garrido2016generation**: abstract and Crossref metadata read, body and supplement unread.
- Tool caveat for 07_threat_checks.md: every web "no occurrence" result came through a fetch tool that summarises with a small model, so it means "the tool reported none", not a grep. The local PDFs were checked with pdftotext and grep.
