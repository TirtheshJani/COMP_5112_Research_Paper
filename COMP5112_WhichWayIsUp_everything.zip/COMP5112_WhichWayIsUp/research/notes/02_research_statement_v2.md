# Research statement v2 (2026-11-09), after Phase 3 results and peer reviews 1 and 2

Form follows The Craft of Research, 5th ed.: topic, question, significance (1.3, 2.1), with the practical application as a fourth step (2.3) and the claim stated as an answer (Part III). v1.1 posed the question; v2 states the answer the evidence supports and what is still open. Every number traces to research/results/README.md.

## Interest
Patterns that let a sensor work out where it is from a single glance.

## Topic
Binary doubly periodic arrays (tori) read through a u x u window by a camera whose quarter-turn orientation is unknown.

## Question (unchanged from v1.1)
How large can such a torus be when every window and its 90, 180 and 270 degree turns are pairwise distinct and any two of these turned windows differ in at least two cells (the strong form)? Do the two requirements compose or compete?

## Problem
Condition. Orientability (Burns and Mitchell 1993) and window distance (Berkowitz and Kopparty 2016) each have a literature, and each assumes away the other's concern. No print source gives a periodic binary array with both properties at any window size.
Consequence. Without that answer a designer cannot tell whether requirements on a position pattern can be stacked like constraints on a code (compose) or whether each gain in error detection must be paid for in size (compete).

## Claim (the answer)
Definition used: the requirements compose if adding distance 2 shrinks the largest torus by about the factor that window codes lose (exactly 2), and compete if it shrinks it by more.
They compete (proved computationally at 3 x 3; suggested by search at 4 x 4 and 5 x 5), and the extra cost appears when the pattern must close on itself (periodicity), not from local packing.
1. Distance 2 halves the counting ceiling: 4,193,280 cells for 5 x 5 windows (centre-flip pairing, odd sides) and 8,192 for 4 x 4 (Hall and Koenig, even sides). The ceilings are tight for window codes: the even-weight (odd sides) or odd-weight (even sides) usable windows form a rotation-closed code of exactly that size. Any better bound must use the torus structure (periodicity).
2. The real cost is larger than 2. For 3 x 3 windows the exact strong-form maximum is 36 cells (3 x 12 and 6 x 6; 134 shapes decided by SAT and by an exhaustive search that shares no code with it), while orientation alone allows at least 85 of a 120 ceiling: a factor between 2.36 and 3.33. Open patches and strips locate the cost: an open 9 x 8 patch holds 168 turned windows at distance 2, more than any torus (144), while a strip that wraps one way fails early (width 4 at length 7, a third of the code bound); with distance 1 such strips reach length 20. (The first reading, local overlap, was corrected after peer review 2.) Under local search with equal budgets, distance 2 shrinks the largest torus found about 9 times for 4 x 4 (5 seeds; brackets 8.5 to 11.8) and about 20 times for 5 x 5 (2 seeds strong form, 1 seed orientation only; brackets 18 to 25); these are ratios of what one method finds, not of maxima.
3. Large strong-form tori still exist: 256 x 256 for 5 x 5 windows (65,536 cells, two seeds), found by local search and verified independently. Two algebraic families with simple decoders reach 36 (XOR, distance 5) and 280 cells (checkerboard interleave with admissible labels, exact maximum 14 x 20, family cap 392). Without the admissibility condition a 308-cell interleave exists (found during peer review 1); that family's maximum is open (cap 512).

## Hypotheses: what happened
H1 (compose) predicted 3 x 3 maximum = 60. Falsified: 36.
H2 (compete) predicted that 5 x 5 search would stall near 36. Falsified: 65,536.
Neither prediction had a control (orientation alone also falls short of its ceiling). The evidence supports a graded form of H2, formed after seeing the data and so exploratory: distance costs more than the code-level factor of 2, proved at 3 x 3, and search suggests the extra cost grows with window size.

## Fourth step: application (2.3)
In a simulated camera (random position and quarter turn, angle and offset error, blur, pixel noise, 20,000 reads per noise level, common random numbers), with a size-matched control (both 6 x 6, density 0.28): at noise 0.3 distance 2 cut wrong reads from 8.5 to 2.6 percent at the same correct rate (64 percent); the difference went to rejections. On reads with two or more wrong cells it does worse (38 against 29 percent wrong). The single-error result (0 of 103,801 wrong) is a check of the implementation, since it follows from distance 2. The guarantee pays most where windows are dense, which is where it costs most. Table decoding runs at 3.9 to 16.8 million lookups per second, far above Dothraki's 14 Hz pipeline.

## Significance (so what?)
Designers of self-locating patterns should not expect to stack requirements and stay near the counting bound. Distance should be asked for where density makes it pay. For theory, the open problems are about periodicity.

## Open (call for research, 14.7)
- 3 x 3 orientation-only maximum: between 85 and 120.
- 4 x 4 strong-form maximum: between 441 and 8,192 (an exact answer would show whether the cost grows with window size).
- Unrestricted checkerboard interleave: between 308 and 512.
- 5 x 5 strong-form maximum: between 65,536 and 4,193,280.
- Whether extremal 5 x 5 tori must have constant parity (would give 4,193,275 via the divisibility lemma, for sides not in {1, 5}).
- Distance 3, so a reader can correct rather than reject a misread cell.

## Acknowledged limits (9.4, 10)
Search brackets rest on one method, one temperature, five seeds at 4 x 4 and one or two at 5 x 5. Exact results are computational (two complete methods with no shared code agree; no DRAT certificates). The camera is simulated, without perspective or printing. The literature search did not use Google Scholar and sampled patents only.

## Changes from v1.1
- Answer stated; H1 and H2 both falsified in their original form, graded H2 supported.
- XOR family cap corrected from 128 to 120 positions (32 half-turn-fixed windows excluded); its exact maximum is 36.
- Interleave family added (280 cells).
- Baseline in the camera test is an orientation-only torus of the same window size, not a plain de Bruijn torus (a de Bruijn torus is only 1-orientable, so it cannot be decoded without knowing the turn).
- The constant-parity bound needs sides outside {1, 5}; v1.1 omitted this condition.
- After peer review 2: mechanism restated as closure (open-patch control); excess over the code factor reported as a measured 18 to 67 percent; camera multi-error result stated plainly.
- After peer review 1: Theorem 11 restricted to admissible labels; claim restated with a quantitative definition of compose and compete; equal search budgets and five seeds at 4 x 4; size-matched camera control; exhaustive search given its own window bookkeeping; open-strip proposition; every reported torus stored and re-verified.
