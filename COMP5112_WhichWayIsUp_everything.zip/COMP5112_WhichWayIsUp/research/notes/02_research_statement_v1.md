# Research statement v1.1 (2026-11-09), approved direction, Reachy Mini removed from the paper

Form follows The Craft of Research, 5th ed.: topic, question, significance (1.3 and 2.1), stated as pure research with the application as a fourth step (2.2 and 2.3). Section numbers below refer to that edition.

## Interest
Patterns that let a sensor work out where it is from a single glance.

## Topic
I am studying binary doubly periodic arrays (tori) read through a 5 x 5 window by a camera whose rotation is unknown.

## Question
How large can such a torus be when every 5 x 5 window, together with its 90, 180 and 270 degree turns, is pairwise distinct and any two of these turned windows differ in at least two cells? The only example known has 36 cells (a 6 x 6 XOR torus with window distance 5). The counting ceiling is 4,193,280 cells. Where between those two numbers does the true maximum lie, and do exact answers for 3 x 3 and 4 x 4 windows predict it?

## Problem
Condition. Rotation-independence (orientability, Burns and Mitchell 1993) and error detection (window distance, Berkowitz and Kopparty 2016) are each achievable on their own: 4-orientable binary fields of 123 x 123 exist aperiodically, and distance-protected periodic binary arrays exist with known orientation. Nobody has shown whether both can be had together in a periodic binary array at any size above 36 cells, and nobody has computed the exact maximum for any window size.

Consequence (so what?, 1.3). Without that answer we do not know whether the two constraints compose or compete. If they compose, the maximum sits within a small constant of the ceiling and position patterns can be designed by stacking constraints, the way codes are. If they compete, the maximum collapses far below the ceiling, algebraic constructions are ruled out (the XOR family already stops at 128 positions), and such patterns can only be found by search. That distinction decides how every later design of a self-locating pattern should begin.

## Competing hypotheses and the test that separates them
H1 (compose): exact maxima at small windows equal the counting bounds (3 x 3: 60 cells with distance 2), and a 5 x 5 torus of hundreds of cells per side exists.
H2 (compete): exact small-window maxima fall well short of the counting bounds and 5 x 5 search stalls near 36.
The exact 3 x 3 maximum, computable by complete search, decides between them before any 5 x 5 search is run.

## What would falsify the originality claim
A print document giving a periodic binary array that is 4-orientable with window distance at least 2 at the uniqueness window. Phase 1 (lit/00_synthesis.md, lit/07_threat_checks.md) found none; the nearest are Vandenhouten et al. 2017 (binary toroidal, centrally symmetric, distance only at larger windows), Garrido-Jurado et al. 2014 (rotation-aware distance for isolated markers), and US 5,442,147 (orientability without distance).

## Minimum publishable result
The strong-form definition; the proved ceilings 4,193,280 (parity-free) and 4,193,275 (constant parity, with the divisibility lemma 5 | R, 5 | C); the exact maximum for 3 x 3 windows; the 6 x 6 example and the proof that the XOR family cannot exceed 128 positions; and the H1 versus H2 verdict at small windows. A 5 x 5 torus above 36 cells is the upside.

## Fourth step: practical application (2.3, stated in the conclusion, 14.7)
A sensor reading a printed torus at unknown rotation, as in Dothraki, could reject a single misread cell without the four-window agreement test. Evidence: a simulated camera that renders the tiled torus, rotates it by a random angle, adds perspective and pixel noise, and decodes; thousands of trials give decode success and false-accept rate under single-cell corruption, for the torus against a plain de Bruijn torus baseline. The Reachy Mini is not part of the paper. If time allows after Nov 22 it supplies a short clip for the presentation only.

## Acknowledged limits (9.4)
Patents and technical reports were sampled, not exhausted; Lloyd and Burns 1993 is unread; the 2016 Garrido-Jurado body is unread. The paper states these in its related-work section.
