# Results index (Phase 3, 2026-11-09; updated after peer review 1, Phase 4)

Every number meant for the paper should trace to a file here and to the code in research/otorus that produced it. Tests: `cd research/otorus && python3 -m pytest -q` (61 tests). Witness check: `python3 scripts/verify_witnesses.py` re-verifies every torus in witnesses/ against the property its name claims, with code independent of the search and SAT code (output: verify_witnesses.txt, 0 failures on every stored torus; the count is in the file).

## Claims and their evidence

1. Ceilings for every window size 2 x 2 to 5 x 5, s in {1, 2, 4}, distance 1 or 2, with proofs. File: bounds.md. Code: otorus/bounds.py. Check: tests/test_bounds.py, including a bipartite-matching computation of the largest set of usable windows at distance 2 for 2 x 2, 3 x 3 and 4 x 4 windows. Headline: 5 x 5 strong form R*C <= 4,193,280; 4 x 4 strong form R*C <= 8,192 (even-window argument via Hall and Koenig).

2. Exact maximum for 3 x 3 windows, 4-orientable, distance 2: 36 cells (3 x 12 and 6 x 6), against a ceiling of 60. File: exact_3x3_strong_form.md. Data: sat_table.csv (rows u=3, s=4, delta=2), verify_3x3_s4_d2_dfs.csv (exhaustive search, all 134 shapes up to 60 cells, all agree with SAT), verify_3x3_s4_d2.csv (second SAT encoding, 56 shapes up to 30 cells, all agree). Witnesses: witnesses/u3v3s4d2_*.txt.

3. Control at 3 x 3, orientation only (distance 1): every shape with 3 <= R <= C and RC <= 81 has a torus, and so do 4 x 21, 6 x 14 (84) and 5 x 17 (85); 3 x 28 and 7 x 12 undecided at 50 s, 14 shapes from 87 to 116 cells undecided at 40 s, 10 x 12 and 5 x 24 undecided at 25 minutes. Largest known: 85 of 120. Data: sat_table.csv (rows u=3, s=4, delta=1). Witnesses: witnesses/u3v3s4d1_*.txt.

3a. Open strips and patches (exhaustive search, otorus.exhaustive.dfs_strip and dfs_patch). Strips wrap one way only: with distance 2, no strip of width 4 or 5 survives to length 7 (width 1: 5; 2: 7; 3: 17; 6: 9; 7 and 8: 6; 9: 7), strips_3x3_s4_d2.csv; with distance 1, strips of widths 3 to 5 reach length 20, strips_3x3_s4_d1.csv. Patches wrap in neither direction: with distance 2, open 8 x 8 (144 turned windows), 9 x 8 (168) and 20 x 4 (144) patches can be filled, patches_3x3_s4_d2.csv (9 x 9 undecided at 3e8 nodes). Reading (peer review 2, finding A): the extra cost appears when the pattern must close on itself, not from local packing. Scripts: run_strips.py, run_patches.py.

4. XOR family a_i xor b_j (5 x 5): exact maximum 36 cells; all 306 shapes up to the family's cap of 120 cells decided, four exist (1 x 6, 4 x 6, 5 x 6, 6 x 6), all at window distance 5. The family facts (512 windows, closed under turns, 32 half-turn-fixed, pairwise distance >= 5) are checked in tests/test_construct.py. Data: xor_table.csv.

5. Checkerboard interleave (binary counterpart of Construction E): theorem with proof sketch and exact maximum 280 cells (14 x 20) for admissible labels (no 5-window 00000, 11111, 01010, 10101); every shape above 280 is impossible for admissible labels. CORRECTED after peer review 1: without admissibility a 14 x 22 interleave (308 cells) exists at distance 2 (witnesses/interleave_unrestricted_R14C22.txt); the unrestricted maximum is open (cap 512). File: interleave.md. Data: interleave_table.csv, interleave_rows6.csv. Code: otorus/construct.py. Checks: tests/test_construct.py (descriptor criterion against the direct check on 360 random pairs).

6. Local search with equal budgets per condition (after peer review 1). 4 x 4: 3e6 flips, seeds 0 to 4. 5 x 5: 3e7 flips, seed 0 (and seed 1 for the strong form at 256 and 272).
   - 5 x 5 strong form: 256 x 256 = 65,536 solved on seeds 0 and 1 (728,102 and 15.6 million flips); 272 x 272 failed on both (energies 20 and 2); 288 x 288 failed (energy 32).
   - 5 x 5 orientation only: 1152 x 1152 = 1,327,104 solved (12.5 million flips); 1280 x 1280 failed (energy 660).
   - 4 x 4 strong form: 21 x 21 = 441 solved on 1 of 5 seeds (20 x 20 on 3 of 5); 22 x 22 failed on all 5.
   - 4 x 4 orientation only: 64 x 64 = 4,096 solved on 3 of 5 seeds; 72 x 72 failed on all 5.
   - Ratio of largest solved sizes: about 9 (4 x 4; brackets 8.5 to 11.8) and about 20 (5 x 5; brackets 18 to 25). Earlier 10e6-flip runs (288 and 320 at distance 2) and the stalled run without rescans remain in the CSV but are not used for the comparison.
   Data: grow_5x5.csv, grow_4x4.csv. Witnesses: witnesses/u5s4d*_R*_seed*.npz, witnesses/u4s4d*_R*_seed*.npz (np.packbits; unpack with np.unpackbits(bits)[:R*C].reshape(shape)). Method note: the search needs periodic full rescans of its conflict list (regression test in tests/test_search.py); without them one run stalled at 256 x 256.
   Reading: between the largest solved and the smallest unsolved size, the occupied fraction of each window's conflict ball (density times 1 + u*u for distance 2, density for orientation only) is 0.16 to 0.20 (5 x 5) and 0.25 to 0.32 (4 x 4) for orientation only, and 0.20 to 0.23 (5 x 5) and 0.46 to 0.50 (4 x 4) for the strong form.

7. Simulated camera (rerun after peer review 1 with a size-matched control; seed 12345 for every torus, so the six original tori reproduce camera_robustness_v1.csv exactly). Seven tori, 20,000 reads per noise level. Size-matched 3 x 3 pair (6 x 6, density 0.28): at noise 0.3 the strong-form torus is wrong 2.6 percent of the time against 8.5 percent for orientation only, with the same correct rate (63.9 and 64.2 percent); the difference goes to rejections. On reads with two or more wrong cells the strong-form torus is wrong more often (38 against 29 percent). No strong-form torus decoded any of its 103,801 single-error reads wrongly (a check: this follows from distance 2). Orientation-only single-error wrong rates: 22.9 percent (6 x 6, density 28), 64.0 (9 x 9, density 63), 0.74 (256 x 256, density 0.78). File: camera_robustness.csv (v1 kept as camera_robustness_v1.csv). Timing: decode_timing.md, median of five runs of 200,000 decodes on one core of TJ's machine, 3.9 to 16.8 million per second.

## Open (after peer review 2)
- 3 x 3 orientation-only exact maximum: between 85 and 120.
- 4 x 4 strong form: between 441 and 8,192.
- Unrestricted checkerboard interleave: between 308 and 512.
- 5 x 5 strong form: between 65,536 (search) and 4,193,280 (ceiling).
- Whether the constant-parity bound 4,193,275 holds in general.
- More seeds at 5 x 5 (one or two per size), and a temperature tuned per condition.
- Strip and patch experiments for 4 x 4 windows (would test the closure explanation).
