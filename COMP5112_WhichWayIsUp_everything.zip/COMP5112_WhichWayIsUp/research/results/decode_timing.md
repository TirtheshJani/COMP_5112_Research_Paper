# Decode timing (table decoder, numpy binary search, one core, 200,000 decodes per run, 5 runs)

| torus | shape | table entries | median decodes per second | slowest run | fastest run |
|---|---|---|---|---|---|
| 3x3 strong 6x6 | 6 x 6 | 144 | 12,139,282 | 9,046,760 | 13,988,474 |
| 3x3 orientation-only 6x6 | 6 x 6 | 144 | 16,779,565 | 14,208,106 | 19,905,576 |
| 3x3 orientation-only 9x9 | 9 x 9 | 324 | 14,518,437 | 14,038,571 | 17,568,501 |
| 5x5 XOR 6x6 | 6 x 6 | 144 | 7,343,933 | 6,366,872 | 8,066,435 |
| 5x5 interleave 14x20 | 14 x 20 | 1,120 | 6,742,008 | 6,481,093 | 8,131,727 |
| 5x5 strong 256x256 | 256 x 256 | 262,144 | 3,891,705 | 3,189,209 | 4,930,705 |
| 5x5 orientation-only 256x256 | 256 x 256 | 262,144 | 3,903,803 | 3,384,919 | 5,305,988 |

Dothraki (Schusselbauer et al. 2021) reports a 14 Hz end-to-end pipeline; the table lookup is not the bottleneck.
