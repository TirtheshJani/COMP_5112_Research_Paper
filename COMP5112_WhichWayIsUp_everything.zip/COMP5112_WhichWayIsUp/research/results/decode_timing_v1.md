# Decode timing (table decoder, numpy binary search, one core of the cloud container)

| torus | shape | decodes per second |
|---|---|---|
| 3x3 strong 6x6 | 6 x 6 | 6,304,617 |
| 3x3 orientation-only 9x9 | 9 x 9 | 24,908,272 |
| 5x5 XOR 6x6 | 6 x 6 | 6,127,365 |
| 5x5 interleave 14x20 | 14 x 20 | 9,861,989 |
| 5x5 strong 256x256 | 256 x 256 | 3,626,377 |
| 5x5 orientation-only 256x256 | 256 x 256 | 8,798,347 |

Dothraki (Schusselbauer et al. 2021) reports a 14 Hz end-to-end pipeline; the table lookup is not the bottleneck.
