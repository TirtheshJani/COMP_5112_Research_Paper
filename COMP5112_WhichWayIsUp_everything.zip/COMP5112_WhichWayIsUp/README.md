# Which Way Is Up? Everything in one folder

COMP 5112 Research Methodology, Tirthesh Jani, Lakehead University. Packed 11 November 2026.

## What is where

- `study_guide/` : the study guide (`Which_Way_Is_Up_Study_Guide.pdf`) with its LaTeX source (`main.tex`, `preamble.tex`, `parts/`), and the reading list (`reading_list.md`). Compile with `pdflatex main.tex` twice.
- `meeting_prep_aaron/` : Even Realities G2 Conversate Prep Notes for the meeting with Aaron. Start with `00_how_to_load.txt`.
- `research/paper/` : the paper source (LIPIcs; main file `1374286TJ.tex`, sections, figures, `refs.bib`, `refs_check.md`), compiled drafts in `build/` (draft 3 is current), the two peer reviews in `review/`, and the talk plan in `talk/`.
- `research/otorus/` : the Python library, scripts and tests. Run the tests with `python3 -m pytest -q` from this folder.
- `research/results/` : every result file behind a number in the paper, the claims index (`README.md`), logs, and the 136 stored tori in `witnesses/`.
- `research/notes/` : literature notes, synthesis, bibliography and the research statement (`02_research_statement_v2.md` is final).
- `slides/` : the 14-slide talk deck files (`deck.json`, `slides/*.html`, `assets/`). The live, editable deck is at https://claude.ai/artifact/1BViCw9cESKihwE9AYWFzi
- `COMP5112_paper_overleaf.zip` : the paper source packed for upload to Overleaf.

## Still to do before submission

1. AI-use statement at the end of Section 10: say what you checked yourself, name the course AI policy, confirm the model names, remove the TODO comments.
2. Data statement: add the public repository URL, or say the repository is submitted with the paper.
3. BibTeX: the course asks for Google Scholar exports; the entries were checked against Crossref and arXiv instead.
