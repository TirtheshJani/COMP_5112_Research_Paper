"""Window table and piece decoder. No vision, no robot."""
from dataclasses import dataclass
import numpy as np

U = 5      # window side
CELLS = 6  # cells per piece side


@dataclass(frozen=True)
class Read:
    row: int   # piece row in the puzzle, on the printed (back) side
    col: int   # piece column, on the printed (back) side
    turn: int  # quarter turns, counter-clockwise, 0..3


def build_table(patch: np.ndarray, u: int = U) -> dict:
    """Map every upright u x u window of an open patch to its (row, col)."""
    table = {}
    rows, cols = patch.shape
    for r in range(rows - u + 1):
        for c in range(cols - u + 1):
            key = patch[r:r + u, c:c + u].astype(np.uint8).tobytes()
            if key in table:
                raise ValueError(f"duplicate window at {(r, c)} and {table[key]}")
            table[key] = (r, c)
    return table


def decode_piece(cells: np.ndarray, table: dict, u: int = U):
    """Return a Read, or None to reject.

    cells is the CELLS x CELLS bit grid as seen by the camera. Accept only if
    exactly one un-turning makes all four u x u windows land on consistent
    positions that start on a piece boundary.
    """
    n = cells.shape[0]
    hits = []
    for k in range(4):
        upright = np.rot90(cells, -k).astype(np.uint8)
        origin = None
        ok = True
        for a in range(n - u + 1):
            for b in range(n - u + 1):
                pos = table.get(upright[a:a + u, b:b + u].tobytes())
                if pos is None or (origin is not None and (pos[0] - a, pos[1] - b) != origin):
                    ok = False
                    break
                origin = (pos[0] - a, pos[1] - b)
            if not ok:
                break
        if ok and origin[0] % n == 0 and origin[1] % n == 0:
            hits.append(Read(origin[0] // n, origin[1] // n, k))
    return hits[0] if len(hits) == 1 else None


def front_slot(read: Read, puzzle_cols: int) -> tuple:
    """Slot on the picture side: the back is a mirror image, so flip the column."""
    return read.row, puzzle_cols - 1 - read.col
