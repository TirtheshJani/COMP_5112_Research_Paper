"""Draw a piece back and photograph it synthetically."""
import cv2
import numpy as np

UNITS = 8  # 6 cells + half-cell white ring + half-cell black border, each side


def draw_piece(cells: np.ndarray, scale: int = 40) -> np.ndarray:
    """Black border, white ring, then the cells (1 = black). Returns uint8 gray."""
    n = cells.shape[0]
    side = (n + 2) * scale
    img = np.zeros((side, side), np.uint8)
    h = scale // 2
    img[h:side - h, h:side - h] = 255
    for i in range(n):
        for j in range(n):
            if cells[i, j]:
                y, x = (i + 1) * scale, (j + 1) * scale
                img[y:y + scale, x:x + scale] = 0
    return img


def photograph(piece: np.ndarray, rng, angle_deg: float, tilt: float = 0.15,
               blur: float = 1.0, noise: float = 8.0, size: int = 480,
               frac: float = 0.45) -> np.ndarray:
    """Place the piece on a light background at any angle with perspective jitter."""
    s = piece.shape[0]
    half = frac * size / 2
    t = np.deg2rad(angle_deg)
    rot = np.array([[np.cos(t), -np.sin(t)], [np.sin(t), np.cos(t)]])
    square = np.array([[-1, -1], [1, -1], [1, 1], [-1, 1]], float) * half
    dst = square @ rot.T + size / 2 + rng.uniform(-tilt, tilt, (4, 2)) * half
    src = np.array([[0, 0], [s, 0], [s, s], [0, s]], np.float32)
    H = cv2.getPerspectiveTransform(src, dst.astype(np.float32))
    frame = cv2.warpPerspective(piece, H, (size, size), borderValue=200)
    if blur > 0:
        frame = cv2.GaussianBlur(frame, (0, 0), blur)
    frame = frame.astype(float) + rng.normal(0, noise, frame.shape)
    return np.clip(frame, 0, 255).astype(np.uint8)
