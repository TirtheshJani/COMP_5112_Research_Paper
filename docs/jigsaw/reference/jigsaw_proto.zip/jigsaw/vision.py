"""Find the piece in a gray frame and read its cell grid."""
import cv2
import numpy as np


def find_quad(gray: np.ndarray):
    """Corners of the largest dark four-sided blob, clockwise from the top-left-most."""
    _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    contours, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    best = None
    for c in sorted(contours, key=cv2.contourArea, reverse=True)[:5]:
        approx = cv2.approxPolyDP(c, 0.03 * cv2.arcLength(c, True), True)
        if len(approx) == 4 and cv2.contourArea(approx) > 0.01 * gray.size:
            best = approx.reshape(4, 2).astype(np.float32)
            break
    if best is None:
        return None
    centre = best.mean(axis=0)
    ang = np.arctan2(best[:, 1] - centre[1], best[:, 0] - centre[0])
    best = best[np.argsort(ang)]              # clockwise in image coordinates
    start = int(np.argmin(best.sum(axis=1)))  # top-left-most first
    return np.roll(best, -start, axis=0)


def read_cells(gray: np.ndarray, n: int = 6, scale: int = 24):
    """Return the n x n bit grid (1 = black) as the camera sees it, or None."""
    quad = find_quad(gray)
    if quad is None:
        return None
    side = (n + 2) * scale
    dst = np.array([[0, 0], [side, 0], [side, side], [0, side]], np.float32)
    flat = cv2.warpPerspective(gray, cv2.getPerspectiveTransform(quad, dst), (side, side))
    q = scale // 4
    means = np.array([[flat[(i + 1) * scale + q:(i + 2) * scale - q,
                            (j + 1) * scale + q:(j + 2) * scale - q].mean()
                       for j in range(n)] for i in range(n)])
    ring = flat[scale * 5 // 8: scale * 7 // 8, scale:side - scale].mean()   # white ring
    edge = flat[scale // 8: scale * 3 // 8, scale:side - scale].mean()       # black border
    if ring - edge < 40:
        return None
    return (means < (ring + edge) / 2).astype(np.uint8)
