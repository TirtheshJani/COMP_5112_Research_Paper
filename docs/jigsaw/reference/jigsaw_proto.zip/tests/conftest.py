import numpy as np
import pytest
from jigsaw.decode import build_table


@pytest.fixture(scope="session")
def patch():
    """A 30 x 48 stand-in patch (5 x 8 pieces). Real runs load the stored torus."""
    rng = np.random.default_rng(7)
    while True:
        p = rng.integers(0, 2, (30, 48), dtype=np.uint8)
        seen = set()
        ok = True
        for r in range(26):
            for c in range(44):
                w = p[r:r + 5, c:c + 5]
                for k in range(4):
                    key = np.rot90(w, k).tobytes()
                    if key in seen:
                        ok = False
                    seen.add(key)
        if ok:
            return p


@pytest.fixture(scope="session")
def table(patch):
    return build_table(patch)
