import numpy as np
from jigsaw.decode import decode_piece
from jigsaw.render import draw_piece, photograph
from jigsaw.vision import read_cells


def test_round_trip_at_any_angle(patch, table):
    rng = np.random.default_rng(1)
    wrong = rejected = 0
    trials = 400
    for _ in range(trials):
        i, j = int(rng.integers(5)), int(rng.integers(8))
        frame = photograph(draw_piece(patch[6*i:6*i+6, 6*j:6*j+6]), rng,
                           angle_deg=float(rng.uniform(0, 360)))
        cells = read_cells(frame)
        got = decode_piece(cells, table) if cells is not None else None
        if got is None:
            rejected += 1
        elif (got.row, got.col) != (i, j):
            wrong += 1
    print(f"wrong={wrong} rejected={rejected} of {trials}")
    assert wrong == 0
    assert rejected <= trials * 0.05
