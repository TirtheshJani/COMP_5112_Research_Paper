import numpy as np
from jigsaw.decode import Read, decode_piece, front_slot


def piece(patch, i, j):
    return patch[6 * i:6 * i + 6, 6 * j:6 * j + 6]


def test_every_piece_decodes_at_every_turn(patch, table):
    for i in range(5):
        for j in range(8):
            for k in range(4):
                assert decode_piece(np.rot90(piece(patch, i, j), k), table) == Read(i, j, k)


def test_single_misread_is_never_a_wrong_answer(patch, table):
    for i in range(5):
        for j in range(8):
            for a in range(6):
                for b in range(6):
                    bad = piece(patch, i, j).copy()
                    bad[a, b] ^= 1
                    assert decode_piece(bad, table) in (None, Read(i, j, 0))


def test_front_slot_mirrors_the_column():
    assert front_slot(Read(2, 0, 1), puzzle_cols=8) == (2, 7)
